import { useEffect, useState } from "react";
import { signedImageUrls } from "@/lib/keepsakes";

/** Signed URLs for private photos, refreshed whenever the set of paths changes. */
export function usePrivateImageUrls(paths: string[]) {
  const key = paths.filter(Boolean).join("|");
  const [urls, setUrls] = useState<Record<string, string>>({});

  useEffect(() => {
    const list = key ? key.split("|") : [];
    if (!list.length) {
      setUrls({});
      return;
    }
    let active = true;
    signedImageUrls(list).then((map) => {
      if (active) setUrls(map);
    });
    return () => {
      active = false;
    };
  }, [key]);

  return urls;
}
