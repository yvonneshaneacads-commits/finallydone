import { useUniverse } from "@/store/universe";
import { MascotAvatar } from "@/components/kit/bits";
import { MusicNotes } from "@/components/home/music-notes";
import { WelcomePanel } from "@/components/home/welcome-panel";
import { LocationsPanel } from "@/components/home/locations-panel";
import { OverviewPanel } from "@/components/home/overview-panel";
import { PlannerPreview } from "@/components/home/planner-preview";
import { AnimalsPanel } from "@/components/home/animals-panel";
import { QuickAccessPanel } from "@/components/home/quick-access-panel";
import { NotificationsPanel } from "@/components/home/notifications-panel";
import { GoalsPanel } from "@/components/home/goals-panel";
import { ReflectionPanel } from "@/components/home/reflection-panel";

const Home = () => {
  const { data } = useUniverse();
  const show = data.settings.widgets;

  return (
    <div className="flex flex-col gap-3.5">
      <div className="stagger-fade grid grid-cols-1 gap-3.5 xl:grid-cols-12">
        <WelcomePanel className="xl:col-span-7" />
        <LocationsPanel className="xl:col-span-5" />
      </div>

      <MusicNotes />

      <div className="stagger-fade grid grid-cols-1 gap-3.5 lg:grid-cols-2 xl:grid-cols-12">
        {show.overview && <OverviewPanel className="xl:col-span-3" />}
        {show.planner && <PlannerPreview className="xl:col-span-5" />}
        {show.animals && <AnimalsPanel className="xl:col-span-2" />}
        {show.quick && <QuickAccessPanel className="xl:col-span-2" />}
      </div>

      <div className="stagger-fade grid grid-cols-1 gap-3.5 lg:grid-cols-2 xl:grid-cols-12">
        {show.notifications && <NotificationsPanel className="xl:col-span-3" />}
        {show.goals && <GoalsPanel className="xl:col-span-5" />}
        {show.reflection && <ReflectionPanel className="xl:col-span-4" />}
      </div>

      <div className="flex items-center justify-center gap-2.5 pt-1.5">
        <MascotAvatar name="betta" className="h-8 w-8" />
        <p className="hand text-center text-[1.02rem] text-ink-soft/80">
          two lives, three time zones, one shared dream · this little world is ours
        </p>
        <MascotAvatar name="parakeet" className="h-8 w-8" />
      </div>
    </div>
  );
};

export default Home;
