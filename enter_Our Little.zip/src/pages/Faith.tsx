import { useMemo, useState } from "react";
import {
  BookMarked,
  Check,
  Church,
  Flame,
  HandHeart,
  Heart,
  Lock,
  Plus,
  Sparkles,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { makeId, useUniverse } from "@/store/universe";
import { formatDateIn, relativeTime } from "@/lib/time";
import { PageHeading, Pill } from "@/components/kit/bits";
import { Panel, StickyNote } from "@/components/kit/panel";
import { EmptyState, SectionCard, SelectField, TextField, TextareaField } from "@/components/kit/controls";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import type { PersonId, Prayer } from "@/lib/types";

const CATEGORIES = [
  "Personal growth",
  "Family",
  "Studies & work",
  "Health & well-being",
  "Relationship",
  "Future plans",
  "Gratitude",
];

const STATUS_LABELS: Record<Prayer["status"], string> = {
  new: "New prayer",
  praying: "Praying together",
  updated: "Updated",
  answered: "Answered",
  continuing: "Continuing to pray",
  gratitude: "Gratitude / testimony",
};

const STATUS_TONES: Record<Prayer["status"], string> = {
  new: "bg-powder-soft text-ink",
  praying: "bg-sage-soft text-sage",
  updated: "bg-butter text-ink",
  answered: "bg-sage text-primary-foreground",
  continuing: "bg-lilac text-ink",
  gratitude: "bg-blush text-ink",
};

const FILTERS = [
  { id: "shared", label: "Shared" },
  { id: "new", label: "New" },
  { id: "praying", label: "Praying" },
  { id: "answered", label: "Answered" },
  { id: "private", label: "Mine only" },
] as const;

export default function Faith() {
  const { data, mutate } = useUniverse();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("shared");
  const [prayerDraft, setPrayerDraft] = useState<Prayer | null>(null);
  const [updateFor, setUpdateFor] = useState<{ prayer: Prayer; text: string } | null>(null);
  const [sessionDraft, setSessionDraft] = useState<{
    prayerId: string;
    scripture: string;
    intention: string;
  } | null>(null);
  const [reflectionDraft, setReflectionDraft] = useState<{ text: string; shared: boolean } | null>(null);
  const [intentionDraft, setIntentionDraft] = useState<{ title: string; note: string; period: string } | null>(
    null,
  );

  const prayers = useMemo(() => {
    const list = [...data.prayers].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (filter === "private") return list.filter((prayer) => prayer.visibility === "private");
    if (filter === "shared") return list.filter((prayer) => prayer.visibility === "shared");
    if (filter === "new") return list.filter((prayer) => ["new", "updated"].includes(prayer.status));
    if (filter === "praying") return list.filter((prayer) => ["praying", "continuing"].includes(prayer.status));
    return list.filter((prayer) => ["answered", "gratitude"].includes(prayer.status));
  }, [data.prayers, filter]);

  const openNewPrayer = () =>
    setPrayerDraft({
      id: makeId("prayer"),
      title: "",
      description: "",
      category: "Relationship",
      scripture: "",
      concern: "",
      status: "new",
      visibility: "shared",
      author: "you",
      createdAt: new Date().toISOString(),
      updates: [],
    });

  const savePrayer = () => {
    if (!prayerDraft || !prayerDraft.title.trim()) {
      toast("Give this prayer a title");
      return;
    }
    mutate((state) => {
      const exists = state.prayers.some((prayer) => prayer.id === prayerDraft.id);
      return {
        ...state,
        prayers: exists
          ? state.prayers.map((prayer) => (prayer.id === prayerDraft.id ? prayerDraft : prayer))
          : [prayerDraft, ...state.prayers],
      };
    });
    setPrayerDraft(null);
    toast("Held in prayer", { description: "You can add dated updates as this story unfolds." });
  };

  const addUpdate = () => {
    if (!updateFor || !updateFor.text.trim()) return;
    mutate((state) => ({
      ...state,
      prayers: state.prayers.map((prayer) =>
        prayer.id === updateFor.prayer.id
          ? {
              ...prayer,
              status: prayer.status === "new" ? "praying" : prayer.status,
              updates: [
                { id: makeId("pu"), date: new Date().toISOString(), text: updateFor.text },
                ...prayer.updates,
              ],
            }
          : prayer,
      ),
    }));
    setUpdateFor(null);
    toast("Update added", { description: "The original entry stays, so you keep the whole story." });
  };

  const setStatus = (prayerId: string, status: Prayer["status"]) =>
    mutate((state) => ({
      ...state,
      prayers: state.prayers.map((prayer) => (prayer.id === prayerId ? { ...prayer, status } : prayer)),
    }));

  const removePrayer = (prayer: Prayer) => {
    if (!window.confirm(`Remove “${prayer.title}” from the prayer list?`)) return;
    mutate((state) => ({ ...state, prayers: state.prayers.filter((item) => item.id !== prayer.id) }));
    toast("Removed from the list");
  };

  const saveSession = () => {
    if (!sessionDraft) return;
    mutate((state) => ({
      ...state,
      prayerSessions: [
        {
          id: makeId("session"),
          prayerId: sessionDraft.prayerId,
          date: new Date().toISOString(),
          scripture: sessionDraft.scripture,
          intentions: [{ person: "you" as PersonId, text: sessionDraft.intention }],
          completed: true,
        },
        ...state.prayerSessions,
      ],
    }));
    setSessionDraft(null);
    toast("Prayer session kept", { description: "A quiet little milestone in your history." });
  };

  const saveReflection = () => {
    if (!reflectionDraft || !reflectionDraft.text.trim()) return;
    mutate((state) => ({
      ...state,
      spiritualReflections: [
        {
          id: makeId("sr"),
          author: "you",
          date: new Date().toISOString(),
          text: reflectionDraft.text,
          shared: reflectionDraft.shared,
        },
        ...state.spiritualReflections,
      ],
    }));
    setReflectionDraft(null);
    toast("Reflection saved");
  };

  const sharedAnswered = data.prayers.filter((prayer) => prayer.status === "answered").length;

  return (
    <div className="flex flex-col gap-3.5">
      <PageHeading eyebrow="a quiet corner for two" title="Faith & Prayer" mascot="parakeet">
        <Button variant="note" size="sm" onClick={openNewPrayer}>
          <Plus className="h-3.5 w-3.5" /> New prayer
        </Button>
      </PageHeading>

      <div className="grid grid-cols-1 gap-3.5 xl:grid-cols-12">
        <div className="flex flex-col gap-3 xl:col-span-8">
          <p className="rounded-xl border border-dashed border-border/80 bg-card/60 px-3 py-1.5 text-[0.64rem] leading-snug text-muted-foreground">
            Add a prayer either of you is carrying, then keep the story: each update is dated underneath, and
            answered prayers stay as gratitude.
          </p>
          <div className="flex flex-wrap items-center gap-1.5">
            {FILTERS.map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => setFilter(option.id)}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[0.66rem] font-bold transition",
                  filter === option.id
                    ? "border-sage/50 bg-sage text-primary-foreground shadow-sm"
                    : "border-border/70 bg-card/80 text-muted-foreground hover:text-ink",
                )}
              >
                {option.label}
              </button>
            ))}
            <span className="ml-auto text-[0.62rem] font-semibold text-muted-foreground">
              {sharedAnswered} answered · kept as testimony
            </span>
          </div>

          {prayers.length === 0 ? (
            <SectionCard title="Nothing here yet">
              <EmptyState
                mascot="parakeet"
                title="A quiet, open page"
                note="Write the first thing you're carrying, and we'll keep it here together."
                action={
                  <Button size="sm" variant="note" onClick={openNewPrayer}>
                    <Plus className="h-3 w-3" /> Add a prayer
                  </Button>
                }
              />
            </SectionCard>
          ) : (
            <div className="grid grid-cols-1 gap-3.5 md:grid-cols-2">
              {prayers.map((prayer) => (
                <section
                  key={prayer.id}
                  className={cn(
                    "paper-card grain flex flex-col gap-1.5 p-3.5",
                    prayer.status === "answered" && "bg-sage-soft/60",
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-[0.92rem] font-bold leading-tight">{prayer.title}</p>
                      <p className="mt-0.5 text-[0.58rem] font-semibold uppercase tracking-wide text-muted-foreground">
                        {prayer.category} · {formatDateIn(new Date(prayer.createdAt), "UTC")}
                      </p>
                    </div>
                    {prayer.visibility === "private" ? (
                      <Pill tone="peach" className="shrink-0">
                        <Lock className="h-2.5 w-2.5" /> mine
                      </Pill>
                    ) : (
                      <Pill tone="sage" className="shrink-0">
                        shared
                      </Pill>
                    )}
                  </div>

                  <p className="font-read text-[0.76rem] leading-snug text-ink-soft">{prayer.description}</p>

                  {prayer.scripture && (
                    <p className="inline-flex items-center gap-1 text-[0.64rem] font-semibold text-sage">
                      <BookMarked className="h-3 w-3" aria-hidden /> {prayer.scripture}
                    </p>
                  )}
                  {prayer.concern && (
                    <p className="text-[0.6rem] text-muted-foreground">For: {prayer.concern}</p>
                  )}

                  <div className="flex flex-wrap items-center gap-1">
                    <span
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[0.56rem] font-bold uppercase tracking-wide",
                        STATUS_TONES[prayer.status],
                      )}
                    >
                      {STATUS_LABELS[prayer.status]}
                    </span>
                    <span className="text-[0.56rem] text-muted-foreground">
                      {prayer.updates.length} update{prayer.updates.length === 1 ? "" : "s"}
                    </span>
                  </div>

                  {prayer.updates.length > 0 && (
                    <ol className="mt-0.5 space-y-1 border-l border-dashed border-border pl-2">
                      {prayer.updates.slice(0, 2).map((update) => (
                        <li key={update.id} className="text-[0.64rem] leading-snug text-ink-soft">
                          <span className="font-bold text-muted-foreground">
                            {formatDateIn(new Date(update.date), "UTC")} ·{" "}
                          </span>
                          {update.text}
                        </li>
                      ))}
                    </ol>
                  )}

                  <div className="mt-auto flex flex-wrap items-center gap-1 pt-1.5">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 px-2 text-[0.62rem]"
                      onClick={() => setUpdateFor({ prayer, text: "" })}
                    >
                      <Plus className="h-3 w-3" /> Update
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 px-2 text-[0.62rem]"
                      onClick={() => {
                        setSessionDraft({
                          prayerId: prayer.id,
                          scripture: prayer.scripture ?? "",
                          intention: "",
                        });
                      }}
                    >
                      <Church className="h-3 w-3" /> Pray now
                    </Button>
                    <select
                      value={prayer.status}
                      aria-label={`Status for ${prayer.title}`}
                      onChange={(event) => setStatus(prayer.id, event.target.value as Prayer["status"])}
                      className="h-7 rounded-full border border-border bg-card px-2 text-[0.6rem] font-semibold"
                    >
                      {Object.entries(STATUS_LABELS).map(([value, label]) => (
                        <option key={value} value={value}>
                          {label}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => removePrayer(prayer)}
                      aria-label={`Remove ${prayer.title}`}
                      className="ml-auto grid h-7 w-7 place-items-center rounded-full text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </section>
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-col gap-3 xl:col-span-4">
          <Panel
            title="This week's intention"
            icon={<Flame className="h-3.5 w-3.5 text-coral" aria-hidden />}
            action={
              <button
                type="button"
                onClick={() => setIntentionDraft({ title: "", note: "", period: "This week" })}
                className="inline-flex items-center gap-0.5 hover:text-sage"
              >
                <Plus className="h-3 w-3" /> Add
              </button>
            }
          >
            {data.intentions.length === 0 && (
              <p className="rounded-xl border border-dashed border-border/80 bg-card/60 px-2 py-2 text-[0.62rem] leading-snug text-muted-foreground">
                No intention set. Pick one small thing to practise together this week — patience, gratitude, rest.
              </p>
            )}
            <ul className="flex flex-col gap-2">
              {data.intentions.map((intention) => (
                <li key={intention.id} className="rounded-xl bg-butter-soft/70 p-2">
                  <p className="text-[0.74rem] font-bold leading-tight">{intention.title}</p>
                  <p className="mt-0.5 text-[0.64rem] leading-snug text-ink-soft">{intention.note}</p>
                  <div className="mt-1 flex items-center justify-between gap-2">
                    <span className="text-[0.56rem] font-semibold uppercase tracking-wide text-muted-foreground">
                      {intention.period}
                    </span>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 px-1.5 text-[0.58rem]"
                      onClick={() =>
                        mutate((state) => ({
                          ...state,
                          intentions: state.intentions.map((item) =>
                            item.id === intention.id
                              ? {
                                  ...item,
                                  practiced: [
                                    { person: "you" as PersonId, text: "Noticed it again today." },
                                    ...item.practiced,
                                  ],
                                }
                              : item,
                          ),
                        }))
                      }
                    >
                      <Check className="h-2.5 w-2.5" /> I practised this
                    </Button>
                  </div>
                  {intention.practiced.length > 0 && (
                    <p className="mt-1 text-[0.58rem] text-sage">
                      {intention.practiced.length} little moment
                      {intention.practiced.length === 1 ? "" : "s"} noticed
                    </p>
                  )}
                </li>
              ))}
            </ul>
          </Panel>

          <Panel
            title="Prayer together"
            icon={<Church className="h-3.5 w-3.5 text-sage" aria-hidden />}
            action={<span>{data.prayerSessions.length} kept</span>}
          >
            {data.prayerSessions.length === 0 ? (
              <EmptyState title="No sessions yet" note="Choose a prayer and pray it side by side, even apart." />
            ) : (
              <ul className="flex flex-col gap-1.5">
                {data.prayerSessions.slice(0, 3).map((session) => {
                  const prayer = data.prayers.find((item) => item.id === session.prayerId);
                  return (
                    <li key={session.id} className="rounded-lg bg-muted/50 px-2 py-1.5">
                      <p className="text-[0.68rem] font-bold">{prayer?.title ?? "A prayer"}</p>
                      <p className="text-[0.6rem] text-muted-foreground">
                        {formatDateIn(new Date(session.date), "UTC")} · {session.scripture || "no verse noted"} ·{" "}
                        {session.completed ? "completed" : "in progress"}
                      </p>
                    </li>
                  );
                })}
              </ul>
            )}
          </Panel>

          <Panel
            title="Spiritual reflections"
            icon={<Sparkles className="h-3.5 w-3.5 text-sage" aria-hidden />}
            action={
              <button
                type="button"
                onClick={() => setReflectionDraft({ text: "", shared: false })}
                className="inline-flex items-center gap-0.5 hover:text-sage"
              >
                <Plus className="h-3 w-3" /> Write
              </button>
            }
          >
            {data.spiritualReflections.length === 0 && (
              <p className="rounded-xl border border-dashed border-border/80 bg-card/60 px-2 py-2 text-[0.62rem] leading-snug text-muted-foreground">
                Nothing written yet. A reflection can be one honest sentence, kept private until you choose to share it.
              </p>
            )}
            <ul className="flex flex-col gap-1.5">
              {data.spiritualReflections.map((reflection) => {
                const mine = reflection.author === "me";
                if (reflection.shared === false && !mine) return null;
                return (
                  <li key={reflection.id} className="rounded-lg bg-card/70 p-2 shadow-sm">
                    <p className="font-read text-[0.7rem] leading-snug text-ink-soft">{reflection.text}</p>
                    <p className="mt-1 flex items-center gap-1 text-[0.54rem] font-bold text-muted-foreground">
                      {reflection.shared ? <Heart className="h-2.5 w-2.5" /> : <Lock className="h-2.5 w-2.5" />}
                      {reflection.author === "you" ? data.people.you.nickname : data.people.me.nickname} ·{" "}
                      {relativeTime(reflection.date)} · {reflection.shared ? "shared" : "private"}
                    </p>
                  </li>
                );
              })}
            </ul>
          </Panel>

          <StickyNote tone="butter" className="mx-auto w-[85%] rotate-[-1deg]">
            an answered prayer is a testimony, not a deadline.
          </StickyNote>
        </div>
      </div>

      <Dialog open={Boolean(prayerDraft)} onOpenChange={(open) => !open && setPrayerDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A prayer to carry together</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Updates will stack underneath, so you keep the whole story.
            </DialogDescription>
          </DialogHeader>
          {prayerDraft && (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <TextField
                label="Title"
                value={prayerDraft.title}
                onChange={(event) => setPrayerDraft({ ...prayerDraft, title: event.target.value })}
                className="sm:col-span-2"
                placeholder="Navi's thesis defense"
              />
              <TextareaField
                label="What are we asking for?"
                value={prayerDraft.description}
                onChange={(event) =>
                  setPrayerDraft({ ...prayerDraft, description: event.target.value })
                }
                className="sm:col-span-2"
              />
              <SelectField
                label="Category"
                value={prayerDraft.category}
                onChange={(value) => setPrayerDraft({ ...prayerDraft, category: value })}
                options={CATEGORIES.map((category) => ({ value: category, label: category }))}
              />
              <TextField
                label="Scripture (optional)"
                value={prayerDraft.scripture ?? ""}
                onChange={(event) => setPrayerDraft({ ...prayerDraft, scripture: event.target.value })}
                placeholder="Philippians 4:6-7"
              />
              <TextField
                label="Who is it for? (optional)"
                value={prayerDraft.concern ?? ""}
                onChange={(event) => setPrayerDraft({ ...prayerDraft, concern: event.target.value })}
              />
              <SelectField
                label="Who can see it?"
                value={prayerDraft.visibility}
                onChange={(value) =>
                  setPrayerDraft({ ...prayerDraft, visibility: value as Prayer["visibility"] })
                }
                options={[
                  { value: "shared", label: "Shared with my partner" },
                  { value: "private", label: "Private to me only" },
                ]}
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setPrayerDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={savePrayer}>
              Keep this prayer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(updateFor)} onOpenChange={(open) => !open && setUpdateFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">An update on {updateFor?.prayer.title}</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Dated, added underneath — the original entry stays untouched.
            </DialogDescription>
          </DialogHeader>
          {updateFor && (
            <TextareaField
              label="What has changed?"
              value={updateFor.text}
              onChange={(event) => setUpdateFor({ ...updateFor, text: event.target.value })}
              placeholder="The results came back clear…"
            />
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setUpdateFor(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={addUpdate}>
              Add update
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(sessionDraft)} onOpenChange={(open) => !open && setSessionDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">Pray together, from two places</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Keep it short. A verse, an intention, a quiet amen.
            </DialogDescription>
          </DialogHeader>
          {sessionDraft && (
            <div className="space-y-2.5">
              <SelectField
                label="Which prayer?"
                value={sessionDraft.prayerId}
                onChange={(value) => setSessionDraft({ ...sessionDraft, prayerId: value })}
                options={data.prayers.map((prayer) => ({ value: prayer.id, label: prayer.title }))}
              />
              <TextField
                label="Scripture (optional)"
                value={sessionDraft.scripture}
                onChange={(event) => setSessionDraft({ ...sessionDraft, scripture: event.target.value })}
              />
              <TextareaField
                label="Your intention"
                value={sessionDraft.intention}
                onChange={(event) => setSessionDraft({ ...sessionDraft, intention: event.target.value })}
                placeholder="That I would speak with grace."
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setSessionDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={saveSession}>
              <Church className="h-3.5 w-3.5" /> Mark as prayed
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(reflectionDraft)} onOpenChange={(open) => !open && setReflectionDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A private thought, if you want one</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Private reflections stay with you unless you choose to share them.
            </DialogDescription>
          </DialogHeader>
          {reflectionDraft && (
            <div className="space-y-2.5">
              <TextareaField
                label="Your reflection"
                value={reflectionDraft.text}
                onChange={(event) => setReflectionDraft({ ...reflectionDraft, text: event.target.value })}
              />
              <label className="flex items-center gap-2 text-[0.72rem] font-semibold">
                <input
                  type="checkbox"
                  checked={reflectionDraft.shared}
                  onChange={(event) =>
                    setReflectionDraft({ ...reflectionDraft, shared: event.target.checked })
                  }
                  className="h-4 w-4 rounded border-border accent-[hsl(var(--sage))]"
                />
                Share this one with {data.people.me.nickname}
              </label>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setReflectionDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={saveReflection}>
              Save reflection
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(intentionDraft)} onOpenChange={(open) => !open && setIntentionDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A gentle intention</DialogTitle>
          </DialogHeader>
          {intentionDraft && (
            <div className="space-y-2.5">
              <TextField
                label="Intention"
                value={intentionDraft.title}
                onChange={(event) => setIntentionDraft({ ...intentionDraft, title: event.target.value })}
                placeholder="Patience with our time zones"
              />
              <TextareaField
                label="How we'll practise it"
                value={intentionDraft.note}
                onChange={(event) => setIntentionDraft({ ...intentionDraft, note: event.target.value })}
              />
              <SelectField
                label="Period"
                value={intentionDraft.period}
                onChange={(value) => setIntentionDraft({ ...intentionDraft, period: value })}
                options={[
                  { value: "This week", label: "This week" },
                  { value: "This month", label: "This month" },
                ]}
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setIntentionDraft(null)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={() => {
                if (!intentionDraft?.title.trim()) return;
                mutate((state) => ({
                  ...state,
                  intentions: [
                    { id: makeId("int"), ...intentionDraft, practiced: [] },
                    ...state.intentions,
                  ],
                }));
                setIntentionDraft(null);
                toast("Intention added");
              }}
            >
              Add intention
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
