import { useState } from "react";
import {
  CalendarClock,
  Check,
  Heart,
  Lock,
  MessageCircleHeart,
  Send,
  Sparkles,
  Smile,
} from "lucide-react";
import { toast } from "sonner";
import { makeId, useUniverse } from "@/store/universe";
import { formatDateIn, relativeTime } from "@/lib/time";
import { PageHeading, MascotAvatar, Pill } from "@/components/kit/bits";
import { Panel, StickyNote } from "@/components/kit/panel";
import { EmptyState, SectionCard, SelectField, TextField, TextareaField } from "@/components/kit/controls";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import type { MoodCheck, PersonId } from "@/lib/types";

const MOODS = [
  "Happy and energized",
  "Peaceful and content",
  "Missing you",
  "Stressed and overwhelmed",
  "Sad or discouraged",
  "Need some quiet time",
  "Need extra care",
  "Not sure how I feel yet",
];

const NEEDS = [
  "I would love to talk",
  "I need reassurance",
  "I could use some encouragement",
  "I need quality time",
  "I need some space",
  "I am okay, just checking in",
];

const GENTLE_RESPONSES = [
  "Take your time. I'm here.",
  "Would you like to talk about it?",
  "Sending you a little encouragement.",
  "Let's find a time for us.",
];

const needTone = (need: string) => {
  if (need.startsWith("I need some space")) return "peach" as const;
  if (need.startsWith("I need quality")) return "butter" as const;
  if (need.startsWith("I need reassurance")) return "blush" as const;
  return "powder" as const;
};

export default function StayingClose() {
  const { data, mutate } = useUniverse();
  const [draft, setDraft] = useState<MoodCheck | null>(null);
  const [noteDraft, setNoteDraft] = useState<{ text: string; revealOn: string } | null>(null);

  const latestFor = (person: PersonId) =>
    data.moods
      .filter((mood) => mood.person === person)
      .sort((a, b) => b.date.localeCompare(a.date))[0];

  const youMood = latestFor("you");
  const meMood = latestFor("me");
  const today = new Date().toISOString().slice(0, 10);

  const openCheckIn = (person: PersonId) => {
    const existing = latestFor(person);
    setDraft(
      existing
        ? { ...existing }
        : {
            id: makeId("mood"),
            person,
            mood: "Peaceful and content",
            note: "",
            need: "I'm okay, just checking in",
            needNote: "",
            date: new Date().toISOString(),
          },
    );
  };

  const saveMood = () => {
    if (!draft) return;
    mutate((state) => {
      const stamped = { ...draft, date: new Date().toISOString() };
      return {
        ...state,
        moods: [{ ...stamped, id: makeId("mood") }, ...state.moods].sort((a, b) =>
          b.date.localeCompare(a.date),
        ),
      };
    });
    setDraft(null);
    toast("Check-in saved", { description: "Shared gently — no pressure to reply right away." });
  };

  const saveNote = () => {
    if (!noteDraft || !noteDraft.text.trim()) {
      toast("A note needs a few words first");
      return;
    }
    mutate((state) => ({
      ...state,
      loveNotes: [
        {
          id: makeId("note"),
          from: "you",
          text: noteDraft.text,
          createdAt: new Date().toISOString(),
          revealOn: noteDraft.revealOn || undefined,
        },
        ...state.loveNotes,
      ],
    }));
    setNoteDraft(null);
    toast(noteDraft.revealOn ? "Sealed until that day" : "Note delivered by parakeet");
  };

  const sendResponse = (text: string) => {
    mutate((state) => ({
      ...state,
      loveNotes: [
        {
          id: makeId("note"),
          from: "you",
          text,
          createdAt: new Date().toISOString(),
        },
        ...state.loveNotes,
      ],
    }));
    toast("Sent with a little heart");
  };

  const recent = [...data.moods].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);

  return (
    <div className="flex flex-col gap-3.5">
      <PageHeading eyebrow="soft landings only" title="Staying Close" mascot="orange">
        <Button variant="note" size="sm" onClick={() => openCheckIn("you")}>
          <Smile className="h-3.5 w-3.5" /> How am I today?
        </Button>
        <Button variant="soft" size="sm" onClick={() => setNoteDraft({ text: "", revealOn: "" })}>
          <Send className="h-3.5 w-3.5" /> Leave a note
        </Button>
      </PageHeading>

      <div className="grid grid-cols-1 gap-3.5 lg:grid-cols-2">
        {(["you", "me"] as PersonId[]).map((personId) => {
          const person = data.people[personId];
          const mood = personId === "you" ? youMood : meMood;
          const isMine = personId === "you";
          return (
            <Panel
              key={personId}
              title={person.name}
              icon={<MessageCircleHeart className="h-3.5 w-3.5 text-sage" aria-hidden />}
              action={
                mood?.date.slice(0, 10) === today ? (
                  <span className="inline-flex items-center gap-1 text-sage">
                    <Check className="h-3 w-3" /> checked in
                  </span>
                ) : (
                  "not yet today"
                )
              }
              tint="cream"
            >
              <div className="flex items-start gap-2.5">
                <MascotAvatar name={person.companion} className="h-11 w-11" />
                <div className="min-w-0 flex-1">
                  {mood ? (
                    <>
                      <p className="hand text-[1.25rem] leading-tight text-sage">{mood.mood}</p>
                      {mood.note && (
                        <p className="mt-0.5 font-read text-[0.78rem] leading-snug text-ink-soft">
                          “{mood.note}”
                        </p>
                      )}
                      <div className="mt-1.5 flex flex-wrap items-center gap-1">
                        <Pill tone={needTone(mood.need)}>
                          <Heart className="h-2.5 w-2.5" aria-hidden /> {mood.need}
                        </Pill>
                        <span className="text-[0.58rem] text-muted-foreground">{relativeTime(mood.date)}</span>
                      </div>
                      {mood.needNote && (
                        <p className="mt-1 text-[0.66rem] text-muted-foreground">{mood.needNote}</p>
                      )}
                    </>
                  ) : (
                    <EmptyState
                      mascot={person.companion}
                      title="No check-in yet"
                      note="Tap below to say how today feels — one small honest sentence is enough."
                    />
                  )}
                </div>
              </div>

              {isMine ? (
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2.5 w-full"
                  onClick={() => openCheckIn("you")}
                >
                  <Smile className="h-3.5 w-3.5" /> Update today&apos;s check-in
                </Button>
              ) : (
                <div className="mt-2.5">
                  <p className="mb-1 text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted-foreground">
                    A gentle reply
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {GENTLE_RESPONSES.map((response) => (
                      <button
                        key={response}
                        type="button"
                        onClick={() => sendResponse(response)}
                        className="rounded-full border border-border/80 bg-card px-2 py-1 text-[0.62rem] font-semibold text-ink-soft transition hover:-translate-y-px hover:bg-sage-soft hover:text-sage"
                      >
                        {response}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </Panel>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-3.5 xl:grid-cols-12">
        <SectionCard
          className="xl:col-span-8"
          title="Little love notes"
          subtitle="Short notes, reminders, or something to open on a harder day."
          action={
            <Button size="sm" variant="note" onClick={() => setNoteDraft({ text: "", revealOn: "" })}>
              <Send className="h-3 w-3" /> Write one
            </Button>
          }
        >
          <ul className="grid grid-cols-1 gap-2.5 md:grid-cols-2">
            {data.loveNotes.map((note, index) => {
              const sealed = note.revealOn ? note.revealOn > today : false;
              return (
                <li
                  key={note.id}
                  className={cn(
                    "grain relative rounded-xl border border-border/70 p-3 shadow-sm",
                    index % 3 === 0 && "bg-butter-soft",
                    index % 3 === 1 && "bg-blush",
                    index % 3 === 2 && "bg-powder-soft",
                  )}
                >
                  <div className="mb-1 flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1 text-[0.62rem] font-bold text-ink-soft">
                      <MascotAvatar
                        name={note.from === "me" ? data.people.me.companion : data.people.you.companion}
                        className="h-4 w-4"
                      />
                      from {note.from === "me" ? data.people.me.nickname : data.people.you.nickname}
                    </span>
                    <span className="text-[0.54rem] font-semibold text-muted-foreground">
                      {relativeTime(note.createdAt)}
                    </span>
                  </div>
                  {sealed ? (
                    <div className="flex items-start gap-1.5 text-ink-soft">
                      <Lock className="mt-0.5 h-3 w-3 shrink-0" aria-hidden />
                      <p className="text-[0.72rem] leading-snug">
                        Sealed until {formatDateIn(new Date(note.revealOn!), "UTC", true)} — a little patience,
                        love.
                      </p>
                    </div>
                  ) : (
                    <p className="font-read text-[0.78rem] leading-snug text-ink/85">{note.text}</p>
                  )}
                </li>
              );
            })}
          </ul>
          {data.loveNotes.length === 0 && (
            <EmptyState title="The board is waiting" note="One kind sentence is enough to begin." />
          )}
        </SectionCard>

        <div className="flex flex-col gap-3 xl:col-span-4">
          <Panel title="Recently felt" icon={<Sparkles className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <ul className="flex flex-col gap-1.5">
              {recent.map((mood) => (
                <li
                  key={mood.id}
                  className="flex items-center justify-between gap-2 rounded-lg bg-muted/50 px-2 py-1.5"
                >
                  <div className="min-w-0">
                    <p className="truncate text-[0.68rem] font-bold">
                      {mood.person === "you" ? data.people.you.nickname : data.people.me.nickname} · {mood.mood}
                    </p>
                    <p className="truncate text-[0.58rem] text-muted-foreground">{mood.need}</p>
                  </div>
                  <span className="shrink-0 text-[0.54rem] text-muted-foreground">
                    {relativeTime(mood.date)}
                  </span>
                </li>
              ))}
            </ul>
          </Panel>

          <StickyNote tone="sage" className="mx-auto w-[88%] rotate-[1.5deg]">
            moods are information, not accusations.
          </StickyNote>

          <Panel title="Private by design" icon={<Lock className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <p className="text-[0.7rem] leading-snug text-muted-foreground">
              Check-ins are always optional and never read as anger. Anything you mark private stays with you —
              your partner simply sees that you checked in.
            </p>
          </Panel>
        </div>
      </div>

      <Dialog open={Boolean(draft)} onOpenChange={(open) => !open && setDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">How is your heart today?</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              No score, no streak. Just a small honest sentence.
            </DialogDescription>
          </DialogHeader>
          {draft && (
            <div className="space-y-2.5">
              <SelectField
                label="Mood"
                value={MOODS.includes(draft.mood) ? draft.mood : "custom"}
                onChange={(value) =>
                  setDraft({ ...draft, mood: value === "custom" ? "" : value })
                }
                options={[
                  ...MOODS.map((mood) => ({ value: mood, label: mood })),
                  { value: "custom", label: "Something else (write it below)" },
                ]}
              />
              {!MOODS.includes(draft.mood) && (
                <TextField
                  label="Your own words"
                  value={draft.mood}
                  onChange={(event) => setDraft({ ...draft, mood: event.target.value })}
                  placeholder="A little tired but hopeful"
                />
              )}
              <TextareaField
                label="A sentence about it (optional)"
                value={draft.note}
                onChange={(event) => setDraft({ ...draft, note: event.target.value })}
              />
              <SelectField
                label="What I need today"
                value={draft.need}
                onChange={(value) => setDraft({ ...draft, need: value })}
                options={NEEDS.map((need) => ({ value: need, label: need }))}
              />
              <TextField
                label="Anything else they should know? (optional)"
                value={draft.needNote}
                onChange={(event) => setDraft({ ...draft, needNote: event.target.value })}
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setDraft(null)}>
              Not now
            </Button>
            <Button size="sm" onClick={saveMood}>
              Share gently
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(noteDraft)} onOpenChange={(open) => !open && setNoteDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A little note for {data.people.me.nickname}</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Keep it warm and short. You can choose a day for it to appear.
            </DialogDescription>
          </DialogHeader>
          {noteDraft && (
            <div className="space-y-2.5">
              <TextareaField
                label="Your note"
                value={noteDraft.text}
                onChange={(event) => setNoteDraft({ ...noteDraft, text: event.target.value })}
                placeholder="I'm proud of you…"
              />
              <TextField
                label="Reveal on a future day (optional)"
                type="date"
                value={noteDraft.revealOn}
                onChange={(event) => setNoteDraft({ ...noteDraft, revealOn: event.target.value })}
                hint="Leave empty to deliver it now."
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setNoteDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={saveNote}>
              <CalendarClock className="h-3.5 w-3.5" />
              {noteDraft?.revealOn ? "Seal this note" : "Send it now"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
