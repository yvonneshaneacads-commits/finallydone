import { useState } from "react";
import {
  ArrowRight,
  Calculator,
  Check,
  Coins,
  Copy,
  PiggyBank,
  Plus,
  ReceiptText,
  Sparkles,
  Target,
  Trash2,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { makeId, useUniverse } from "@/store/universe";
import { currency, monthLabel } from "@/lib/time";
import { PageHeading, MascotAvatar, SoftProgress } from "@/components/kit/bits";
import { Panel, StickyNote } from "@/components/kit/panel";
import { EmptyState, SectionCard, SelectField, TextField, TextareaField } from "@/components/kit/controls";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import type { Goal, PersonId, Trip } from "@/lib/types";

const ACCENTS: Goal["accent"][] = ["sage", "powder", "blush", "butter", "peach", "lilac"];

const accentSurface: Record<Goal["accent"], string> = {
  sage: "bg-sage-soft",
  powder: "bg-powder-soft",
  blush: "bg-blush",
  butter: "bg-butter-soft",
  peach: "bg-peach-soft",
  lilac: "bg-lilac",
};

function tripTotal(trip: Trip) {
  const base =
    trip.airfare * trip.travelers +
    trip.lodging * trip.days +
    trip.transport * trip.days +
    trip.food * trip.days * trip.travelers +
    trip.activities +
    trip.documents;
  return Math.round(base * (1 + trip.bufferPct / 100));
}

const AGENDA = [
  { key: "well", label: "What went well financially this month?" },
  { key: "saved", label: "What did we save or accomplish?" },
  { key: "surprise", label: "What expenses surprised us?" },
  { key: "adjust", label: "What should we adjust?" },
  { key: "learned", label: "What did we learn?" },
  { key: "priority", label: "What is our next financial priority?" },
];

export default function Money() {
  const { data, mutate } = useUniverse();
  const [activeTripId, setActiveTripId] = useState(data.trips[0]?.id ?? "");
  const trip = data.trips.find((item) => item.id === activeTripId) ?? data.trips[0];
  const [goalDraft, setGoalDraft] = useState<{
    title: string;
    subtitle: string;
    target: string;
    targetDate: string;
    accent: Goal["accent"];
  } | null>(null);
  const [contributionDraft, setContributionDraft] = useState<{
    goalId: string;
    person: PersonId;
    amount: string;
    note: string;
  } | null>(null);
  const [actionDraft, setActionDraft] = useState<{ person: PersonId; text: string; due: string } | null>(null);

  const talk = data.moneyTalks[0];
  const [talkAnswers, setTalkAnswers] = useState<Record<string, string>>(talk?.answers ?? {});

  const total = trip ? tripTotal(trip) : 0;
  const saved = data.goals[0]?.contributions.reduce((sum, c) => sum + c.amount, 0) ?? 0;
  const remaining = Math.max(0, total - saved);
  const monthly = trip?.monthly ?? 0;
  const monthsNeeded = monthly > 0 ? Math.ceil(remaining / monthly) : 0;
  const eta = new Date();
  eta.setMonth(eta.getMonth() + monthsNeeded);

  const patchTrip = (patch: Partial<Trip>) => {
    if (!trip) return;
    mutate((state) => ({
      ...state,
      trips: state.trips.map((item) => (item.id === trip.id ? { ...item, ...patch } : item)),
    }));
  };

  const addTrip = () => {
    const draft: Trip = {
      id: makeId("trip"),
      name: "Our first trip",
      from: `${data.people.you.city}, ${data.people.you.country}`,
      to: `${data.people.me.city}, ${data.people.me.country}`,
      currency: "PHP",
      exchangeRateLabel: "Manual rate — edit with your own",
      days: 7,
      travelers: 1,
      airfare: 0,
      lodging: 0,
      transport: 0,
      food: 0,
      activities: 0,
      documents: 0,
      bufferPct: 10,
      saved: 0,
      monthly: 0,
    };
    mutate((state) => ({ ...state, trips: [...state.trips, draft] }));
    setActiveTripId(draft.id);
    toast("Trip estimate started", { description: "Fill in your own numbers — nothing is guessed for you." });
  };

  const addGoal = () => {
    if (!goalDraft || !goalDraft.title.trim()) {
      toast("Name the goal first");
      return;
    }
    mutate((state) => ({
      ...state,
      goals: [
        ...state.goals,
        {
          id: makeId("goal"),
          title: goalDraft.title,
          subtitle: goalDraft.subtitle,
          target: Number(goalDraft.target) || 0,
          targetDate: goalDraft.targetDate,
          accent: goalDraft.accent,
          contributions: [],
        },
      ],
    }));
    setGoalDraft(null);
    toast("A new shared goal is born");
  };

  const addContribution = () => {
    if (!contributionDraft) return;
    const amount = Number(contributionDraft.amount);
    if (!amount || amount <= 0) {
      toast("Enter an amount above zero");
      return;
    }
    mutate((state) => ({
      ...state,
      goals: state.goals.map((goal) =>
        goal.id === contributionDraft.goalId
          ? {
              ...goal,
              contributions: [
                {
                  id: makeId("contrib"),
                  person: contributionDraft.person,
                  amount,
                  date: new Date().toISOString().slice(0, 10),
                  note: contributionDraft.note,
                },
                ...goal.contributions,
              ],
            }
          : goal,
      ),
    }));
    setContributionDraft(null);
    toast("Contribution added", { description: "Progress recalculated right away." });
  };

  return (
    <div className="flex flex-col gap-3.5">
      <PageHeading eyebrow="building wisely, together" title="Money & Future" mascot="betta">
        <Button variant="soft" size="sm" onClick={addTrip}>
          <Calculator className="h-3.5 w-3.5" /> New trip
        </Button>
        <Button
          variant="soft"
          size="sm"
          onClick={() => setGoalDraft({ title: "", subtitle: "", target: "20000", targetDate: new Date(Date.now() + 86400000 * 300).toISOString().slice(0, 10), accent: "sage" })}
        >
          <Plus className="h-3.5 w-3.5" /> New goal
        </Button>
        <Button
          variant="note"
          size="sm"
          onClick={() =>
            setContributionDraft({
              goalId: data.goals[0]?.id ?? "",
              person: "you",
              amount: "",
              note: "",
            })
          }
          disabled={data.goals.length === 0}
        >
          <Coins className="h-3.5 w-3.5" /> Add savings
        </Button>
      </PageHeading>

      <div className="grid grid-cols-1 gap-3.5 xl:grid-cols-12">
        <SectionCard
          className="xl:col-span-7"
          title="Visit fund calculator"
          subtitle="Our own estimates, clearly labelled — never invented flight prices."
          action={
            <div className="flex items-center gap-1">
              {data.trips.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTripId(item.id)}
                  className={cn(
                    "rounded-full border px-2 py-0.5 text-[0.6rem] font-bold",
                    trip?.id === item.id
                      ? "border-sage/50 bg-sage-soft text-sage"
                      : "border-border bg-card text-muted-foreground",
                  )}
                >
                  {item.name.split(",")[0]}
                </button>
              ))}
            </div>
          }
        >
          {!trip ? (
            <EmptyState
              mascot="betta"
              title="No trip estimate yet"
              note="Start one, then type your own airfare, stay and spending. Nothing here is invented — the totals just add up and tell you what to save each month."
              action={
                <Button size="sm" variant="note" className="mt-1" onClick={addTrip}>
                  <Plus className="h-3 w-3" /> Start a trip estimate
                </Button>
              }
            />
          ) : (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <TextField
                  label="Travellers"
                  type="number"
                  min={1}
                  value={trip.travelers}
                  onChange={(event) => patchTrip({ travelers: Math.max(1, Number(event.target.value)) })}
                />
                <TextField
                  label="Days"
                  type="number"
                  min={1}
                  value={trip.days}
                  onChange={(event) => patchTrip({ days: Math.max(1, Number(event.target.value)) })}
                />
                <TextField
                  label="Currency"
                  value={trip.currency}
                  onChange={(event) => patchTrip({ currency: event.target.value.toUpperCase() })}
                />
                <TextField
                  label="Buffer %"
                  type="number"
                  min={0}
                  value={trip.bufferPct}
                  onChange={(event) => patchTrip({ bufferPct: Math.max(0, Number(event.target.value)) })}
                />
              </div>

              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                <TextField
                  label="Airfare / traveller"
                  type="number"
                  value={trip.airfare}
                  onChange={(event) => patchTrip({ airfare: Number(event.target.value) })}
                />
                <TextField
                  label="Stay / night"
                  type="number"
                  value={trip.lodging}
                  onChange={(event) => patchTrip({ lodging: Number(event.target.value) })}
                />
                <TextField
                  label="Local transport / day"
                  type="number"
                  value={trip.transport}
                  onChange={(event) => patchTrip({ transport: Number(event.target.value) })}
                />
                <TextField
                  label="Food / day / person"
                  type="number"
                  value={trip.food}
                  onChange={(event) => patchTrip({ food: Number(event.target.value) })}
                />
                <TextField
                  label="Activities (total)"
                  type="number"
                  value={trip.activities}
                  onChange={(event) => patchTrip({ activities: Number(event.target.value) })}
                />
                <TextField
                  label="Documents & fees"
                  type="number"
                  value={trip.documents}
                  onChange={(event) => patchTrip({ documents: Number(event.target.value) })}
                />
              </div>

              <TextField
                label="Exchange rate note"
                value={trip.exchangeRateLabel}
                onChange={(event) => patchTrip({ exchangeRateLabel: event.target.value })}
                hint="Manual rates stay editable and are labelled as ours, not live data."
              />

              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                <div className="rounded-xl bg-sage-soft/70 p-2">
                  <p className="text-[0.58rem] font-bold uppercase tracking-wide text-sage">Saved in visit fund</p>
                  <p className="text-[0.9rem] font-bold tabular-nums">{currency(saved, trip.currency)}</p>
                </div>
                <TextField
                  label="Monthly together"
                  type="number"
                  value={trip.monthly}
                  onChange={(event) => patchTrip({ monthly: Number(event.target.value) })}
                />
                <div className="rounded-xl bg-sage-soft/70 p-2">
                  <p className="text-[0.58rem] font-bold uppercase tracking-wide text-sage">Reach goal by</p>
                  <p className="text-[0.8rem] font-bold">
                    {monthsNeeded > 0
                      ? eta.toLocaleDateString("en-US", { month: "short", year: "numeric" })
                      : "already there"}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 rounded-xl border border-border/70 bg-butter-soft/60 p-2.5 sm:grid-cols-4">
                <div>
                  <p className="text-[0.56rem] font-bold uppercase tracking-wide text-muted-foreground">Estimated total</p>
                  <p className="text-[1rem] font-bold">{currency(total, trip.currency)}</p>
                </div>
                <div>
                  <p className="text-[0.56rem] font-bold uppercase tracking-wide text-muted-foreground">Saved</p>
                  <p className="text-[1rem] font-bold text-sage">{currency(saved, trip.currency)}</p>
                </div>
                <div>
                  <p className="text-[0.56rem] font-bold uppercase tracking-wide text-muted-foreground">Still needed</p>
                  <p className="text-[1rem] font-bold">{currency(remaining, trip.currency)}</p>
                </div>
                <div>
                  <p className="text-[0.56rem] font-bold uppercase tracking-wide text-muted-foreground">Each person</p>
                  <p className="text-[1rem] font-bold">
                    {currency(Math.round(total / 2), trip.currency)}
                  </p>
                </div>
              </div>
              <SoftProgress value={Math.min(100, Math.round((saved / Math.max(1, total)) * 100))} />

              <div className="flex flex-wrap items-center gap-1.5">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    const copy: Trip = { ...trip, id: makeId("trip"), name: `${trip.name} (plan B)` };
                    mutate((state) => ({ ...state, trips: [...state.trips, copy] }));
                    setActiveTripId(copy.id);
                    toast("Scenario duplicated", { description: "Adjust the numbers to compare a different plan." });
                  }}
                >
                  <Copy className="h-3 w-3" /> Compare a scenario
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    if (data.trips.length <= 1) {
                      toast("Keep at least one scenario");
                      return;
                    }
                    if (!window.confirm("Remove this trip scenario?")) return;
                    mutate((state) => ({ ...state, trips: state.trips.filter((item) => item.id !== trip.id) }));
                    setActiveTripId(data.trips[0].id);
                  }}
                >
                  <Trash2 className="h-3 w-3" /> Remove scenario
                </Button>
                <span className="text-[0.58rem] text-muted-foreground">
                  {trip.from} <ArrowRight className="inline h-2.5 w-2.5" /> {trip.to}
                </span>
              </div>
            </div>
          )}
        </SectionCard>

        <div className="flex flex-col gap-3 xl:col-span-5">
          <SectionCard
            title="Shared goals"
            subtitle="Progress is calculated from what we actually put in."
            action={<span className="text-[0.6rem]">{data.goals.length} funds</span>}
          >
            {data.goals.length === 0 && (
              <div className="rounded-xl border border-dashed border-border/80 bg-card/60 p-3 text-center">
                <p className="hand text-[1.05rem] leading-tight text-sage">No funds yet</p>
                <p className="mt-0.5 text-[0.62rem] leading-snug text-muted-foreground">
                  Create a fund for something you are building together, then record what each of you puts in.
                </p>
                <Button
                  size="sm"
                  variant="note"
                  className="mt-1.5"
                  onClick={() =>
                    setGoalDraft({
                      title: "",
                      subtitle: "",
                      target: "20000",
                      targetDate: new Date(Date.now() + 86400000 * 300).toISOString().slice(0, 10),
                      accent: "sage",
                    })
                  }
                >
                  <Plus className="h-3 w-3" /> Create a fund
                </Button>
              </div>
            )}
            <ul className="flex flex-col gap-2">
              {data.goals.map((goal) => {
                const goalSaved = goal.contributions.reduce((sum, c) => sum + c.amount, 0);
                const pct = Math.min(100, Math.round((goalSaved / Math.max(1, goal.target)) * 100));
                return (
                  <li key={goal.id} className={cn("rounded-xl border border-border/60 p-2.5", accentSurface[goal.accent])}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-[0.78rem] font-bold capitalize">{goal.title}</p>
                        <p className="truncate text-[0.58rem] text-ink-soft">{goal.subtitle}</p>
                      </div>
                      <span className="hand shrink-0 text-[1rem] leading-none text-ink/70">{pct}%</span>
                    </div>
                    <SoftProgress
                      value={pct}
                      tone={goal.accent === "blush" || goal.accent === "peach" ? "peach" : "sage"}
                      className="mt-1.5"
                      height="h-1.5"
                    />
                    <div className="mt-1 flex items-center justify-between gap-2 text-[0.58rem] font-semibold">
                      <span className="tabular-nums">
                        {currency(goalSaved)} / {currency(goal.target)}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setContributionDraft({
                            goalId: goal.id,
                            person: "you",
                            amount: "",
                            note: "",
                          })
                        }
                        className="rounded-full bg-card/80 px-1.5 py-0.5 font-bold text-sage hover:bg-card"
                      >
                        + add
                      </button>
                    </div>
                    <div className="mt-1 flex items-center gap-1">
                      {(["you", "me"] as PersonId[]).map((person) => {
                        const personSaved = goal.contributions
                          .filter((c) => c.person === person)
                          .reduce((sum, c) => sum + c.amount, 0);
                        return (
                          <span
                            key={person}
                            className="inline-flex items-center gap-1 rounded-full bg-card/70 px-1.5 py-0.5 text-[0.54rem] font-semibold"
                          >
                            <MascotAvatar name={data.people[person].companion} className="h-3.5 w-3.5" />
                            {currency(personSaved)}
                          </span>
                        );
                      })}
                    </div>
                  </li>
                );
              })}
            </ul>
          </SectionCard>

          <Panel title="A gentle money reminder" icon={<Sparkles className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <p className="font-read text-[0.74rem] leading-snug text-ink-soft">
              Steady beats dramatic. We are not racing anyone — we are building something patient and honest,
              one small transfer at a time.
            </p>
          </Panel>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3.5 xl:grid-cols-12">
        <SectionCard
          className="xl:col-span-8"
          title={`Monthly money talk${talk ? ` · ${talk.month}` : ""}`}
          subtitle="Six quiet questions and the actions we promised each other."
          action={
            <Button
              size="sm"
              variant="note"
              onClick={() => {
                mutate((state) => {
                  const current = state.moneyTalks.find((item) => item.month === monthLabel(new Date().toISOString()));
                  if (current) {
                    return {
                      ...state,
                      moneyTalks: state.moneyTalks.map((item) =>
                        item.id === current.id ? { ...item, answers: talkAnswers } : item,
                      ),
                    };
                  }
                  return {
                    ...state,
                    moneyTalks: [
                      {
                        id: makeId("talk"),
                        month: monthLabel(new Date().toISOString()),
                        answers: talkAnswers,
                        actions: [],
                      },
                      ...state.moneyTalks,
                    ],
                  };
                });
                toast("Money talk saved");
              }}
            >
              <ReceiptText className="h-3 w-3" /> Save this month
            </Button>
          }
        >
          {!talk && (
            <p className="mb-2 rounded-xl border border-dashed border-border/80 bg-butter-soft/60 px-3 py-1.5 text-[0.62rem] leading-snug text-ink-soft">
              No money talk saved yet. Answer the six questions together, add what each of you promised, then press
              “Save this month” to keep it as your archive.
            </p>
          )}
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {AGENDA.map((item) => (
              <div key={item.key}>
                <label className="text-[0.6rem] font-bold uppercase tracking-wide text-muted-foreground">
                  {item.label}
                </label>
                <textarea
                  value={talkAnswers[item.key] ?? ""}
                  onChange={(event) => setTalkAnswers({ ...talkAnswers, [item.key]: event.target.value })}
                  rows={2}
                  className="mt-0.5 w-full rounded-lg border border-input bg-card px-2 py-1.5 text-[0.72rem]"
                  placeholder="Our honest answer…"
                />
              </div>
            ))}
          </div>

          <div className="mt-3 rounded-xl bg-muted/40 p-2.5">
            <div className="mb-1.5 flex items-center justify-between gap-2">
              <p className="text-[0.72rem] font-bold">Before the next meeting</p>
              <Button
                size="sm"
                variant="ghost"
                className="h-6 px-1.5 text-[0.6rem]"
                onClick={() => setActionDraft({ person: "you", text: "", due: "" })}
              >
                <Plus className="h-3 w-3" /> Add action
              </Button>
            </div>
            <ul className="flex flex-col gap-1">
              {(talk?.actions ?? []).map((action) => (
                <li key={action.id} className="flex items-start gap-1.5 rounded-lg bg-card/70 px-2 py-1">
                  <button
                    type="button"
                    aria-label={action.done ? "Mark as not done" : "Mark as done"}
                    onClick={() =>
                      mutate((state) => ({
                        ...state,
                        moneyTalks: state.moneyTalks.map((item) => ({
                          ...item,
                          actions: item.actions.map((entry) =>
                            entry.id === action.id ? { ...entry, done: !entry.done } : entry,
                          ),
                        })),
                      }))
                    }
                    className={cn(
                      "mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded border",
                      action.done ? "border-sage bg-sage text-primary-foreground" : "border-border bg-card",
                    )}
                  >
                    {action.done && <Check className="h-2.5 w-2.5" />}
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className={cn("text-[0.68rem] font-semibold", action.done && "text-muted-foreground line-through")}>
                      {action.text}
                    </p>
                    <p className="text-[0.54rem] text-muted-foreground">
                      {action.person === "you" ? data.people.you.nickname : data.people.me.nickname}
                      {action.due ? ` · by ${action.due}` : ""}
                    </p>
                  </div>
                </li>
              ))}
              {!talk?.actions.length && (
                <li className="text-[0.62rem] text-muted-foreground">No promises yet — keep them tiny.</li>
              )}
            </ul>
          </div>
        </SectionCard>

        <div className="flex flex-col gap-3 xl:col-span-4">
          <Panel title="Archived talks" icon={<Calculator className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            {data.moneyTalks.length === 0 && (
              <p className="rounded-lg border border-dashed border-border/80 bg-card/60 px-2 py-1.5 text-[0.6rem] leading-snug text-muted-foreground">
                Past talks will live here after your first save.
              </p>
            )}
            <ul className="flex flex-col gap-1.5">
              {data.moneyTalks.map((item) => (
                <li key={item.id} className="rounded-lg bg-card/70 px-2 py-1.5">
                  <p className="text-[0.7rem] font-bold">{item.month}</p>
                  <p className="truncate text-[0.58rem] text-muted-foreground">
                    {item.answers.priority || "No priority noted"}
                  </p>
                </li>
              ))}
            </ul>
          </Panel>
          <StickyNote tone="sage" className="mx-auto w-[88%] rotate-[-1.4deg]">
            one tiny step closer to the life we&apos;re dreaming of.
          </StickyNote>
          <Panel title="Who contributes what" icon={<Users className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <p className="text-[0.68rem] leading-snug text-muted-foreground">
              Contributions never have to be equal. What matters is that both names appear in the story.
            </p>
            <div className="mt-1.5 flex items-center gap-2">
              {(["you", "me"] as PersonId[]).map((person) => {
                const personTotal = data.goals.reduce(
                  (sum, goal) =>
                    sum + goal.contributions.filter((c) => c.person === person).reduce((s, c) => s + c.amount, 0),
                  0,
                );
                return (
                  <span key={person} className="flex items-center gap-1 rounded-full bg-muted/60 px-2 py-1 text-[0.6rem] font-bold">
                    <MascotAvatar name={data.people[person].companion} className="h-4 w-4" />
                    {currency(personTotal)}
                  </span>
                );
              })}
            </div>
          </Panel>
        </div>
      </div>

      <Dialog open={Boolean(goalDraft)} onOpenChange={(open) => !open && setGoalDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A new shared fund</DialogTitle>
          </DialogHeader>
          {goalDraft && (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <TextField
                label="Name"
                value={goalDraft.title}
                onChange={(event) => setGoalDraft({ ...goalDraft, title: event.target.value })}
                className="sm:col-span-2"
              />
              <TextField
                label="What is it for?"
                value={goalDraft.subtitle}
                onChange={(event) => setGoalDraft({ ...goalDraft, subtitle: event.target.value })}
                className="sm:col-span-2"
              />
              <TextField
                label="Target amount"
                type="number"
                value={goalDraft.target}
                onChange={(event) => setGoalDraft({ ...goalDraft, target: event.target.value })}
              />
              <TextField
                label="Target date"
                type="date"
                value={goalDraft.targetDate}
                onChange={(event) => setGoalDraft({ ...goalDraft, targetDate: event.target.value })}
              />
              <SelectField
                label="Colour"
                value={goalDraft.accent}
                onChange={(value) => setGoalDraft({ ...goalDraft, accent: value as Goal["accent"] })}
                options={ACCENTS.map((accent) => ({ value: accent, label: accent }))}
                className="sm:col-span-2"
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setGoalDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={addGoal}>
              <Target className="h-3.5 w-3.5" /> Create goal
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(contributionDraft)} onOpenChange={(open) => !open && setContributionDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A little more saved</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Recorded in the history, so progress always adds up honestly.
            </DialogDescription>
          </DialogHeader>
          {contributionDraft && (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <SelectField
                label="Which fund?"
                value={contributionDraft.goalId}
                onChange={(value) => setContributionDraft({ ...contributionDraft, goalId: value })}
                options={data.goals.map((goal) => ({ value: goal.id, label: goal.title }))}
                className="sm:col-span-2"
              />
              <SelectField
                label="Who saved it?"
                value={contributionDraft.person}
                onChange={(value) =>
                  setContributionDraft({ ...contributionDraft, person: value as PersonId })
                }
                options={[
                  { value: "you", label: data.people.you.name },
                  { value: "me", label: data.people.me.name },
                ]}
              />
              <TextField
                label="Amount"
                type="number"
                value={contributionDraft.amount}
                onChange={(event) => setContributionDraft({ ...contributionDraft, amount: event.target.value })}
              />
              <TextField
                label="Note (optional)"
                value={contributionDraft.note}
                onChange={(event) => setContributionDraft({ ...contributionDraft, note: event.target.value })}
                className="sm:col-span-2"
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setContributionDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={addContribution}>
              <PiggyBank className="h-3.5 w-3.5" /> Add to the fund
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(actionDraft)} onOpenChange={(open) => !open && setActionDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A small promise</DialogTitle>
          </DialogHeader>
          {actionDraft && (
            <div className="space-y-2.5">
              <TextField
                label="What will you do?"
                value={actionDraft.text}
                onChange={(event) => setActionDraft({ ...actionDraft, text: event.target.value })}
              />
              <SelectField
                label="Who?"
                value={actionDraft.person}
                onChange={(value) => setActionDraft({ ...actionDraft, person: value as PersonId })}
                options={[
                  { value: "you", label: data.people.you.name },
                  { value: "me", label: data.people.me.name },
                ]}
              />
              <TextField
                label="By when?"
                type="date"
                value={actionDraft.due}
                onChange={(event) => setActionDraft({ ...actionDraft, due: event.target.value })}
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setActionDraft(null)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={() => {
                if (!actionDraft?.text.trim()) return;
                mutate((state) => ({
                  ...state,
                  moneyTalks: state.moneyTalks.map((item, index) =>
                    index === 0
                      ? {
                          ...item,
                          actions: [
                            ...item.actions,
                            {
                              id: makeId("action"),
                              person: actionDraft.person,
                              text: actionDraft.text,
                              due: actionDraft.due,
                              done: false,
                            },
                          ],
                        }
                      : item,
                  ),
                }));
                setActionDraft(null);
                toast("Action added to this month's talk");
              }}
            >
              Add action
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
