import { useEffect, useMemo, useState } from "react";
import {
  AlarmClock,
  CalendarCheck2,
  CalendarDays,
  Clock3,
  CloudOff,
  Heart,
  Pencil,
  Plus,
  Loader2,
  RefreshCw,
  Repeat,
  Sparkles,
  Sun,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { makeId, useNow, useUniverse } from "@/store/universe";
import {
  DAY_LABELS,
  formatClock,
  formatDiff,
  formatDuration,
  formatHHmm,
  hhmmInZone,
  relativeTime,
  weekdayIndexInZone,
  weekDates,
  weekLabel,
  zoneDifference,
} from "@/lib/time";
import { conflictsFor, eventInterval, overlapWindows, type OverlapWindow } from "@/lib/planner";
import {
  checkCalendar,
  eventToPayload,
  googleToEvent,
  patchCalendarEvent,
  pullCalendar,
  pushCalendarEvent,
  removeCalendarEvent,
  weekWindow,
} from "@/lib/google";
import { PageHeading, LiveClock } from "@/components/kit/bits";
import { Panel, StickyNote } from "@/components/kit/panel";
import { EmptyState, SectionCard, SelectField, TextField, TextareaField } from "@/components/kit/controls";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import type { CalEvent, EventStatus, PersonId, Ritual } from "@/lib/types";

const CATEGORIES = ["School", "Work", "Study", "Family", "Rest", "Faith", "Personal", "Us", "Travel"];
const STATUS_OPTIONS: { value: EventStatus; label: string }[] = [
  { value: "busy", label: "Busy — please don't assume I'm free" },
  { value: "flexible", label: "Flexible — movable if needed" },
  { value: "available", label: "Available — I'm happily free" },
];

type EventDraft = Omit<CalEvent, "id"> & { id?: string };

const emptyDraft = (person: PersonId, day: number): EventDraft => ({
  person,
  title: "",
  day,
  start: "19:00",
  end: "20:00",
  status: "busy",
  category: "Us",
  recurrence: "none",
  notes: "",
});

export default function Planner() {
  const { data, mutate, spaceId } = useUniverse();
  const now = useNow(30000);
  const dates = weekDates();
  const todayIndex = (new Date().getDay() + 6) % 7;
  const [selectedDay, setSelectedDay] = useState(todayIndex);
  const [displayPerson, setDisplayPerson] = useState<PersonId>("you");
  const [editing, setEditing] = useState<EventDraft | null>(null);
  const [googleState, setGoogleState] = useState<"unknown" | "checking" | "connected" | "error">("unknown");
  const [googleBusy, setGoogleBusy] = useState<"pull" | "push" | null>(null);
  const [googleMessage, setGoogleMessage] = useState<string | null>(null);
  const [allDayGoogle, setAllDayGoogle] = useState(0);
  const [ritualDraft, setRitualDraft] = useState<Ritual | null>(null);
  const [reflectionDraft, setReflectionDraft] = useState<{
    list: "love" | "improve";
    title: string;
    body: string;
    followUp: string;
  } | null>(null);

  const zone = data.people[displayPerson].timezone;
  const overlaps = useMemo(
    () => overlapWindows(data.people, selectedDay, dates, data.events, 30),
    [data.people, data.events, selectedDay, dates],
  );
  const weekOverlaps = useMemo(
    () => dates.map((_, index) => overlapWindows(data.people, index, dates, data.events, 30)),
    [data.people, data.events, dates],
  );

  useEffect(() => {
    let active = true;
    setGoogleState("checking");
    checkCalendar(spaceId).then((result) => {
      if (!active) return;
      if ("error" in result) {
        setGoogleState("error");
        setGoogleMessage(result.error);
        return;
      }
      setGoogleState("connected");
      setGoogleMessage(null);
    });
    return () => {
      active = false;
    };
  }, [spaceId]);

  const googleOwner = data.settings.googleOwner;
  const pendingGoogle = data.events.filter(
    (event) =>
      event.source !== "google" &&
      !event.googleEventId &&
      event.syncToGoogle !== false &&
      event.person === googleOwner,
  ).length;

  const pullGoogle = async () => {
    if (googleBusy) return;
    setGoogleBusy("pull");
    const timezone = data.people[googleOwner].timezone;
    const bounds = weekWindow(dates, timezone);
    const result = await pullCalendar(spaceId, bounds.timeMin, bounds.timeMax);
    setGoogleBusy(null);
    if ("error" in result) {
      setGoogleState("error");
      setGoogleMessage(result.error);
      toast("Google Calendar didn't answer", { description: result.error });
      return;
    }
    const items = result.data.items ?? [];
    const mapped = items
      .map((item) => googleToEvent(item, googleOwner, timezone, { start: bounds.start, end: bounds.end }))
      .filter((event): event is CalEvent => Boolean(event));
    const allDay = items.filter((item) => item.allDay).length;
    setAllDayGoogle(allDay);
    setGoogleState("connected");
    setGoogleMessage(null);
    mutate((draft) => ({
      ...draft,
      events: [...draft.events.filter((event) => event.source !== "google"), ...mapped],
      settings: { ...draft.settings, googleSyncedAt: new Date().toISOString() },
    }));
    toast(`${mapped.length} Google event${mapped.length === 1 ? "" : "s"} in the planner`, {
      description: allDay
        ? `${allDay} all-day event${allDay === 1 ? "" : "s"} stay only in Google.`
        : "Only the weeks you pull are mirrored here.",
    });
  };

  const pushGoogle = async () => {
    if (googleBusy) return;
    const pending = data.events.filter(
      (event) =>
        event.source !== "google" &&
        !event.googleEventId &&
        event.syncToGoogle !== false &&
        event.person === googleOwner,
    );
    if (!pending.length) {
      toast("Nothing left to send", { description: "Every planned event for this calendar is already in Google." });
      return;
    }
    setGoogleBusy("push");
    const created: { id: string; googleEventId: string }[] = [];
    let failed = 0;
    for (const event of pending.slice(0, 10)) {
      const payload = eventToPayload(event, dates, data.people[event.person].timezone);
      const result = await pushCalendarEvent(spaceId, payload);
      if ("error" in result) {
        failed += 1;
        continue;
      }
      const newId = (result.data as { googleEventId?: string }).googleEventId;
      if (newId) created.push({ id: event.id, googleEventId: newId });
    }
    setGoogleBusy(null);
    if (created.length) {
      mutate((draft) => ({
        ...draft,
        events: draft.events.map((event) => {
          const hit = created.find((entry) => entry.id === event.id);
          return hit ? { ...event, googleEventId: hit.googleEventId } : event;
        }),
        settings: { ...draft.settings, googleSyncedAt: new Date().toISOString() },
      }));
    }
    if (failed) {
      toast(`${created.length} sent, ${failed} still waiting`, {
        description: "The failed ones stay in the planner — try again whenever you like.",
      });
    } else {
      toast(`${created.length} event${created.length === 1 ? "" : "s"} added to Google Calendar`);
    }
  };

  const saveEvent = async () => {
    if (!editing) return;
    if (!editing.title.trim()) {
      toast("Give the event a name first");
      return;
    }
    if (editing.start >= editing.end) {
      toast("Heads up: this ends before it starts", {
        description: "We'll save it as an overnight event so it doesn't vanish.",
      });
    }
    const savedId = editing.id ?? makeId("ev");
    const saved: CalEvent = {
      ...editing,
      id: savedId,
      syncToGoogle: editing.syncToGoogle ?? data.settings.googleWrite,
    };
    mutate((draft) => ({
      ...draft,
      events: draft.events.some((event) => event.id === savedId)
        ? draft.events.map((event) => (event.id === savedId ? saved : event))
        : [...draft.events, saved],
    }));
    toast(editing.id ? "Event updated" : "Event added to the week");
    setEditing(null);

    if (googleState === "connected" && saved.source !== "google" && saved.syncToGoogle) {
      const payload = eventToPayload(saved, dates, data.people[saved.person].timezone);
      const result = saved.googleEventId
        ? await patchCalendarEvent(spaceId, saved.googleEventId, payload)
        : await pushCalendarEvent(spaceId, payload);
      if ("error" in result) {
        toast("Saved here, but Google didn't take it", { description: result.error });
      } else if (!saved.googleEventId) {
        const newId = (result.data as { googleEventId?: string }).googleEventId;
        if (newId) {
          mutate((draft) => ({
            ...draft,
            events: draft.events.map((event) =>
              event.id === savedId ? { ...event, googleEventId: newId } : event,
            ),
            settings: { ...draft.settings, googleSyncedAt: new Date().toISOString() },
          }));
        }
      }
    }
  };

  const removeEvent = (id: string) => {
    const target = data.events.find((event) => event.id === id);
    if (!window.confirm(target?.googleEventId ? "Remove this event here and in Google Calendar?" : "Remove this event from the week?")) {
      return;
    }
    mutate((draft) => ({ ...draft, events: draft.events.filter((event) => event.id !== id) }));
    setEditing(null);
    toast("Event removed");
    if (target?.googleEventId) {
      void removeCalendarEvent(spaceId, target.googleEventId).then((result) => {
        if ("error" in result) {
          toast("Removed here, but Google kept it", { description: result.error });
        }
      });
    }
  };

  const saveRitual = () => {
    if (!ritualDraft || !ritualDraft.title.trim()) {
      toast("Name your little ritual first");
      return;
    }
    mutate((draft) => ({
      ...draft,
      rituals: draft.rituals.some((ritual) => ritual.id === ritualDraft.id)
        ? draft.rituals.map((ritual) => (ritual.id === ritualDraft.id ? ritualDraft : ritual))
        : [...draft.rituals, ritualDraft],
    }));
    setRitualDraft(null);
    toast("Ritual saved");
  };

  const addRitualToWeek = (ritual: Ritual) => {
    mutate((draft) => {
      const additions: CalEvent[] = [];
      for (const day of ritual.days) {
        for (const person of ["you", "me"] as PersonId[]) {
          additions.push({
            id: makeId("ritual"),
            person,
            title: ritual.title,
            day,
            start: ritual.start,
            end: ritual.end,
            status: "busy",
            category: "Us",
            recurrence: "weekly",
            ritual: true,
            notes: "Kept as our own little ritual",
          });
        }
      }
      return { ...draft, events: [...draft.events, ...additions] };
    });
    toast(`${ritual.title} added`, {
      description: "Both planners now protect that time. Adjust either side if you need to.",
    });
  };

  const createCallFrom = (window: OverlapWindow) => {
    mutate((draft) => ({
      ...draft,
      events: [
        ...draft.events,
        {
          id: makeId("call"),
          person: "you",
          title: "Call / Date",
          day: weekdayIndexInZone(window.start, draft.people.you.timezone),
          start: hhmmInZone(window.start, draft.people.you.timezone),
          end: hhmmInZone(window.end, draft.people.you.timezone),
          status: "busy",
          category: "Us",
          recurrence: "none",
        },
        {
          id: makeId("call"),
          person: "me",
          title: "Call / Date",
          day: weekdayIndexInZone(window.start, draft.people.me.timezone),
          start: hhmmInZone(window.start, draft.people.me.timezone),
          end: hhmmInZone(window.end, draft.people.me.timezone),
          status: "busy",
          category: "Us",
          recurrence: "none",
        },
      ],
    }));
    toast("It's on both calendars", { description: "Your time together is protected now." });
  };

  const saveReflection = () => {
    if (!reflectionDraft || !reflectionDraft.title.trim()) {
      toast("Add a short title first");
      return;
    }
    mutate((draft) => {
      const current = draft.reflections.find((entry) => !entry.archived);
      const entry = {
        id: makeId("ref"),
        person: "you" as PersonId,
        list: reflectionDraft.list,
        title: reflectionDraft.title,
        body: reflectionDraft.body,
        status: "open" as const,
        followUp: reflectionDraft.followUp,
      };
      if (current) {
        return {
          ...draft,
          reflections: draft.reflections.map((week) =>
            week.id === current.id ? { ...week, entries: [...week.entries, entry] } : week,
          ),
        };
      }
      return {
        ...draft,
        reflections: [
          {
            id: makeId("week"),
            weekOf: new Date().toISOString().slice(0, 10),
            archived: false,
            entries: [entry],
          },
          ...draft.reflections,
        ],
      };
    });
    setReflectionDraft(null);
    toast("Added to this week's reflection");
  };

  const currentReflection = data.reflections.find((entry) => !entry.archived);

  return (
    <div className="flex flex-col gap-3.5">
      <PageHeading eyebrow="two lives, one overlap" title="Weekly Planner" mascot="siamese">
        <div className="flex items-center gap-1 rounded-full border border-border/70 bg-card/80 p-0.5">
          {(["you", "me"] as PersonId[]).map((person) => (
            <button
              key={person}
              type="button"
              onClick={() => setDisplayPerson(person)}
              className={cn(
                "rounded-full px-2.5 py-1 text-[0.66rem] font-bold transition",
                displayPerson === person ? "bg-sage text-primary-foreground shadow-sm" : "text-muted-foreground",
              )}
            >
              Times in {data.people[person].nickname}&apos;s zone
            </button>
          ))}
        </div>
        <Button
          variant="note"
          size="sm"
          onClick={() => setEditing(emptyDraft("you", selectedDay))}
        >
          <Plus className="h-3.5 w-3.5" /> Add event
        </Button>
      </PageHeading>

      <Panel
        title="This week at a glance"
        icon={<CalendarDays className="h-3.5 w-3.5 text-sage" aria-hidden />}
        action={<span>{weekLabel(dates)}</span>}
        bodyClassName="p-2.5"
      >
        <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-7">
          {dates.map((date, index) => {
            const count = data.events.filter((event) => event.day === index).length;
            const free = weekOverlaps[index].reduce((sum, window) => sum + window.minutes, 0);
            return (
              <button
                key={date.toISOString()}
                type="button"
                onClick={() => setSelectedDay(index)}
                className={cn(
                  "flex flex-col items-start gap-0.5 rounded-xl border px-2 py-1.5 text-left transition",
                  selectedDay === index
                    ? "border-sage/50 bg-sage-soft shadow-sm"
                    : "border-border/70 bg-card/70 hover:bg-muted/60",
                  index === todayIndex && selectedDay !== index && "border-dashed",
                )}
              >
                <span className="text-[0.6rem] font-bold uppercase tracking-wide text-muted-foreground">
                  {DAY_LABELS[index]}
                </span>
                <span className="text-[0.95rem] font-bold leading-none">{date.getDate()}</span>
                <span className="text-[0.56rem] font-semibold text-muted-foreground">
                  {count} event{count === 1 ? "" : "s"}
                </span>
                <span className="inline-flex items-center gap-0.5 text-[0.56rem] font-bold text-coral">
                  <Heart className="h-2.5 w-2.5" aria-hidden /> {free >= 60 ? formatDuration(free) : "—"}
                </span>
              </button>
            );
          })}
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-3.5 xl:grid-cols-12">
        <div className="flex flex-col gap-3 xl:col-span-8">
          <div className="grid grid-cols-1 gap-3.5 md:grid-cols-2">
            {(["you", "me"] as PersonId[]).map((personId) => {
              const person = data.people[personId];
              const laneEvents = data.events
                .filter((event) => event.person === personId && event.day === selectedDay)
                .sort((a, b) => a.start.localeCompare(b.start));

              return (
                <Panel
                  key={personId}
                  title={person.name}
                  icon={<Clock3 className="h-3.5 w-3.5 text-sage" aria-hidden />}
                  action={<span>{person.timezone.replace("_", " ")}</span>}
                  tint={personId === "you" ? "butter" : "powder"}
                  bodyClassName="space-y-1.5 p-2.5"
                >
                  <div className="flex items-center justify-between text-[0.6rem] font-semibold text-muted-foreground">
                    <span>
                      {DAY_LABELS[selectedDay]} {dates[selectedDay].getDate()}
                    </span>
                    <span>{laneEvents.length} planned</span>
                  </div>

                  {laneEvents.length === 0 ? (
                    <EmptyState
                      mascot={person.companion}
                      title="An open page"
                      note="Empty does not mean free — add your busy blocks so overlap stays honest."
                      action={
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditing(emptyDraft(personId, selectedDay))}
                        >
                          <Plus className="h-3 w-3" /> Add
                        </Button>
                      }
                    />
                  ) : (
                    <ul className="flex flex-col gap-1.5">
                      {laneEvents.map((event) => {
                        const interval = eventInterval(event, dates, person.timezone);
                        const conflict =
                          event.status === "busy" && conflictsFor(event, data.events, person);
                        return (
                          <li key={event.id}>
                            <button
                              type="button"
                              onClick={() => {
                                if (event.source === "google") {
                                  toast("This one lives in Google Calendar", {
                                    description: "Edit it in Google, then pull the week again.",
                                  });
                                  return;
                                }
                                setEditing({ ...event });
                              }}
                              className={cn(
                                "w-full rounded-xl border border-border/70 bg-card/90 px-2.5 py-1.5 text-left shadow-sm transition hover:-translate-y-px hover:shadow-note",
                                event.status === "flexible" && "border-dashed",
                              )}
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span className="truncate text-[0.78rem] font-bold">{event.title}</span>
                                <span className="shrink-0 rounded-full bg-muted px-1.5 text-[0.52rem] font-bold uppercase tracking-wide text-muted-foreground">
                                  {event.category}
                                </span>
                              </div>
                              <p className="mt-0.5 text-[0.64rem] font-semibold tabular-nums text-ink-soft">
                                {formatClock(interval.start, zone)} – {formatClock(interval.end, zone)}
                                <span className="ml-1 font-medium text-muted-foreground">
                                  ({formatDuration(Math.round((interval.end.getTime() - interval.start.getTime()) / 60000))})
                                </span>
                              </p>
                              <div className="mt-0.5 flex flex-wrap items-center gap-1 text-[0.52rem] font-bold">
                                <span
                                  className={cn(
                                    "rounded-full px-1.5 py-0.5",
                                    event.status === "busy" && "bg-peach text-accent-foreground",
                                    event.status === "flexible" && "bg-butter text-ink",
                                    event.status === "available" && "bg-sage-soft text-sage",
                                  )}
                                >
                                  {event.status}
                                </span>
                                {event.recurrence !== "none" && (
                                  <span className="inline-flex items-center gap-0.5 text-muted-foreground">
                                    <Repeat className="h-2.5 w-2.5" aria-hidden /> {event.recurrence}
                                  </span>
                                )}
                                {event.ritual && (
                                  <span className="inline-flex items-center gap-0.5 text-coral">
                                    <Heart className="h-2.5 w-2.5" aria-hidden /> ritual
                                  </span>
                                )}
                                {event.source === "google" && (
                                  <span className="inline-flex items-center gap-0.5 rounded-full bg-powder px-1.5 py-0.5 text-ink">
                                    <CalendarCheck2 className="h-2.5 w-2.5" aria-hidden /> google
                                  </span>
                                )}
                                {conflict && (
                                  <span className="rounded-full bg-coral/15 px-1.5 py-0.5 text-coral">
                                    double-booked
                                  </span>
                                )}
                              </div>
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  )}

                  {personId === "you" && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="w-full justify-start text-[0.65rem]"
                      onClick={() => setEditing(emptyDraft(personId, selectedDay))}
                    >
                      <Plus className="h-3 w-3" /> Add to {person.name}&apos;s day
                    </Button>
                  )}
                </Panel>
              );
            })}
          </div>

          <SectionCard
            title="Our Time (Overlap)"
            subtitle="Only the windows where both of you are genuinely open — never just an empty calendar."
            action={
              <span className="hand text-[0.95rem] text-sage">
                {overlaps.reduce((sum, w) => sum + w.minutes, 0) >= 60
                  ? `${formatDuration(overlaps.reduce((sum, w) => sum + w.minutes, 0))} together`
                  : "still finding room"}
              </span>
            }
          >
            {overlaps.length === 0 ? (
              <EmptyState
                mascot="siamese"
                title="No shared window on this day"
                note="Open a little space in either planner, or let the parakeet suggest another day."
                action={
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      const nextDay = weekOverlaps.findIndex(
                        (windows, index) => index !== selectedDay && windows.length > 0,
                      );
                      if (nextDay >= 0) {
                        setSelectedDay(nextDay);
                      } else {
                        toast("No shared window this week yet", {
                          description: "Add your open hours and busy blocks first — we only count real free time.",
                        });
                      }
                    }}
                  >
                    Find another day
                  </Button>
                }
              />
            ) : (
              <ul className="grid grid-cols-1 gap-2 md:grid-cols-2">
                {overlaps.map((window) => (
                  <li
                    key={window.start.toISOString()}
                    className="rounded-xl border border-peach bg-peach-soft p-2.5"
                  >
                    <p className="flex items-center gap-1 text-[0.82rem] font-bold tabular-nums">
                      <Heart className="h-3 w-3 text-coral" aria-hidden />
                      {formatClock(window.start, zone)} – {formatClock(window.end, zone)}
                    </p>
                    <p className="mt-0.5 text-[0.63rem] font-semibold text-ink-soft">
                      {formatDuration(window.minutes)} · {formatClock(window.start, data.people.you.timezone)} for{" "}
                      {data.people.you.nickname}, {formatClock(window.start, data.people.me.timezone)} for{" "}
                      {data.people.me.nickname}
                    </p>
                    <Button
                      size="sm"
                      variant="outline"
                      className="mt-1.5 h-7 bg-card text-[0.62rem]"
                      onClick={() => createCallFrom(window)}
                    >
                      <Plus className="h-3 w-3" /> Create call / date
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </SectionCard>

          <SectionCard
            id="reflection"
            title="Weekly reflection"
            subtitle="Three things we love, three things we'd like to grow — written gently."
            action={
              <Button
                size="sm"
                variant="soft"
                onClick={() =>
                  setReflectionDraft({ list: "love", title: "", body: "", followUp: "" })
                }
              >
                <Plus className="h-3 w-3" /> Add a thought
              </Button>
            }
          >
            {!currentReflection && (
              <p className="mb-2 rounded-xl border border-dashed border-border/80 bg-butter-soft/60 px-2.5 py-1.5 text-[0.62rem] leading-snug text-ink-soft">
                Nothing written for this week yet. Use “Add a thought” for each of the three things you loved, then
                the three you would like to grow.
              </p>
            )}
            <div className="grid grid-cols-1 gap-2.5 md:grid-cols-2">
              {(["love", "improve"] as const).map((list) => {
                const entries = currentReflection?.entries.filter((entry) => entry.list === list) ?? [];
                return (
                  <div
                    key={list}
                    className={cn(
                      "rounded-xl border p-2.5",
                      list === "love" ? "border-sage/30 bg-sage-soft/70" : "border-powder bg-powder-soft/70",
                    )}
                  >
                    <p className="mb-1.5 text-[0.72rem] font-bold">
                      {list === "love" ? "Three things we love" : "Three things we can improve"}
                    </p>
                    <ul className="flex flex-col gap-1.5">
                      {entries.length === 0 && (
                        <li className="text-[0.66rem] text-muted-foreground">
                          Nothing here yet — the page is yours.
                        </li>
                      )}
                      {entries.map((entry) => (
                        <li key={entry.id} className="rounded-lg bg-card/80 p-2 shadow-sm">
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-[0.72rem] font-bold leading-tight">{entry.title}</p>
                            <button
                              type="button"
                              onClick={() =>
                                mutate((draft) => ({
                                  ...draft,
                                  reflections: draft.reflections.map((week) => ({
                                    ...week,
                                    entries: week.entries.map((item) =>
                                      item.id === entry.id
                                        ? {
                                            ...item,
                                            status:
                                              item.status === "open"
                                                ? "working"
                                                : item.status === "working"
                                                  ? "resolved"
                                                  : "open",
                                          }
                                        : item,
                                    ),
                                  })),
                                }))
                              }
                              className={cn(
                                "shrink-0 rounded-full px-1.5 py-0.5 text-[0.5rem] font-bold uppercase",
                                entry.status === "open" && "bg-muted text-muted-foreground",
                                entry.status === "working" && "bg-butter text-ink",
                                entry.status === "resolved" && "bg-sage-soft text-sage",
                              )}
                              title="Cycle status"
                            >
                              {entry.status}
                            </button>
                          </div>
                          <p className="mt-0.5 text-[0.64rem] leading-snug text-ink-soft">{entry.body}</p>
                          {entry.followUp && (
                            <p className="mt-0.5 text-[0.58rem] text-muted-foreground">
                              Next: {entry.followUp}
                            </p>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>
            {data.reflections.length > 1 && (
              <p className="mt-2 text-[0.62rem] text-muted-foreground">
                {data.reflections.length - 1} earlier week
                {data.reflections.length - 1 === 1 ? "" : "s"} kept in your scrapbook.
              </p>
            )}
          </SectionCard>
        </div>

        <div className="flex flex-col gap-3 xl:col-span-4">
          <Panel
            title="Google Calendar"
            icon={<CalendarCheck2 className="h-3.5 w-3.5 text-sage" aria-hidden />}
            action={
              <span
                className={cn(
                  "inline-flex items-center gap-1",
                  googleState === "connected" ? "text-sage" : "text-muted-foreground",
                )}
              >
                <span
                  className={cn(
                    "h-1.5 w-1.5 rounded-full",
                    googleState === "connected"
                      ? "bg-sage"
                      : googleState === "error"
                        ? "bg-coral"
                        : "bg-muted-foreground/50",
                  )}
                />
                {googleState === "connected"
                  ? "connected"
                  : googleState === "checking"
                    ? "checking…"
                    : googleState === "error"
                      ? "needs attention"
                      : "not checked"}
              </span>
            }
          >
            <div className="space-y-2">
              {googleState === "error" ? (
                <p className="flex items-start gap-1.5 rounded-lg bg-destructive/10 px-2 py-1.5 text-[0.6rem] leading-snug text-destructive">
                  <CloudOff className="mt-0.5 h-3 w-3 shrink-0" aria-hidden />
                  {googleMessage ?? "We could not reach Google Calendar just now."}
                </p>
              ) : (
                <p className="text-[0.62rem] leading-snug text-muted-foreground">
                  Pull this week's Google events into the lanes, and send our plans back the other way.
                </p>
              )}

              <SelectField
                label="Whose Google calendar?"
                value={googleOwner}
                onChange={(value) =>
                  mutate((draft) => ({
                    ...draft,
                    settings: { ...draft.settings, googleOwner: value as PersonId },
                  }))
                }
                options={[
                  { value: "you", label: data.people.you.name },
                  { value: "me", label: data.people.me.name },
                ]}
              />

              <label className="flex items-center justify-between gap-2 rounded-xl border border-border/70 bg-card/70 px-2.5 py-1.5">
                <span className="text-[0.64rem] font-semibold">New events go to Google too</span>
                <Switch
                  checked={data.settings.googleWrite}
                  onCheckedChange={(checked) =>
                    mutate((draft) => ({
                      ...draft,
                      settings: { ...draft.settings, googleWrite: checked },
                    }))
                  }
                  aria-label="Send new events to Google Calendar by default"
                />
              </label>

              <div className="flex gap-1.5">
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1"
                  onClick={() => void pullGoogle()}
                  disabled={googleBusy !== null || googleState === "checking"}
                >
                  {googleBusy === "pull" ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <RefreshCw className="h-3 w-3" />
                  )}
                  Pull week
                </Button>
                <Button
                  size="sm"
                  variant="soft"
                  className="flex-1"
                  onClick={() => void pushGoogle()}
                  disabled={googleBusy !== null || pendingGoogle === 0}
                >
                  {googleBusy === "push" ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <CalendarCheck2 className="h-3 w-3" />
                  )}
                  Send {pendingGoogle > 0 ? pendingGoogle : ""}
                </Button>
              </div>

              {allDayGoogle > 0 && (
                <p className="text-[0.55rem] leading-snug text-muted-foreground">
                  {allDayGoogle} all-day Google event{allDayGoogle === 1 ? "" : "s"} stay in Google only — they have no
                  clock time to place in a lane.
                </p>
              )}
              <p className="text-[0.55rem] leading-snug text-muted-foreground">
                {data.settings.googleSyncedAt
                  ? `Last synced ${relativeTime(data.settings.googleSyncedAt)}.`
                  : "Not synced yet."}{" "}
                Pulled events are read-only here; edit them in Google, then pull again.
              </p>
            </div>
          </Panel>

          <Panel title="Where we are, right now" icon={<Sun className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <div className="flex flex-col gap-2">
              {(["you", "me"] as PersonId[]).map((personId) => {
                const person = data.people[personId];
                return (
                  <div key={personId} className="flex items-center justify-between gap-2 rounded-xl bg-muted/50 px-2.5 py-1.5">
                    <div>
                      <p className="text-[0.66rem] font-bold">
                        {person.name}
                      </p>
                      <p className="text-[0.58rem] text-muted-foreground">
                        {person.city} · {person.timezone.replace("_", " ")}
                      </p>
                    </div>
                    <LiveClock timezone={person.timezone} showDate={false} align="right" />
                  </div>
                );
              })}
              <p className="text-center text-[0.62rem] font-semibold text-muted-foreground">
                {formatDiff(
                  zoneDifference(data.people.you.timezone, data.people.me.timezone, now),
                )}{" "}
                right now · daylight saving included
              </p>
            </div>
          </Panel>

          <Panel title="When are we open?" icon={<AlarmClock className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <div className="space-y-2.5">
              {(["you", "me"] as PersonId[]).map((personId) => {
                const person = data.people[personId];
                return (
                  <div key={personId} className="grid grid-cols-[1fr_auto_auto] items-end gap-1.5">
                    <span className="text-[0.64rem] font-bold">{person.nickname}</span>
                    <input
                      type="time"
                      value={person.openFrom}
                      aria-label={`${person.nickname} open from`}
                      onChange={(event) =>
                        mutate((draft) => ({
                          ...draft,
                          people: {
                            ...draft.people,
                            [personId]: { ...draft.people[personId], openFrom: event.target.value },
                          },
                        }))
                      }
                      className="h-8 rounded-lg border border-input bg-card px-1.5 text-[0.68rem]"
                    />
                    <input
                      type="time"
                      value={person.openTo}
                      aria-label={`${person.nickname} open until`}
                      onChange={(event) =>
                        mutate((draft) => ({
                          ...draft,
                          people: {
                            ...draft.people,
                            [personId]: { ...draft.people[personId], openTo: event.target.value },
                          },
                        }))
                      }
                      className="h-8 rounded-lg border border-input bg-card px-1.5 text-[0.68rem]"
                    />
                  </div>
                );
              })}
              <p className="text-[0.6rem] leading-snug text-muted-foreground">
                Overlap is only found inside these hours, and only outside busy blocks. Empty space never counts
                as free on its own.
              </p>
            </div>
          </Panel>

          <Panel
            title="Our little rituals"
            icon={<Sparkles className="h-3.5 w-3.5 text-sage" aria-hidden />}
            action={
              <button
                type="button"
                className="inline-flex items-center gap-0.5 hover:text-sage"
                onClick={() =>
                  setRitualDraft({
                    id: makeId("rit"),
                    title: "",
                    days: [6],
                    start: "20:00",
                    end: "21:00",
                    enabled: true,
                  })
                }
              >
                <Plus className="h-3 w-3" /> New
              </button>
            }
          >
            {data.rituals.length === 0 && (
              <p className="rounded-xl border border-dashed border-border/80 bg-card/60 px-2 py-2 text-[0.62rem] leading-snug text-muted-foreground">
                No rituals yet. Add the goodnight call, a date night, or a Sunday check-in and we&apos;ll protect the
                time for you.
              </p>
            )}
            <ul className="flex flex-col gap-1.5">
              {data.rituals.map((ritual) => (
                <li key={ritual.id} className="rounded-xl border border-border/70 bg-card/80 p-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-[0.72rem] font-bold">{ritual.title}</p>
                      <p className="text-[0.58rem] font-semibold text-muted-foreground">
                        {ritual.days.map((day) => DAY_LABELS[day]).join(" · ")} ·{" "}
                        {formatHHmm(ritual.start)}–{formatHHmm(ritual.end)}
                      </p>
                    </div>
                    <Switch
                      checked={ritual.enabled}
                      aria-label={`${ritual.title} enabled`}
                      onCheckedChange={(checked) =>
                        mutate((draft) => ({
                          ...draft,
                          rituals: draft.rituals.map((item) =>
                            item.id === ritual.id ? { ...item, enabled: checked } : item,
                          ),
                        }))
                      }
                    />
                  </div>
                  <div className="mt-1 flex items-center gap-1.5">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 px-1.5 text-[0.58rem]"
                      onClick={() => addRitualToWeek(ritual)}
                    >
                      <Plus className="h-2.5 w-2.5" /> Add to week
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 px-1.5 text-[0.58rem]"
                      onClick={() => setRitualDraft({ ...ritual })}
                    >
                      <Pencil className="h-2.5 w-2.5" /> Edit
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          </Panel>

          <StickyNote tone="blush" className="mx-auto w-[85%] rotate-[-1.4deg]">
            time zones are silly. let's still find each other.
          </StickyNote>
        </div>
      </div>

      <Dialog open={Boolean(editing)} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">
              {editing?.id ? "Edit this little plan" : "Add a little plan"}
            </DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Times are saved in each of your own zones, so conversions stay correct.
            </DialogDescription>
          </DialogHeader>
          {editing && (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <TextField
                label="What is it?"
                value={editing.title}
                onChange={(event) => setEditing({ ...editing, title: event.target.value })}
                placeholder="Class, prayer walk, call…"
                className="sm:col-span-2"
              />
              <SelectField
                label="Whose day?"
                value={editing.person}
                onChange={(value) => setEditing({ ...editing, person: value as PersonId })}
                options={[
                  { value: "you", label: data.people.you.name },
                  { value: "me", label: data.people.me.name },
                ]}
              />
              <SelectField
                label="Day"
                value={String(editing.day)}
                onChange={(value) => setEditing({ ...editing, day: Number(value) })}
                options={DAY_LABELS.map((label, index) => ({
                  value: String(index),
                  label: `${label} · ${dates[index].getDate()}`,
                }))}
              />
              <TextField
                label="Start"
                type="time"
                value={editing.start}
                onChange={(event) => setEditing({ ...editing, start: event.target.value })}
              />
              <TextField
                label="End"
                type="time"
                value={editing.end}
                onChange={(event) => setEditing({ ...editing, end: event.target.value })}
              />
              <SelectField
                label="Availability"
                value={editing.status}
                onChange={(value) => setEditing({ ...editing, status: value as EventStatus })}
                options={STATUS_OPTIONS}
              />
              <SelectField
                label="Category"
                value={editing.category}
                onChange={(value) => setEditing({ ...editing, category: value })}
                options={CATEGORIES.map((category) => ({ value: category, label: category }))}
              />
              <SelectField
                label="Repeats"
                value={editing.recurrence}
                onChange={(value) =>
                  setEditing({ ...editing, recurrence: value as CalEvent["recurrence"] })
                }
                options={[
                  { value: "none", label: "Just this week" },
                  { value: "weekly", label: "Every week" },
                  { value: "biweekly", label: "Every other week" },
                  { value: "monthly", label: "Monthly" },
                ]}
              />
              {googleState === "connected" && editing?.source !== "google" && (
                <label className="flex items-center justify-between gap-2 rounded-xl border border-border/70 bg-muted/40 px-2.5 py-2 sm:col-span-2">
                  <span className="flex items-center gap-1.5 text-[0.7rem] font-semibold">
                    <CalendarCheck2 className="h-3.5 w-3.5 text-sage" aria-hidden />
                    Also keep this in Google Calendar
                  </span>
                  <Switch
                    checked={editing ? (editing.syncToGoogle ?? data.settings.googleWrite) : false}
                    onCheckedChange={(checked) => setEditing(editing ? { ...editing, syncToGoogle: checked } : editing)}
                    aria-label="Also keep this event in Google Calendar"
                  />
                </label>
              )}
              <TextareaField
                label="Notes for each other (optional)"
                value={editing.notes ?? ""}
                onChange={(event) => setEditing({ ...editing, notes: event.target.value })}
                className="sm:col-span-2"
                placeholder="Anything the other should know?"
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            {editing?.id && (
              <Button variant="ghost" size="sm" onClick={() => removeEvent(editing.id!)}>
                <Trash2 className="h-3.5 w-3.5" /> Remove
              </Button>
            )}
            <Button variant="soft" size="sm" onClick={() => setEditing(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={saveEvent}>
              {editing?.id ? "Save changes" : "Add to the week"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(ritualDraft)} onOpenChange={(open) => !open && setRitualDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A ritual worth protecting</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              We&apos;ll add it at the same local time for both of you, then you can nudge it.
            </DialogDescription>
          </DialogHeader>
          {ritualDraft && (
            <div className="space-y-2.5">
              <TextField
                label="Ritual name"
                value={ritualDraft.title}
                onChange={(event) => setRitualDraft({ ...ritualDraft, title: event.target.value })}
                placeholder="Goodnight call, Sunday check-in…"
              />
              <div>
                <p className="mb-1 text-[0.68rem] font-bold uppercase tracking-[0.08em] text-muted-foreground">
                  Days
                </p>
                <div className="flex flex-wrap gap-1">
                  {DAY_LABELS.map((label, index) => {
                    const active = ritualDraft.days.includes(index);
                    return (
                      <button
                        key={label}
                        type="button"
                        onClick={() =>
                          setRitualDraft({
                            ...ritualDraft,
                            days: active
                              ? ritualDraft.days.filter((day) => day !== index)
                              : [...ritualDraft.days, index],
                          })
                        }
                        className={cn(
                          "rounded-full border px-2.5 py-1 text-[0.66rem] font-bold",
                          active
                            ? "border-sage/50 bg-sage-soft text-sage"
                            : "border-border bg-card text-muted-foreground",
                        )}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <TextField
                  label="Start"
                  type="time"
                  value={ritualDraft.start}
                  onChange={(event) => setRitualDraft({ ...ritualDraft, start: event.target.value })}
                />
                <TextField
                  label="End"
                  type="time"
                  value={ritualDraft.end}
                  onChange={(event) => setRitualDraft({ ...ritualDraft, end: event.target.value })}
                />
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setRitualDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={saveRitual}>
              Save ritual
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(reflectionDraft)} onOpenChange={(open) => !open && setReflectionDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">Add to this week&apos;s reflection</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Specific and kind beats vague and heavy. It&apos;s a scrapbook, not a report card.
            </DialogDescription>
          </DialogHeader>
          {reflectionDraft && (
            <div className="space-y-2.5">
              <SelectField
                label="Which list?"
                value={reflectionDraft.list}
                onChange={(value) =>
                  setReflectionDraft({ ...reflectionDraft, list: value as "love" | "improve" })
                }
                options={[
                  { value: "love", label: "Three things we love" },
                  { value: "improve", label: "Three things we can improve" },
                ]}
              />
              <TextField
                label="Short title"
                value={reflectionDraft.title}
                onChange={(event) =>
                  setReflectionDraft({ ...reflectionDraft, title: event.target.value })
                }
                placeholder="Your gentle honesty"
              />
              <TextareaField
                label="What happened?"
                value={reflectionDraft.body}
                onChange={(event) =>
                  setReflectionDraft({ ...reflectionDraft, body: event.target.value })
                }
              />
              <TextField
                label="A follow-up action (optional)"
                value={reflectionDraft.followUp}
                onChange={(event) =>
                  setReflectionDraft({ ...reflectionDraft, followUp: event.target.value })
                }
                placeholder="Something small we can actually do"
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setReflectionDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={saveReflection}>
              Add it
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
