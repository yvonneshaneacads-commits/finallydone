import { useState } from "react";
import {
  BookOpen,
  Bookmark,
  CalendarDays,
  Check,
  MessageSquareQuote,
  Plus,
  Quote,
  Sparkles,
} from "lucide-react";
import { toast } from "sonner";
import { makeId, useUniverse } from "@/store/universe";
import { formatDateIn, formatDuration, formatClock, hhmmInZone, weekDates } from "@/lib/time";
import { overlapWindows } from "@/lib/planner";
import { PageHeading, MascotAvatar, SoftProgress } from "@/components/kit/bits";
import { Panel, StickyNote } from "@/components/kit/panel";
import { EmptyState, SectionCard, SelectField, TextField, TextareaField } from "@/components/kit/controls";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import type { PersonId, ReadingPlan } from "@/lib/types";

const PROMPTS = [
  "What stood out to me?",
  "What did I learn?",
  "What questions do I have?",
  "How can I apply this?",
  "What would I like to discuss with you?",
];

const KIND_OPTIONS = ["Devotional", "Book", "Bible plan", "Study series", "Poetry"];

const STATUS_SEQUENCE = ["todo", "reading", "done"] as const;

const statusLabel: Record<string, string> = {
  todo: "not started",
  reading: "in progress",
  done: "finished",
};

export default function Reading() {
  const { data, mutate } = useUniverse();
  const [activeId, setActiveId] = useState(data.readingPlans[0]?.id ?? "");
  const [planDraft, setPlanDraft] = useState<{
    title: string;
    kind: string;
    startDate: string;
    targetDate: string;
    chapters: string;
  } | null>(null);
  const [quoteDraft, setQuoteDraft] = useState("");
  const [discussionDraft, setDiscussionDraft] = useState<{ prompt: string; text: string } | null>(null);

  const plan: ReadingPlan | undefined =
    data.readingPlans.find((item) => item.id === activeId) ?? data.readingPlans[0];

  const cycleChapter = (chapterId: string, person: PersonId) => {
    if (!plan) return;
    mutate((state) => ({
      ...state,
      readingPlans: state.readingPlans.map((item) =>
        item.id === plan.id
          ? {
              ...item,
              chapters: item.chapters.map((chapter) =>
                chapter.id === chapterId
                  ? {
                      ...chapter,
                      progress: {
                        ...chapter.progress,
                        [person]:
                          STATUS_SEQUENCE[
                            (STATUS_SEQUENCE.indexOf(chapter.progress[person]) + 1) %
                              STATUS_SEQUENCE.length
                          ],
                      },
                    }
                  : chapter,
              ),
            }
          : item,
      ),
    }));
  };

  const scheduleSession = () => {
    if (!plan) return;
    const dates = weekDates();
    const windows = overlapWindows(data.people, 2, dates, data.events, 30);
    const window = windows[0];
    if (!window) {
      toast("No shared window on Wednesday", { description: "Open a little space in the planner first." });
      return;
    }
    mutate((state) => ({
      ...state,
      events: [
        ...state.events,
        {
          id: makeId("read"),
          person: "you",
          title: `Reading · ${plan.title}`,
          day: 2,
          start: hhmmInZone(window.start, state.people.you.timezone),
          end: hhmmInZone(window.end, state.people.you.timezone),
          status: "busy",
          category: "Us",
          recurrence: "weekly",
          ritual: true,
        },
        {
          id: makeId("read"),
          person: "me",
          title: `Reading · ${plan.title}`,
          day: 2,
          start: hhmmInZone(window.start, state.people.me.timezone),
          end: hhmmInZone(window.end, state.people.me.timezone),
          status: "busy",
          category: "Us",
          recurrence: "weekly",
          ritual: true,
        },
      ],
    }));
    toast("Reading session scheduled", {
      description: `${formatClock(window.start, data.people.you.timezone)} – ${formatClock(
        window.end,
        data.people.you.timezone,
      )} for you, converted for ${data.people.me.nickname}.`,
    });
  };

  const savePlan = () => {
    if (!planDraft || !planDraft.title.trim()) {
      toast("Give the plan a name");
      return;
    }
    const chapters = planDraft.chapters
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean)
      .map((title) => ({
        id: makeId("ch"),
        title,
        progress: { you: "todo" as const, me: "todo" as const },
      }));

    mutate((state) => ({
      ...state,
      readingPlans: [
        ...state.readingPlans,
        {
          id: makeId("plan"),
          title: planDraft.title,
          kind: planDraft.kind,
          startDate: planDraft.startDate,
          targetDate: planDraft.targetDate,
          chapters: chapters.length
            ? chapters
            : [{ id: makeId("ch"), title: "Chapter 1", progress: { you: "todo", me: "todo" } }],
          quotes: [],
          discussion: [],
        },
      ],
    }));
    toast("New reading plan added");
    setPlanDraft(null);
  };

  const addQuote = () => {
    if (!plan || !quoteDraft.trim()) return;
    mutate((state) => ({
      ...state,
      readingPlans: state.readingPlans.map((item) =>
        item.id === plan.id
          ? {
              ...item,
              quotes: [{ id: makeId("q"), author: "you", text: quoteDraft }, ...item.quotes],
            }
          : item,
      ),
    }));
    setQuoteDraft("");
    toast("Saved to our margins");
  };

  const addDiscussion = () => {
    if (!plan || !discussionDraft || !discussionDraft.text.trim()) return;
    mutate((state) => ({
      ...state,
      readingPlans: state.readingPlans.map((item) =>
        item.id === plan.id
          ? {
              ...item,
              discussion: [
                {
                  id: makeId("d"),
                  author: "you",
                  chapter: "This week",
                  prompt: discussionDraft.prompt,
                  text: discussionDraft.text,
                  date: new Date().toISOString(),
                },
                ...item.discussion,
              ],
            }
          : item,
      ),
    }));
    setDiscussionDraft(null);
    toast("Added to the shared journal");
  };

  const progressFor = (person: PersonId) => {
    if (!plan) return 0;
    const done = plan.chapters.filter((chapter) => chapter.progress[person] === "done").length;
    return Math.round((done / plan.chapters.length) * 100);
  };
  const sharedProgress = plan
    ? Math.round(
        (plan.chapters.filter((c) => c.progress.you === "done" && c.progress.me === "done").length /
          plan.chapters.length) *
          100,
      )
    : 0;

  return (
    <div className="flex flex-col gap-3.5">
      <PageHeading eyebrow="a cozy shared library" title="Reading Together" mascot="black">
        <Button
          variant="soft"
          size="sm"
          onClick={() =>
            setPlanDraft({
              title: "",
              kind: "Devotional",
              startDate: new Date().toISOString().slice(0, 10),
              targetDate: new Date(Date.now() + 86400000 * 30).toISOString().slice(0, 10),
              chapters: "",
            })
          }
        >
          <Plus className="h-3.5 w-3.5" /> New plan
        </Button>
        <Button variant="note" size="sm" onClick={scheduleSession} disabled={!plan}>
          <CalendarDays className="h-3.5 w-3.5" /> Schedule a session
        </Button>
      </PageHeading>

      {!plan ? (
        <SectionCard title="The shelf is waiting">
          <EmptyState
            mascot="black"
            title="No reading plan yet"
            note="Add a book or devotional, list the chapters, and tick each one as you go — together or on your own."
            action={
              <Button
                size="sm"
                variant="note"
                className="mt-1"
                onClick={() =>
                  setPlanDraft({
                    title: "",
                    kind: "Devotional",
                    startDate: new Date().toISOString().slice(0, 10),
                    targetDate: new Date(Date.now() + 86400000 * 30).toISOString().slice(0, 10),
                    chapters: "",
                  })
                }
              >
                <Plus className="h-3 w-3" /> Add our first plan
              </Button>
            }
          />
        </SectionCard>
      ) : (
        <>
          <div className="flex flex-wrap items-center gap-1.5">
            {data.readingPlans.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveId(item.id)}
                className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[0.66rem] font-bold transition",
                  plan.id === item.id
                    ? "border-sage/50 bg-sage-soft text-sage"
                    : "border-border/70 bg-card/80 text-muted-foreground hover:text-ink",
                )}
              >
                <BookOpen className="h-3 w-3" aria-hidden /> {item.title}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3.5 xl:grid-cols-12">
            <div className="flex flex-col gap-3 xl:col-span-8">
              <SectionCard
                title={plan.title}
                subtitle={`${plan.kind} · ${formatDateIn(new Date(plan.startDate), "UTC")} → ${formatDateIn(
                  new Date(plan.targetDate),
                  "UTC",
                )}`}
                action={
                  <span className="hand text-[0.95rem] text-sage">
                    {plan.chapters.filter((c) => c.progress.you === "done" && c.progress.me === "done").length}/
                    {plan.chapters.length} together
                  </span>
                }
              >
                <div className="mb-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
                  {(
                    [
                      { id: "you" as PersonId, label: data.people.you.nickname },
                      { id: "me" as PersonId, label: data.people.me.nickname },
                    ]
                  ).map((person) => (
                    <div key={person.id} className="rounded-xl bg-muted/50 p-2">
                      <div className="mb-1 flex items-center justify-between gap-2">
                        <span className="flex items-center gap-1 text-[0.64rem] font-bold">
                          <MascotAvatar
                            name={data.people[person.id].companion}
                            className="h-4 w-4"
                          />
                          {person.label}
                        </span>
                        <span className="text-[0.6rem] font-bold text-sage">{progressFor(person.id)}%</span>
                      </div>
                      <SoftProgress value={progressFor(person.id)} tone={person.id === "you" ? "sage" : "powder"} />
                    </div>
                  ))}
                  <div className="rounded-xl bg-sage-soft/60 p-2">
                    <div className="mb-1 flex items-center justify-between gap-2">
                      <span className="flex items-center gap-1 text-[0.64rem] font-bold">
                        <Sparkles className="h-3 w-3 text-sage" /> Together
                      </span>
                      <span className="text-[0.6rem] font-bold text-sage">{sharedProgress}%</span>
                    </div>
                    <SoftProgress value={sharedProgress} tone="sage" />
                  </div>
                </div>

                <ul className="flex flex-col divide-y divide-dashed divide-border/60">
                  {plan.chapters.map((chapter, index) => {
                    const shared = chapter.progress.you === "done" && chapter.progress.me === "done";
                    return (
                      <li key={chapter.id} className="flex flex-wrap items-center gap-2 py-1.5">
                        <span className="w-4 text-[0.6rem] font-bold text-muted-foreground">{index + 1}</span>
                        <span className="min-w-0 flex-1">
                          <span
                            className={cn(
                              "block text-[0.76rem] font-semibold leading-tight",
                              shared && "text-muted-foreground line-through",
                            )}
                          >
                            {chapter.title}
                          </span>
                          <span className="text-[0.56rem] text-muted-foreground">
                            {statusLabel[chapter.progress.you]} · {statusLabel[chapter.progress.me]}
                          </span>
                        </span>
                        <div className="flex items-center gap-1">
                          {(["you", "me"] as PersonId[]).map((person) => (
                            <button
                              key={person}
                              type="button"
                              onClick={() => cycleChapter(chapter.id, person)}
                              className={cn(
                                "rounded-full border px-2 py-0.5 text-[0.56rem] font-bold transition",
                                chapter.progress[person] === "done" &&
                                  "border-sage/40 bg-sage-soft text-sage",
                                chapter.progress[person] === "reading" &&
                                  "border-butter bg-butter-soft text-ink",
                                chapter.progress[person] === "todo" &&
                                  "border-border bg-card text-muted-foreground",
                              )}
                              aria-label={`Toggle ${data.people[person].nickname} on ${chapter.title}`}
                            >
                              {chapter.progress[person] === "done" ? (
                                <Check className="mr-0.5 inline h-2.5 w-2.5" />
                              ) : null}
                              {data.people[person].nickname}
                            </button>
                          ))}
                        </div>
                        {shared && (
                          <span className="rounded-full bg-sage px-1.5 py-0.5 text-[0.5rem] font-bold uppercase text-primary-foreground">
                            shared
                          </span>
                        )}
                      </li>
                    );
                  })}
                </ul>
              </SectionCard>

              <SectionCard
                title="Our discussion journal"
                subtitle="Answers we want to bring to the next call."
                action={
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setDiscussionDraft({ prompt: PROMPTS[0], text: "" })}
                  >
                    <Plus className="h-3 w-3" /> Add a thought
                  </Button>
                }
              >
                {plan.discussion.length === 0 ? (
                  <EmptyState
                    icon={<MessageSquareQuote className="h-5 w-5" />}
                    title="Nothing written yet"
                    note="What stood out to you this week? That's a good place to start."
                  />
                ) : (
                  <ul className="flex flex-col gap-2">
                    {plan.discussion.map((entry) => (
                      <li key={entry.id} className="rounded-xl border border-border/70 bg-card/80 p-2.5">
                        <p className="text-[0.58rem] font-bold uppercase tracking-wide text-sage">
                          {entry.prompt} · {entry.chapter}
                        </p>
                        <p className="mt-0.5 font-read text-[0.78rem] leading-snug text-ink-soft">
                          {entry.text}
                        </p>
                        <p className="mt-1 text-[0.54rem] text-muted-foreground">
                          {entry.author === "you" ? data.people.you.nickname : data.people.me.nickname} ·{" "}
                          {formatDateIn(new Date(entry.date), "UTC")}
                        </p>
                      </li>
                    ))}
                  </ul>
                )}
              </SectionCard>
            </div>

            <div className="flex flex-col gap-3 xl:col-span-4">
              <Panel
                title="Margins & favourite lines"
                icon={<Quote className="h-3.5 w-3.5 text-sage" aria-hidden />}
                action={<span>{plan.quotes.length} kept</span>}
              >
                <div className="flex gap-1.5">
                  <input
                    value={quoteDraft}
                    onChange={(event) => setQuoteDraft(event.target.value)}
                    placeholder="A line worth keeping…"
                    className="h-8 flex-1 rounded-lg border border-input bg-card px-2 text-[0.7rem]"
                  />
                  <Button size="sm" variant="soft" className="h-8 px-2" onClick={addQuote}>
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
                <ul className="mt-2 flex flex-col gap-1.5">
                  {plan.quotes.map((quote) => (
                    <li key={quote.id} className="rounded-lg bg-butter-soft/70 px-2 py-1.5">
                      <p className="font-read text-[0.72rem] italic leading-snug text-ink/80">“{quote.text}”</p>
                    </li>
                  ))}
                </ul>
              </Panel>

              <Panel title="Next reading session" icon={<Bookmark className="h-3.5 w-3.5 text-sage" aria-hidden />}>
                {(() => {
                  const dates = weekDates();
                  const windows = overlapWindows(data.people, 2, dates, data.events, 30);
                  if (!windows.length) {
                    return <p className="text-[0.68rem] text-muted-foreground">No shared window on Wednesday yet.</p>;
                  }
                  return (
                    <div className="rounded-xl bg-sage-soft/60 p-2.5">
                      <p className="text-[0.74rem] font-bold">
                        Wed · {formatClock(windows[0].start, data.people.you.timezone)} –{" "}
                        {formatClock(windows[0].end, data.people.you.timezone)}
                      </p>
                      <p className="text-[0.6rem] font-semibold text-ink-soft">
                        {formatDuration(windows[0].minutes)} together ·{" "}
                        {formatClock(windows[0].start, data.people.me.timezone)} for {data.people.me.nickname}
                      </p>
                    </div>
                  );
                })()}
                <Button size="sm" variant="outline" className="mt-2 w-full" onClick={scheduleSession}>
                  <CalendarDays className="h-3 w-3" /> Protect this time
                </Button>
              </Panel>

              <StickyNote tone="peach" className="mx-auto w-[86%] rotate-[1.2deg]">
                a little progress is still progress.
              </StickyNote>
            </div>
          </div>
        </>
      )}

      <Dialog open={Boolean(planDraft)} onOpenChange={(open) => !open && setPlanDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A new book for two</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Chapters can be days, passages or chapters — whatever fits.
            </DialogDescription>
          </DialogHeader>
          {planDraft && (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <TextField
                label="Title"
                value={planDraft.title}
                onChange={(event) => setPlanDraft({ ...planDraft, title: event.target.value })}
                className="sm:col-span-2"
                placeholder="The Purpose Driven Life"
              />
              <SelectField
                label="Kind"
                value={planDraft.kind}
                onChange={(value) => setPlanDraft({ ...planDraft, kind: value })}
                options={KIND_OPTIONS.map((kind) => ({ value: kind, label: kind }))}
              />
              <TextField
                label="Start"
                type="date"
                value={planDraft.startDate}
                onChange={(event) => setPlanDraft({ ...planDraft, startDate: event.target.value })}
              />
              <TextField
                label="Target finish"
                type="date"
                value={planDraft.targetDate}
                onChange={(event) => setPlanDraft({ ...planDraft, targetDate: event.target.value })}
              />
              <TextareaField
                label="Readings, one per line"
                value={planDraft.chapters}
                onChange={(event) => setPlanDraft({ ...planDraft, chapters: event.target.value })}
                className="sm:col-span-2"
                placeholder={"Day 1 · It all starts with God\nDay 2 · You are not an accident"}
                hint="Leave empty to start with a single placeholder chapter."
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setPlanDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={savePlan}>
              Add to the shelf
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(discussionDraft)} onOpenChange={(open) => !open && setDiscussionDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A thought for the call</DialogTitle>
          </DialogHeader>
          {discussionDraft && (
            <div className="space-y-2.5">
              <SelectField
                label="Prompt"
                value={discussionDraft.prompt}
                onChange={(value) => setDiscussionDraft({ ...discussionDraft, prompt: value })}
                options={PROMPTS.map((prompt) => ({ value: prompt, label: prompt }))}
              />
              <TextareaField
                label="Your answer"
                value={discussionDraft.text}
                onChange={(event) => setDiscussionDraft({ ...discussionDraft, text: event.target.value })}
              />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setDiscussionDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={addDiscussion}>
              Add to journal
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
