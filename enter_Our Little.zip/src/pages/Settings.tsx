import { useState } from "react";
import {
  Bell,
  Brush,
  Check,
  Copy,
  Heart,
  LogOut,
  LayoutDashboard,
  Palette,
  RotateCcw,
  Save,
  ShieldCheck,
} from "lucide-react";
import { toast } from "sonner";
import { useUniverse } from "@/store/universe";
import { ZONES } from "@/lib/types";
import type { PersonId, SettingsData } from "@/lib/types";
import { PageHeading, MascotAvatar } from "@/components/kit/bits";
import { Panel } from "@/components/kit/panel";
import { Field, SectionCard, SelectField, TextField } from "@/components/kit/controls";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

const COMPANION_OPTIONS: { value: "siamese" | "orange" | "black"; label: string }[] = [
  { value: "siamese", label: "Mochi — the calm Siamese" },
  { value: "orange", label: "Kyo — the playful orange cat" },
  { value: "black", label: "Yuki — the cosy black cat" },
];

const WIDGET_LABELS: Record<string, string> = {
  overview: "Today's little overview",
  planner: "Weekly planner preview",
  animals: "Our animal friends",
  quick: "Quick access",
  notifications: "Notifications",
  goals: "Shared goals",
  reflection: "Weekly reflection",
};

const WALLPAPERS: { value: SettingsData["wallpaper"]; label: string }[] = [
  { value: "room", label: "Sunlit room" },
  { value: "meadow", label: "Soft meadow" },
  { value: "dusk", label: "Dusk window" },
];

export default function Settings() {
  const { data, mutate, reset, joinCode, partnerJoined, email, syncState, signOut } = useUniverse();
  const settings = data.settings;
  const [draftNote, setDraftNote] = useState(settings.siteNote);
  const [draftVerse, setDraftVerse] = useState(settings.verse);

  const patchSettings = (patch: Partial<SettingsData>) =>
    mutate((state) => ({ ...state, settings: { ...state.settings, ...patch } }));

  const patchPerson = (personId: PersonId, patch: Partial<(typeof data.people)["you"]>) =>
    mutate((state) => ({
      ...state,
      people: { ...state.people, [personId]: { ...state.people[personId], ...patch } },
    }));

  return (
    <div className="flex flex-col gap-3.5">
      <PageHeading eyebrow="make it truly ours" title="Settings & Personalisation" mascot="black">
        <Button
          variant="soft"
          size="sm"
          onClick={() => {
            mutate((state) => ({
              ...state,
              settings: { ...state.settings, siteNote: draftNote, verse: draftVerse },
            }));
            toast("Our words are saved");
          }}
        >
          <Save className="h-3.5 w-3.5" /> Save our words
        </Button>
      </PageHeading>

      <div className="grid grid-cols-1 gap-3.5 xl:grid-cols-12">
        <div className="flex flex-col gap-3 xl:col-span-8">
          <div className="grid grid-cols-1 gap-3.5 md:grid-cols-2">
            {(["you", "me"] as PersonId[]).map((personId) => {
              const person = data.people[personId];
              return (
                <SectionCard
                  key={personId}
                  title={person.name}
                  subtitle="Names, place and the animal that feels like you."
                  action={<MascotAvatar name={person.companion} className="h-9 w-9" />}
                >
                  <div className="grid grid-cols-2 gap-2">
                    <TextField
                      label="Name"
                      value={person.name}
                      onChange={(event) => patchPerson(personId, { name: event.target.value })}
                    />
                    <TextField
                      label="Nickname"
                      value={person.nickname}
                      onChange={(event) => patchPerson(personId, { nickname: event.target.value })}
                    />
                    <TextField
                      label="City"
                      value={person.city}
                      onChange={(event) => patchPerson(personId, { city: event.target.value })}
                    />
                    <TextField
                      label="Country"
                      value={person.country}
                      onChange={(event) => patchPerson(personId, { country: event.target.value })}
                    />
                    <SelectField
                      label="Time zone"
                      value={person.timezone}
                      onChange={(value) => patchPerson(personId, { timezone: value })}
                      options={ZONES.map((zone) => ({
                        value: zone.id,
                        label: `${zone.city}, ${zone.country}`,
                      }))}
                      className="col-span-2"
                      hint="Real zone identifiers — daylight saving is handled automatically."
                    />
                    <SelectField
                      label="Companion"
                      value={person.companion}
                      onChange={(value) =>
                        patchPerson(personId, { companion: value as typeof person.companion })
                      }
                      options={COMPANION_OPTIONS}
                      className="col-span-2"
                    />
                    <Field label="Open from">
                      <input
                        type="time"
                        value={person.openFrom}
                        onChange={(event) => patchPerson(personId, { openFrom: event.target.value })}
                        className="h-10 w-full rounded-xl border border-input bg-card px-3 text-[0.85rem]"
                      />
                    </Field>
                    <Field label="Open until">
                      <input
                        type="time"
                        value={person.openTo}
                        onChange={(event) => patchPerson(personId, { openTo: event.target.value })}
                        className="h-10 w-full rounded-xl border border-input bg-card px-3 text-[0.85rem]"
                      />
                    </Field>
                  </div>
                </SectionCard>
              );
            })}
          </div>

          <SectionCard
            title="Our shared words"
            subtitle="Only what you write here appears on the dashboard — leave anything blank until you choose it."
            action={<Heart className="h-4 w-4 text-coral" aria-hidden />}
          >
            <div className="space-y-2.5">
              <Field label="Dashboard note">
                <input
                  value={draftNote}
                  onChange={(event) => setDraftNote(event.target.value)}
                  placeholder="A line you want to see every morning"
                  className="h-10 w-full rounded-xl border border-input bg-card px-3 text-[0.85rem]"
                />
              </Field>
              <Field label="Verse or affirmation">
                <textarea
                  value={draftVerse}
                  onChange={(event) => setDraftVerse(event.target.value)}
                  placeholder="A verse, a line from a song, anything you want to read each morning."
                  rows={2}
                  className="w-full rounded-xl border border-input bg-card px-3 py-2 font-read text-[0.85rem]"
                />
              </Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Our anniversary">
                  <input
                    type="date"
                    aria-label="Our anniversary"
                    value={settings.anniversary}
                    onChange={(event) => patchSettings({ anniversary: event.target.value })}
                    className="h-10 w-full rounded-xl border border-input bg-card px-3 text-[0.85rem]"
                  />
                </Field>
                <Field label="Theme">
                  <select
                    value={settings.theme}
                    onChange={(event) =>
                      patchSettings({ theme: event.target.value as SettingsData["theme"] })
                    }
                    className="h-10 w-full rounded-xl border border-input bg-card px-3 text-[0.85rem]"
                  >
                    <option value="light">Daylight</option>
                    <option value="dark">Dusk</option>
                  </select>
                </Field>
              </div>
            </div>
          </SectionCard>

          <SectionCard
            title="Home dashboard"
            subtitle="Choose which little rooms appear on your homepage."
            action={<LayoutDashboard className="h-4 w-4 text-sage" aria-hidden />}
          >
            <ul className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
              {Object.entries(settings.widgets).map(([key, value]) => (
                <li
                  key={key}
                  className="flex items-center justify-between gap-2 rounded-xl border border-border/70 bg-card/70 px-2.5 py-1.5"
                >
                  <span className="text-[0.72rem] font-semibold">{WIDGET_LABELS[key] ?? key}</span>
                  <Switch
                    checked={value}
                    aria-label={`Show ${WIDGET_LABELS[key] ?? key}`}
                    onCheckedChange={(checked) =>
                      patchSettings({ widgets: { ...settings.widgets, [key]: checked } })
                    }
                  />
                </li>
              ))}
            </ul>
          </SectionCard>
        </div>

        <div className="flex flex-col gap-3 xl:col-span-4">
          <Panel title="Look & feel" icon={<Palette className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <div className="space-y-2">
              <SelectField
                label="Wallpaper"
                value={settings.wallpaper}
                onChange={(value) => patchSettings({ wallpaper: value as SettingsData["wallpaper"] })}
                options={WALLPAPERS}
              />
              <div className="grid grid-cols-3 gap-1.5">
                {WALLPAPERS.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => patchSettings({ wallpaper: option.value })}
                    className={cn(
                      "relative h-12 overflow-hidden rounded-lg border-2 transition",
                      settings.wallpaper === option.value ? "border-sage" : "border-border/70",
                    )}
                    aria-label={option.label}
                  >
                    <span
                      className={cn(
                        "absolute inset-0",
                        option.value === "room" && "bg-gradient-to-br from-butter-soft via-card to-powder-soft",
                        option.value === "meadow" && "bg-gradient-to-br from-sage-soft via-card to-butter-soft",
                        option.value === "dusk" && "bg-gradient-to-br from-powder via-lilac to-blush",
                      )}
                    />
                    {settings.wallpaper === option.value && (
                      <Check className="absolute right-1 top-1 h-3 w-3 text-sage" />
                    )}
                  </button>
                ))}
              </div>

              <label className="flex items-center justify-between gap-2 rounded-xl border border-border/70 bg-card/70 px-2.5 py-1.5">
                <span className="text-[0.72rem] font-semibold">Reduced motion</span>
                <Switch
                  checked={settings.reducedMotion}
                  onCheckedChange={(checked) => patchSettings({ reducedMotion: checked })}
                  aria-label="Reduced motion"
                />
              </label>
              <label className="flex items-center justify-between gap-2 rounded-xl border border-border/70 bg-card/70 px-2.5 py-1.5">
                <span className="text-[0.72rem] font-semibold">Comfortable text size</span>
                <Switch
                  checked={settings.comfortText}
                  onCheckedChange={(checked) => patchSettings({ comfortText: checked })}
                  aria-label="Comfortable text size"
                />
              </label>
            </div>
          </Panel>

          <Panel title="Little notifications" icon={<Bell className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <ul className="flex flex-col gap-1.5">
              {(
                [
                  { key: "checkIns", label: "Gentle check-in nudges" },
                  { key: "prayers", label: "Prayer updates" },
                  { key: "reading", label: "Reading sessions" },
                  { key: "money", label: "Money talks" },
                ] as const
              ).map((item) => (
                <li
                  key={item.key}
                  className="flex items-center justify-between gap-2 rounded-xl bg-muted/40 px-2.5 py-1.5"
                >
                  <span className="text-[0.7rem] font-semibold">{item.label}</span>
                  <Switch
                    checked={settings.notifications[item.key]}
                    aria-label={item.label}
                    onCheckedChange={(checked) =>
                      patchSettings({
                        notifications: { ...settings.notifications, [item.key]: checked },
                      })
                    }
                  />
                </li>
              ))}
            </ul>
            <p className="mt-1.5 text-[0.58rem] text-muted-foreground">
              In-app only. No email or push reminders are connected yet.
            </p>
          </Panel>

          <Panel title="Our shared universe" icon={<ShieldCheck className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <div className="space-y-2">
              <div className="rounded-xl border border-dashed border-border bg-butter-soft/70 p-2.5 text-center">
                <p className="text-[0.56rem] font-bold uppercase tracking-[0.12em] text-muted-foreground">
                  Invite code
                </p>
                <p className="hand mt-0.5 text-[1.7rem] leading-none tracking-[0.25em] text-ink">{joinCode}</p>
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-1.5 h-7 bg-card text-[0.6rem]"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(joinCode);
                      toast("Code copied", { description: "Send it to your person, and only them." });
                    } catch {
                      toast("Copy the code by hand: " + joinCode);
                    }
                  }}
                >
                  <Copy className="h-3 w-3" /> Copy code
                </Button>
              </div>
              <div className="flex items-center justify-between gap-2 rounded-xl bg-muted/50 px-2.5 py-1.5">
                <span className="text-[0.66rem] font-semibold">Your partner</span>
                <span
                  className={cn(
                    "rounded-full px-2 py-0.5 text-[0.58rem] font-bold",
                    partnerJoined ? "bg-sage-soft text-sage" : "bg-peach text-accent-foreground",
                  )}
                >
                  {partnerJoined ? "joined" : "invite waiting"}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2 rounded-xl bg-muted/50 px-2.5 py-1.5">
                <span className="truncate text-[0.66rem] font-semibold">{email}</span>
                <span className="shrink-0 text-[0.56rem] font-bold uppercase tracking-wide text-muted-foreground">
                  {syncState === "saving" ? "saving…" : syncState === "error" ? "retrying" : "synced"}
                </span>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="w-full"
                onClick={async () => {
                  await signOut();
                  toast("Signed out — your universe waits for you");
                }}
              >
                <LogOut className="h-3 w-3" /> Sign out
              </Button>
              <p className="text-[0.58rem] leading-snug text-muted-foreground">
                Only the two of you can open this universe. Private prayers, memories and reflections are readable
                by their author alone, enforced by the database rather than hidden in the interface.
              </p>
            </div>
          </Panel>

          <Panel title="Start fresh" icon={<RotateCcw className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <p className="text-[0.66rem] leading-snug text-muted-foreground">
              Empties every section and leaves you a blank universe to write from scratch. Anything either of you has
              added will be replaced — there is no undo.
            </p>
            <Button
              variant="outline"
              size="sm"
              className="mt-1.5 w-full"
              onClick={() => {
                if (window.confirm("Empty the whole universe? Everything either of you has added will be removed.")) {
                  reset();
                  toast("A blank little universe, ready for you");
                }
              }}
            >
              <RotateCcw className="h-3 w-3" /> Empty our universe
            </Button>
          </Panel>

          <div className="paper-card grain flex items-center gap-2 p-3">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-butter-soft">
              <Brush className="h-4 w-4 text-sage" aria-hidden />
            </span>
            <p className="hand text-[1rem] leading-tight text-ink/75">
              built slowly, with our names on it.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
