import { useMemo, useRef, useState } from "react";
import {
  BookMarked,
  HandHeart,
  ImagePlus,
  Loader2,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { makeId, useUniverse } from "@/store/universe";
import { formatDateIn } from "@/lib/time";
import type { PrayerCard } from "@/lib/types";
import { PageHeading, MascotAvatar } from "@/components/kit/bits";
import { StickyNote } from "@/components/kit/panel";
import { EmptyState, SectionCard, SelectField, TextField, TextareaField } from "@/components/kit/controls";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { deletePrivateImage, imageUploadError, uploadPrivateImage } from "@/lib/keepsakes";
import { usePrivateImageUrls } from "@/hooks/use-private-images";
import { cn } from "@/lib/utils";

const STATUS_LABELS: Record<PrayerCard["status"], string> = {
  praying: "Praying",
  waiting: "Waiting",
  answered: "Answered",
  gratitude: "Gratitude",
};

const STATUS_TONES: Record<PrayerCard["status"], string> = {
  praying: "bg-sage-soft text-sage",
  waiting: "bg-butter text-ink",
  answered: "bg-sage text-primary-foreground",
  gratitude: "bg-blush text-ink",
};

const FILTERS: { id: "all" | PrayerCard["status"]; label: string }[] = [
  { id: "all", label: "Everything" },
  { id: "praying", label: "Praying" },
  { id: "waiting", label: "Waiting" },
  { id: "answered", label: "Answered" },
  { id: "gratitude", label: "Gratitude" },
];

const emptyCard = (): PrayerCard => ({
  id: makeId("prayer-card"),
  title: "",
  description: "",
  scripture: "",
  status: "praying",
  person: "both",
  createdAt: new Date().toISOString(),
});

export default function PrayerBoard() {
  const { data, mutate, spaceId } = useUniverse();
  const [filter, setFilter] = useState<"all" | PrayerCard["status"]>("all");
  const [draft, setDraft] = useState<PrayerCard | null>(null);
  const [note, setNote] = useState(data.prayerBoardNote);
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const imagePaths = useMemo(
    () => data.prayerCards.map((card) => card.imagePath).filter((path): path is string => Boolean(path)),
    [data.prayerCards],
  );
  const imageUrls = usePrivateImageUrls(imagePaths);

  const cards = [...data.prayerCards]
    .filter((card) => (filter === "all" ? true : card.status === filter))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  const counted = (status: PrayerCard["status"]) =>
    data.prayerCards.filter((card) => card.status === status).length;

  const openCard = (card: PrayerCard) => {
    setDraft({ ...card });
    setPreview(null);
  };

  const closeDialog = () => {
    setDraft(null);
    setPreview(null);
  };

  const pickImage = async (file?: File) => {
    if (!file) return;
    const problem = imageUploadError(file);
    if (problem) {
      toast(problem);
      return;
    }
    setUploading(true);
    try {
      const path = await uploadPrivateImage(spaceId, file);
      setDraft((current) => (current ? { ...current, imagePath: path } : current));
      setPreview(URL.createObjectURL(file));
    } catch (error) {
      toast("That photo didn't upload", {
        description: error instanceof Error ? error.message : "Try a smaller file?",
      });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const saveCard = () => {
    if (!draft || !draft.title.trim()) {
      toast("Give this prayer a short title");
      return;
    }
    mutate((state) => {
      const exists = state.prayerCards.some((card) => card.id === draft.id);
      return {
        ...state,
        prayerCards: exists
          ? state.prayerCards.map((card) => (card.id === draft.id ? draft : card))
          : [draft, ...state.prayerCards],
      };
    });
    toast(draft.status === "answered" ? "Kept as an answered prayer" : "Pinned to our board");
    closeDialog();
  };

  const removeCard = async () => {
    if (!draft) return;
    if (!window.confirm("Remove this card from the prayer board?")) return;
    if (draft.imagePath) await deletePrivateImage(draft.imagePath);
    mutate((state) => ({
      ...state,
      prayerCards: state.prayerCards.filter((card) => card.id !== draft.id),
    }));
    toast("Card removed");
    closeDialog();
  };

  const saveNote = () => {
    mutate((state) => ({ ...state, prayerBoardNote: note }));
    toast("Saved what we're holding");
  };

  const personName = (person: PrayerCard["person"]) =>
    person === "both"
      ? "Both of us"
      : person === "you"
        ? data.people.you.name
        : data.people.me.name;

  return (
    <div className="flex flex-col gap-3.5">
      <PageHeading eyebrow="held up together" title="Our Prayer Board" mascot="parakeet">
        <Button
          variant="note"
          size="sm"
          onClick={() => {
            setDraft(emptyCard());
            setPreview(null);
          }}
        >
          <Plus className="h-3.5 w-3.5" /> Add a prayer card
        </Button>
      </PageHeading>

      <p className="rounded-2xl border border-dashed border-border/80 bg-card/60 px-3 py-2 text-[0.68rem] leading-snug text-muted-foreground">
        Pin the things you are praying for — a photo of the person, a verse, a situation. When one is answered it stays
        here as gratitude, so you can see the whole story.
      </p>

      <SectionCard
        title="What we're holding together"
        subtitle="A short note for this season — editable whenever it changes."
        action={<HandHeart className="h-4 w-4 text-sage" aria-hidden />}
      >
        <div className="flex flex-col gap-2">
          <textarea
            value={note}
            onChange={(event) => setNote(event.target.value)}
            rows={2}
            placeholder="For this season, we are holding…"
            className="w-full rounded-2xl border border-input bg-butter-soft/40 px-3 py-2 font-read text-[0.84rem] leading-snug text-ink-soft"
          />
          <div className="flex items-center justify-between gap-2">
            <p className="text-[0.6rem] text-muted-foreground">Shared with both of you.</p>
            <Button size="sm" variant="soft" onClick={saveNote}>
              Save note
            </Button>
          </div>
        </div>
      </SectionCard>

      <div className="flex flex-wrap items-center gap-1.5">
        {FILTERS.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => setFilter(option.id)}
            className={cn(
              "rounded-full border px-2.5 py-1 text-[0.66rem] font-bold transition",
              filter === option.id
                ? "border-sage/50 bg-sage text-primary-foreground shadow-sm"
                : "border-border/70 bg-card/80 text-muted-foreground hover:text-ink",
            )}
          >
            {option.label}
            {option.id !== "all" && counted(option.id) > 0 ? ` · ${counted(option.id)}` : ""}
          </button>
        ))}
      </div>

      {cards.length === 0 ? (
        <SectionCard title="The board is waiting">
          <EmptyState
            mascot="parakeet"
            title={data.prayerCards.length ? "Nothing in this list yet" : "Nothing pinned yet"}
            note="Start with one thing you are carrying. Add a photo if a face helps you pray, or just a name and a verse."
            action={
              <Button
                size="sm"
                variant="note"
                className="mt-1"
                onClick={() => {
                  setDraft(emptyCard());
                  setPreview(null);
                }}
              >
                <Plus className="h-3 w-3" /> Pin our first prayer
              </Button>
            }
          />
        </SectionCard>
      ) : (
        <div className="columns-1 gap-3.5 sm:columns-2 xl:columns-3 [&>*]:mb-3.5">
          {cards.map((card, index) => {
            const image = card.imagePath ? imageUrls[card.imagePath] : undefined;
            return (
              <button
                key={card.id}
                type="button"
                onClick={() => openCard(card)}
                className={cn(
                  "grain block w-full break-inside-avoid overflow-hidden rounded-3xl border border-border/70 bg-card text-left shadow-card transition duration-300 hover:-translate-y-1 hover:shadow-lift",
                  index % 3 === 0 && "bg-card",
                  index % 3 === 1 && "bg-butter-soft/50",
                  index % 3 === 2 && "bg-blush/40",
                )}
              >
                {image && (
                  <img
                    src={image}
                    alt={card.title}
                    loading="lazy"
                    className="max-h-60 w-full object-cover"
                  />
                )}
                <div className="flex flex-col gap-1.5 p-3.5">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[0.56rem] font-bold uppercase tracking-wide",
                        STATUS_TONES[card.status],
                      )}
                    >
                      {STATUS_LABELS[card.status]}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[0.56rem] font-semibold text-muted-foreground">
                      <MascotAvatar
                        name={card.person === "me" ? data.people.me.companion : data.people.you.companion}
                        className="h-3.5 w-3.5"
                      />
                      {personName(card.person)}
                    </span>
                  </div>

                  <h3 className="hand text-[1.35rem] leading-tight text-ink/85">{card.title}</h3>
                  {card.description && (
                    <p className="font-read text-[0.78rem] leading-snug text-ink-soft">{card.description}</p>
                  )}
                  {card.scripture && (
                    <p className="inline-flex items-center gap-1 text-[0.62rem] font-semibold text-sage">
                      <BookMarked className="h-3 w-3" aria-hidden /> {card.scripture}
                    </p>
                  )}
                  <div className="mt-0.5 flex items-center justify-between gap-2 border-t border-dashed border-border/70 pt-1.5">
                    <span className="text-[0.56rem] font-semibold text-muted-foreground">
                      {formatDateIn(new Date(card.createdAt), "UTC")}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[0.56rem] font-bold text-sage">
                      <Pencil className="h-2.5 w-2.5" aria-hidden /> open card
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      <StickyNote tone="butter" className="mx-auto w-fit rotate-[-1deg] px-4">
        answered prayers stay as gratitude, not as proof of timing.
      </StickyNote>

      <Dialog open={Boolean(draft)} onOpenChange={(open) => !open && closeDialog()}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle className="hand text-[1.55rem]">
              {draft && data.prayerCards.some((card) => card.id === draft.id)
                ? "This prayer we're carrying"
                : "A new prayer to pin"}
            </DialogTitle>
            <DialogDescription className="text-[0.72rem]">
              A photo, a name, a verse — whatever helps you hold it together.
            </DialogDescription>
          </DialogHeader>

          {draft && (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <TextField
                label="Title"
                value={draft.title}
                onChange={(event) => setDraft({ ...draft, title: event.target.value })}
                placeholder="Navi's work, Mama's health…"
                className="sm:col-span-2"
              />
              <TextareaField
                label="What are we asking for?"
                value={draft.description}
                onChange={(event) => setDraft({ ...draft, description: event.target.value })}
                className="sm:col-span-2"
              />
              <TextField
                label="Scripture (optional)"
                value={draft.scripture ?? ""}
                onChange={(event) => setDraft({ ...draft, scripture: event.target.value })}
                placeholder="Psalm 23"
              />
              <SelectField
                label="For whom?"
                value={draft.person}
                onChange={(value) => setDraft({ ...draft, person: value as PrayerCard["person"] })}
                options={[
                  { value: "both", label: "Both of us" },
                  { value: "you", label: data.people.you.name },
                  { value: "me", label: data.people.me.name },
                ]}
              />
              <SelectField
                label="Where it is now"
                value={draft.status}
                onChange={(value) => setDraft({ ...draft, status: value as PrayerCard["status"] })}
                options={Object.entries(STATUS_LABELS).map(([value, label]) => ({ value, label }))}
                className="sm:col-span-2"
              />

              <div className="sm:col-span-2">
                <p className="mb-1 text-[0.68rem] font-bold uppercase tracking-[0.08em] text-muted-foreground">
                  A photo (optional)
                </p>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp,image/gif"
                  className="sr-only"
                  onChange={(event) => void pickImage(event.target.files?.[0])}
                />
                <div className="flex items-center gap-2.5 rounded-2xl border border-dashed border-border/80 bg-muted/30 p-2">
                  <div className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-xl bg-card">
                    {preview || (draft.imagePath && imageUrls[draft.imagePath]) ? (
                      <img
                        src={preview ?? imageUrls[draft.imagePath!]}
                        alt=""
                        className="h-full w-full object-cover"
                      />
                    ) : uploading ? (
                      <Loader2 className="h-4 w-4 animate-spin text-sage" aria-hidden />
                    ) : (
                      <ImagePlus className="h-4 w-4 text-sage/70" aria-hidden />
                    )}
                  </div>
                  <div className="flex flex-1 flex-wrap items-center gap-1.5">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 bg-card text-[0.62rem]"
                      onClick={() => fileRef.current?.click()}
                      disabled={uploading}
                    >
                      {uploading ? <Loader2 className="h-3 w-3 animate-spin" /> : <ImagePlus className="h-3 w-3" />}
                      {draft.imagePath ? "Replace photo" : "Add a photo"}
                    </Button>
                    {draft.imagePath && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 text-[0.6rem]"
                        onClick={() => {
                          setDraft({ ...draft, imagePath: undefined });
                          setPreview(null);
                        }}
                      >
                        Remove
                      </Button>
                    )}
                    <p className="w-full text-[0.55rem] text-muted-foreground">
                      Private to the two of you · up to 10 MB.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            {draft && data.prayerCards.some((card) => card.id === draft.id) && (
              <Button variant="ghost" size="sm" onClick={() => void removeCard()}>
                <Trash2 className="h-3.5 w-3.5" /> Remove
              </Button>
            )}
            <Button variant="soft" size="sm" onClick={closeDialog}>
              Cancel
            </Button>
            <Button size="sm" onClick={saveCard}>
              {draft && data.prayerCards.some((card) => card.id === draft.id) ? "Save card" : "Pin it"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
