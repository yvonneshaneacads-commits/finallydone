import { useEffect, useMemo, useRef, useState } from "react";
import { CalendarHeart, Camera, Heart, ImagePlus, Loader2, Lock, Mail, MailOpen, Pencil, Plus, Search, Stamp, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { makeId, useUniverse } from "@/store/universe";
import { formatDateIn } from "@/lib/time";
import { PageHeading, MascotAvatar, Pill } from "@/components/kit/bits";
import { Panel, StickyNote } from "@/components/kit/panel";
import { EmptyState, SectionCard, SelectField, TextField, TextareaField } from "@/components/kit/controls";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { deletePrivateImage, imageUploadError, uploadPrivateImage } from "@/lib/keepsakes";
import { usePrivateImageUrls } from "@/hooks/use-private-images";
import type { Keepsake, Memory, OpenWhenLetter, PersonId } from "@/lib/types";
const KINDS: Memory["kind"][] = ["letter", "photo", "moment", "milestone", "date"];
const PALETTES: Record<Memory["palette"], string> = {
  peach: "bg-peach-soft",
  powder: "bg-powder-soft",
  butter: "bg-butter-soft",
  sage: "bg-sage-soft/80",
  lilac: "bg-lilac"
};
const OCCASIONS = ["When you miss me", "When you need encouragement", "When you had a difficult day", "When you accomplish something", "On your birthday", "On our anniversary", "When we finally see each other"];
export default function Memories() {
  const {
    data,
    mutate,
    spaceId
  } = useUniverse();
  const [filter, setFilter] = useState<"all" | Memory["kind"]>("all");
  const [query, setQuery] = useState("");
  const [memoryDraft, setMemoryDraft] = useState<Memory | null>(null);
  const [letterDraft, setLetterDraft] = useState<OpenWhenLetter | null>(null);
  const [openLetter, setOpenLetter] = useState<OpenWhenLetter | null>(null);
  const [editingAnniversary, setEditingAnniversary] = useState(false);
  const [uploadingKeepsake, setUploadingKeepsake] = useState(false);
  const [memoryUploading, setMemoryUploading] = useState(false);
  const [memoryPreview, setMemoryPreview] = useState<string | null>(null);
  const memoryFileInput = useRef<HTMLInputElement>(null);
  const [viewingKeepsake, setViewingKeepsake] = useState<Keepsake | null>(null);
  const [keepsakeDraft, setKeepsakeDraft] = useState({
    title: "",
    note: ""
  });
  const keepsakeInput = useRef<HTMLInputElement>(null);
  const imagePaths = useMemo(() => {
    const keepsakes = data.keepsakes.map(keepsake => keepsake.path);
    const memories = data.memories.map(memory => memory.imagePath).filter((path): path is string => Boolean(path));
    return [...keepsakes, ...memories];
  }, [data.keepsakes, data.memories]);
  const imageUrls = usePrivateImageUrls(imagePaths);
  useEffect(() => {
    setMemoryPreview(null);
  }, [memoryDraft?.id]);
  const addKeepsakes = async (files: FileList | null) => {
    if (!files?.length || uploadingKeepsake) return;
    setUploadingKeepsake(true);
    const added: Keepsake[] = [];
    for (const file of Array.from(files).slice(0, 6)) {
      const problem = imageUploadError(file);
      if (problem) {
        toast(problem);
        continue;
      }
      try {
        const path = await uploadPrivateImage(spaceId, file);
        added.push({
          id: makeId("keep"),
          title: file.name.replace(/\.[^.]+$/, "").slice(0, 60) || "A little keepsake",
          path,
          note: "",
          date: new Date().toISOString().slice(0, 10),
          author: "you"
        });
      } catch (error) {
        toast("That photo didn't upload", {
          description: error instanceof Error ? error.message : "Try a smaller file?"
        });
      }
    }
    setUploadingKeepsake(false);
    if (keepsakeInput.current) keepsakeInput.current.value = "";
    if (!added.length) return;
    mutate(state => ({
      ...state,
      keepsakes: [...added, ...state.keepsakes]
    }));
    toast(`${added.length} keepsake${added.length === 1 ? "" : "s"} tucked away safely`, {
      description: "Only the two of you can open them."
    });
  };
  const openKeepsake = (keepsake: Keepsake) => {
    setViewingKeepsake(keepsake);
    setKeepsakeDraft({
      title: keepsake.title,
      note: keepsake.note
    });
  };
  const saveKeepsakeDraft = () => {
    if (!viewingKeepsake) return;
    mutate(state => ({
      ...state,
      keepsakes: state.keepsakes.map(keepsake => keepsake.id === viewingKeepsake.id ? {
        ...keepsake,
        title: keepsakeDraft.title,
        note: keepsakeDraft.note
      } : keepsake)
    }));
    setViewingKeepsake(null);
    toast("Keepsake updated");
  };
  const removeKeepsake = async () => {
    if (!viewingKeepsake) return;
    if (!window.confirm("Remove this keepsake? The photo is deleted for both of you.")) return;
    await deletePrivateImage(viewingKeepsake.path);
    mutate(state => ({
      ...state,
      keepsakes: state.keepsakes.filter(keepsake => keepsake.id !== viewingKeepsake.id)
    }));
    setViewingKeepsake(null);
    toast("Keepsake removed");
  };
  const today = new Date().toISOString().slice(0, 10);
  const memories = useMemo(() => {
    return [...data.memories].filter(memory => filter === "all" ? true : memory.kind === filter).filter(memory => query.trim() ? `${memory.title} ${memory.body} ${memory.tags.join(" ")}`.toLowerCase().includes(query.toLowerCase()) : true).sort((a, b) => b.date.localeCompare(a.date));
  }, [data.memories, filter, query]);
  const pickMemoryImage = async (file?: File) => {
    if (!file || !memoryDraft) return;
    const problem = imageUploadError(file);
    if (problem) {
      toast(problem);
      return;
    }
    setMemoryUploading(true);
    try {
      const path = await uploadPrivateImage(spaceId, file);
      setMemoryDraft({
        ...memoryDraft,
        imagePath: path
      });
      setMemoryPreview(URL.createObjectURL(file));
    } catch (error) {
      toast("That photo didn't upload", {
        description: error instanceof Error ? error.message : "Try a smaller file?"
      });
    } finally {
      setMemoryUploading(false);
      if (memoryFileInput.current) memoryFileInput.current.value = "";
    }
  };
  const saveMemory = () => {
    if (!memoryDraft || !memoryDraft.title.trim()) {
      toast("Give this memory a title");
      return;
    }
    mutate(state => {
      const exists = state.memories.some(memory => memory.id === memoryDraft.id);
      return {
        ...state,
        memories: exists ? state.memories.map(memory => memory.id === memoryDraft.id ? memoryDraft : memory) : [memoryDraft, ...state.memories]
      };
    });
    const exists = data.memories.some(memory => memory.id === memoryDraft.id);
    setMemoryDraft(null);
    toast(exists ? "Memory updated" : "A new memory has found its home");
  };
  const deleteMemory = async (memory: Memory) => {
    if (!window.confirm(`Delete “${memory.title}”? ${memory.imagePath ? "Its photo is removed too. " : ""}This cannot be undone.`)) {
      return;
    }
    if (memory.imagePath) {
      await deletePrivateImage(memory.imagePath);
    }
    mutate(state => ({
      ...state,
      memories: state.memories.filter(item => item.id !== memory.id)
    }));
    setMemoryDraft(null);
    setMemoryPreview(null);
    toast("Memory deleted");
  };
  const saveLetter = () => {
    if (!letterDraft || !letterDraft.title.trim()) {
      toast("A letter needs a title");
      return;
    }
    mutate(state => {
      const exists = state.openWhen.some(letter => letter.id === letterDraft.id);
      return {
        ...state,
        openWhen: exists ? state.openWhen.map(letter => letter.id === letterDraft.id ? letterDraft : letter) : [...state.openWhen, letterDraft]
      };
    });
    setLetterDraft(null);
    toast("Sealed and kept");
  };
  return <div className="flex flex-col gap-3.5">
      <PageHeading eyebrow="our little time capsule" title="Memories & Letters" mascot="orange">
        <Button variant="soft" size="sm" onClick={() => setLetterDraft({
        id: makeId("ow"),
        occasion: OCCASIONS[0],
        title: "",
        body: "",
        from: "you"
      })}>
          <Mail className="h-3.5 w-3.5" /> Seal a letter
        </Button>
        <Button variant="note" size="sm" onClick={() => setMemoryDraft({
        id: makeId("memory"),
        title: "",
        date: today,
        body: "",
        tags: [],
        kind: "moment",
        visibility: "shared",
        author: "you",
        palette: "peach"
      })}>
          <Plus className="h-3.5 w-3.5" /> Add a memory
        </Button>
      </PageHeading>

      <div className="flex flex-wrap items-center gap-1.5">
        {(["all", ...KINDS] as const).map(kind => <button key={kind} type="button" onClick={() => setFilter(kind)} className={cn("rounded-full border px-2.5 py-1 text-[0.64rem] font-bold capitalize transition", filter === kind ? "border-sage/50 bg-sage text-primary-foreground" : "border-border/70 bg-card/80 text-muted-foreground hover:text-ink")}>
            {kind}
          </button>)}
        <label className="ml-auto flex items-center gap-1.5 rounded-full border border-border/70 bg-card/80 px-2.5 py-1">
          <Search className="h-3 w-3 text-muted-foreground" aria-hidden />
          <input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search our scrapbook" className="w-36 bg-transparent text-[0.68rem] outline-none" />
        </label>
      </div>

      <div className="grid grid-cols-1 gap-3.5 xl:grid-cols-12">
        <div className="xl:col-span-8">
          {memories.length === 0 ? <SectionCard title="An empty page, for now">
              <EmptyState mascot="orange" title="Nothing kept here yet" note="Start with one memory: a first call, a parcel, an ordinary evening. Add a date and a few lines, and it lives here." action={<Button size="sm" variant="note" className="mt-1" onClick={() => setMemoryDraft({
            id: makeId("memory"),
            title: "",
            date: today,
            body: "",
            tags: [],
            kind: "moment",
            visibility: "shared",
            author: "you",
            palette: "peach"
          })}>
                    <Plus className="h-3 w-3" /> Keep our first memory
                  </Button>} />
            </SectionCard> : <div className="columns-1 gap-3 sm:columns-2 [&>*]:mb-3">
              {memories.map((memory, index) => (
                <article
                  key={memory.id}
                  className={cn(
                    "grain relative break-inside-avoid rounded-xl border border-border/70 p-3 shadow-card",
                    PALETTES[memory.palette],
                    index % 4 === 0 ? "rotate-[0.5deg]" : index % 4 === 2 ? "-rotate-[0.4deg]" : ""
                  )}
                >
                  <span className="washi absolute -top-2 left-4 h-4 w-12 rotate-[-4deg] rounded-[2px] opacity-80" />
                  <div className="mb-1 flex items-start justify-between gap-2">
                    <div>
                      <p className="text-[0.58rem] font-bold uppercase tracking-[0.12em] text-muted-foreground">
                        {memory.kind} · {formatDateIn(new Date(memory.date), "UTC", true)}
                      </p>
                      <h3 className="hand text-[1.2rem] leading-tight text-ink/85">{memory.title}</h3>
                    </div>
                    {memory.visibility === "private" ? (
                      <Pill tone="cream">
                        <Lock className="h-2.5 w-2.5" /> private
                      </Pill>
                    ) : (
                      <Heart className="mt-1 h-3 w-3 shrink-0 text-coral/70" aria-hidden />
                    )}
                  </div>

                  {memory.imagePath && imageUrls[memory.imagePath] && (
                    <img
                      src={imageUrls[memory.imagePath]}
                      alt={memory.title}
                      loading="lazy"
                      className="mb-2 max-h-64 w-full rounded-xl border border-border/60 object-cover"
                    />
                  )}

                  <p className="font-read text-[0.78rem] leading-snug text-ink-soft">{memory.body}</p>

                  <div className="mt-1.5 flex flex-wrap items-center gap-1">
                    {memory.tags.map(tag => (
                      <span
                        key={tag}
                        className="rounded-full bg-card/70 px-1.5 py-0.5 text-[0.54rem] font-semibold text-ink-soft"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <div className="mt-1.5 flex items-center justify-between gap-2 border-t border-dashed border-border/60 pt-1.5">
                    <span className="flex items-center gap-1 text-[0.56rem] text-muted-foreground">
                      <MascotAvatar
                        name={memory.author === "you" ? data.people.you.companion : data.people.me.companion}
                        className="h-3.5 w-3.5"
                      />
                      {memory.author === "you" ? data.people.you.name : data.people.me.name}
                    </span>
                    <span className="flex items-center gap-0.5">
                      <button
                        type="button"
                        aria-label={`Edit ${memory.title}`}
                        title="Edit this memory"
                        onClick={() => {
                          setMemoryDraft({ ...memory });
                          setMemoryPreview(null);
                        }}
                        className="grid h-6 w-6 place-items-center rounded-full text-ink-soft transition hover:bg-card/80 hover:text-sage"
                      >
                        <Pencil className="h-3 w-3" />
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete ${memory.title}`}
                        title="Delete this memory"
                        onClick={() => void deleteMemory(memory)}
                        className="grid h-6 w-6 place-items-center rounded-full text-ink-soft transition hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </span>
                  </div>
                </article>
              ))}
            </div>}
        </div>

        <div className="flex flex-col gap-3 xl:col-span-4">
          <Panel title="Open when…" icon={<MailOpen className="h-3.5 w-3.5 text-sage" aria-hidden />} action={<span>{data.openWhen.length} letters</span>}>
            <ul className="flex flex-col gap-2">
              {data.openWhen.map(letter => {
              const sealed = letter.sealUntil ? letter.sealUntil > today : false;
              return <li key={letter.id} className="rounded-xl border border-border/70 bg-card/85 p-2.5 shadow-sm">
                    <p className="text-[0.56rem] font-bold uppercase tracking-wide text-sage">{letter.occasion}</p>
                    <p className="hand text-[1.05rem] leading-tight">{letter.title}</p>
                    {sealed ? <p className="mt-1 flex items-center gap-1 text-[0.62rem] text-muted-foreground">
                        <Lock className="h-3 w-3" /> Sealed until{" "}
                        {formatDateIn(new Date(letter.sealUntil!), "UTC", true)}
                      </p> : <Button size="sm" variant="ghost" className="mt-1 h-6 px-1.5 text-[0.6rem]" onClick={() => setOpenLetter(letter)}>
                        <MailOpen className="h-3 w-3" /> Open this letter
                      </Button>}
                  </li>;
            })}
              {data.openWhen.length === 0 && <li className="rounded-lg border border-dashed border-border/80 bg-card/60 px-2 py-2 text-[0.62rem] leading-snug text-muted-foreground">
                  No letters yet. Write one for a hard day, a birthday, or the day you finally see each other.
                </li>}
            </ul>
          </Panel>

          <Panel title="Our dates" icon={<CalendarHeart className="h-3.5 w-3.5 text-sage" aria-hidden />}>
            <ul className="flex flex-col gap-1.5 text-[0.68rem]">
              <li className="flex items-center justify-between gap-2 rounded-lg bg-blush/70 px-2 py-1.5">
                <span className="font-semibold">Our anniversary</span>
                {editingAnniversary ? <input type="date" autoFocus aria-label="Our anniversary date" value={data.settings.anniversary} onChange={event => mutate(state => ({
                ...state,
                settings: {
                  ...state.settings,
                  anniversary: event.target.value
                }
              }))} onBlur={() => {
                setEditingAnniversary(false);
                toast("Anniversary saved", {
                  description: "Your day counter and dates now use it."
                });
              }} onKeyDown={event => {
                if (event.key === "Enter") event.currentTarget.blur();
                if (event.key === "Escape") setEditingAnniversary(false);
              }} className="h-7 rounded-lg border border-border bg-card px-1.5 text-[0.68rem] font-bold text-ink" /> : <button type="button" onClick={() => setEditingAnniversary(true)} className="inline-flex shrink-0 items-center gap-1 rounded-full px-1.5 py-0.5 font-bold transition hover:bg-card/80" aria-label="Edit our anniversary date" title="Edit our anniversary">
                    {data.settings.anniversary ? formatDateIn(new Date(data.settings.anniversary), "UTC", true) : "Set our date"}
                    <Pencil className="h-2.5 w-2.5 text-muted-foreground" aria-hidden />
                  </button>}
              </li>
              {data.memories.filter(memory => memory.kind === "date" || memory.kind === "milestone").slice(0, 3).map(memory => <li key={memory.id} className="flex items-center justify-between gap-2 rounded-lg bg-muted/50 px-2 py-1.5">
                    <span className="truncate font-semibold">{memory.title}</span>
                    <button type="button" onClick={() => setMemoryDraft({
                ...memory
              })} className="inline-flex shrink-0 items-center gap-1 rounded-full px-1.5 py-0.5 text-muted-foreground transition hover:bg-card/80 hover:text-ink" aria-label={`Edit the date for ${memory.title}`} title="Edit this date">
                      {formatDateIn(new Date(memory.date), "UTC")}
                      <Pencil className="h-2.5 w-2.5" aria-hidden />
                    </button>
                  </li>)}
              <li className="px-1 pt-0.5 text-[0.58rem] text-muted-foreground">
                Tap any date to change it — memories open with their full details.
              </li>
            </ul>
          </Panel>

          <StickyNote tone="blush" className="mx-auto w-[88%] rotate-[1.2deg]">
            a new memory has found its home.
          </StickyNote>

          <Panel title="Stamps & keepsakes" icon={<Stamp className="h-3.5 w-3.5 text-sage" aria-hidden />} action={<span>{data.keepsakes.length ? `${data.keepsakes.length} kept` : "nothing yet"}</span>}>
            <input ref={keepsakeInput} type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple className="sr-only" onChange={event => void addKeepsakes(event.target.files)} />

            {data.keepsakes.length === 0 ? <button type="button" onClick={() => keepsakeInput.current?.click()} className="flex w-full flex-col items-center gap-1.5 rounded-2xl border border-dashed border-border/80 bg-card/60 px-3 py-5 text-center transition hover:bg-card">
                {uploadingKeepsake ? <Loader2 className="h-5 w-5 animate-spin text-sage" aria-hidden /> : <ImagePlus className="h-5 w-5 text-sage" aria-hidden />}
                <span className="hand text-[1.1rem] leading-tight text-ink/80">Keep a little something</span>
                <span className="text-[0.66rem] leading-snug text-muted-foreground">
                  A parcel, a screenshot of a call, a ticket stub — JPG, PNG, WEBP or GIF up to 10 MB.
                </span>
              </button> : <div className="grid grid-cols-2 gap-2">
                {data.keepsakes.map(keepsake => <button key={keepsake.id} type="button" onClick={() => openKeepsake(keepsake)} className="group overflow-hidden rounded-2xl border border-border/70 bg-card text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-note">
                    <span className="relative block aspect-square overflow-hidden bg-muted">
                      {imageUrls[keepsake.path] ? <img src={imageUrls[keepsake.path]} alt={keepsake.title} loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /> : <span className="grid h-full w-full place-items-center text-sage/50">
                          <Camera className="h-5 w-5" aria-hidden />
                        </span>}
                    </span>
                    <span className="block px-2 py-1.5">
                      <span className="block truncate text-[0.68rem] font-bold leading-tight">
                        {keepsake.title}
                      </span>
                      <span className="block text-[0.56rem] text-muted-foreground">
                        {formatDateIn(new Date(keepsake.date), "UTC")}
                      </span>
                    </span>
                  </button>)}

                <button type="button" onClick={() => keepsakeInput.current?.click()} className="flex aspect-square flex-col items-center justify-center gap-1 rounded-2xl border border-dashed border-border/80 bg-card/50 text-muted-foreground transition hover:bg-card hover:text-sage">
                  {uploadingKeepsake ? <Loader2 className="h-5 w-5 animate-spin" aria-hidden /> : <Plus className="h-5 w-5" aria-hidden />}
                  <span className="text-[0.6rem] font-semibold">Add another</span>
                </button>
              </div>}

            <p className="mt-2 text-[0.58rem] leading-snug text-muted-foreground">
              {uploadingKeepsake ? "Tucking it away…" : "Stored privately — only the two of you can open these photos."}
            </p>
          </Panel>
        </div>
      </div>

      <Dialog open={Boolean(memoryDraft)} onOpenChange={open => {
      if (!open) {
        setMemoryDraft(null);
        setMemoryPreview(null);
      }
    }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">Keep this one</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              A moment, a photo caption, a letter — whatever you want to find again.
            </DialogDescription>
          </DialogHeader>
          {memoryDraft && <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <TextField label="Title" value={memoryDraft.title} onChange={event => setMemoryDraft({
            ...memoryDraft,
            title: event.target.value
          })} className="sm:col-span-2" />
              <TextField label="Date" type="date" value={memoryDraft.date} onChange={event => setMemoryDraft({
            ...memoryDraft,
            date: event.target.value
          })} />
              <SelectField label="Kind" value={memoryDraft.kind} onChange={value => setMemoryDraft({
            ...memoryDraft,
            kind: value as Memory["kind"]
          })} options={KINDS.map(kind => ({
            value: kind,
            label: kind
          }))} />
              <TextareaField label="The memory" value={memoryDraft.body} onChange={event => setMemoryDraft({
            ...memoryDraft,
            body: event.target.value
          })} className="sm:col-span-2" />
              <div className="sm:col-span-2">
                <p className="mb-1 text-[0.68rem] font-bold uppercase tracking-[0.08em] text-muted-foreground">
                  A photo (optional)
                </p>
                <input ref={memoryFileInput} type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="sr-only" onChange={event => void pickMemoryImage(event.target.files?.[0])} />
                <div className="flex items-center gap-2.5 rounded-2xl border border-dashed border-border/80 bg-muted/30 p-2">
                  <div className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-xl bg-card">
                    {memoryPreview || memoryDraft.imagePath && imageUrls[memoryDraft.imagePath] ? <img src={memoryPreview ?? imageUrls[memoryDraft.imagePath!]} alt="" className="h-full w-full object-cover" /> : memoryUploading ? <Loader2 className="h-4 w-4 animate-spin text-sage" aria-hidden /> : <ImagePlus className="h-4 w-4 text-sage/70" aria-hidden />}
                  </div>
                  <div className="flex flex-1 flex-wrap items-center gap-1.5">
                    <Button size="sm" variant="outline" className="h-7 bg-card text-[0.62rem]" onClick={() => memoryFileInput.current?.click()} disabled={memoryUploading}>
                      {memoryUploading ? <Loader2 className="h-3 w-3 animate-spin" /> : <ImagePlus className="h-3 w-3" />}
                      {memoryDraft.imagePath ? "Replace photo" : "Add a photo"}
                    </Button>
                    {memoryDraft.imagePath && <Button size="sm" variant="ghost" className="h-7 text-[0.6rem]" onClick={() => {
                  setMemoryDraft({
                    ...memoryDraft,
                    imagePath: undefined
                  });
                  setMemoryPreview(null);
                }}>
                        Remove
                      </Button>}
                    <p className="w-full text-[0.55rem] text-muted-foreground">
                      Private to the two of you · up to 10 MB.
                    </p>
                  </div>
                </div>
              </div>

              <TextField label="Tags (comma separated)" value={memoryDraft.tags.join(", ")} onChange={event => setMemoryDraft({
            ...memoryDraft,
            tags: event.target.value.split(",").map(tag => tag.trim()).filter(Boolean)
          })} className="sm:col-span-2" />
              <SelectField label="Visibility" value={memoryDraft.visibility} onChange={value => setMemoryDraft({
            ...memoryDraft,
            visibility: value as Memory["visibility"]
          })} options={[{
            value: "shared",
            label: "Shared with my partner"
          }, {
            value: "private",
            label: "Private draft"
          }]} />
              <SelectField label="Paper colour" value={memoryDraft.palette} onChange={value => setMemoryDraft({
            ...memoryDraft,
            palette: value as Memory["palette"]
          })} options={(Object.keys(PALETTES) as Memory["palette"][]).map(palette => ({
            value: palette,
            label: palette
          }))} />
            </div>}
          <DialogFooter className="gap-2">
            {memoryDraft && data.memories.some(memory => memory.id === memoryDraft.id) && (
              <Button variant="ghost" size="sm" onClick={() => void deleteMemory(memoryDraft)}>
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </Button>
            )}
            <Button variant="soft" size="sm" onClick={() => setMemoryDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={saveMemory}>
              Keep it
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(letterDraft)} onOpenChange={open => !open && setLetterDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">A letter for a future moment</DialogTitle>
            <DialogDescription className="text-[0.75rem]">
              Sealed letters stay hidden until the date you choose.
            </DialogDescription>
          </DialogHeader>
          {letterDraft && <div className="space-y-2.5">
              <SelectField label="Open this when…" value={letterDraft.occasion} onChange={value => setLetterDraft({
            ...letterDraft,
            occasion: value
          })} options={OCCASIONS.map(occasion => ({
            value: occasion,
            label: occasion
          }))} />
              <TextField label="Title" value={letterDraft.title} onChange={event => setLetterDraft({
            ...letterDraft,
            title: event.target.value
          })} placeholder="Read this on the quiet nights" />
              <TextareaField label="The letter" value={letterDraft.body} onChange={event => setLetterDraft({
            ...letterDraft,
            body: event.target.value
          })} />
              <SelectField label="From" value={letterDraft.from} onChange={value => setLetterDraft({
            ...letterDraft,
            from: value as PersonId
          })} options={[{
            value: "you",
            label: data.people.you.name
          }, {
            value: "me",
            label: data.people.me.name
          }]} />
              <TextField label="Seal until (optional)" type="date" value={letterDraft.sealUntil ?? ""} onChange={event => setLetterDraft({
            ...letterDraft,
            sealUntil: event.target.value || undefined
          })} hint="Leave empty so it can be opened any time." />
            </div>}
          <DialogFooter className="gap-2">
            <Button variant="soft" size="sm" onClick={() => setLetterDraft(null)}>
              Cancel
            </Button>
            <Button size="sm" onClick={saveLetter}>
              <Mail className="h-3.5 w-3.5" /> Seal it
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(viewingKeepsake)} onOpenChange={open => {
      if (!open) setViewingKeepsake(null);
    }}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle className="hand text-[1.5rem]">
              {viewingKeepsake?.title || "A little keepsake"}
            </DialogTitle>
            <DialogDescription className="text-[0.7rem]">
              {viewingKeepsake ? `${formatDateIn(new Date(viewingKeepsake.date), "UTC", true)} · kept by ${viewingKeepsake.author === "you" ? data.people.you.name : data.people.me.name}` : ""}
            </DialogDescription>
          </DialogHeader>

          {viewingKeepsake && (imageUrls[viewingKeepsake.path] ? <img src={imageUrls[viewingKeepsake.path]} alt={viewingKeepsake.title} className="max-h-[52vh] w-full rounded-2xl bg-muted object-contain" /> : <div className="grid h-40 place-items-center rounded-2xl bg-muted text-sage/50">
                <Camera className="h-6 w-6" aria-hidden />
              </div>)}

          <div className="space-y-2.5">
            <TextField label="Title" value={keepsakeDraft.title} onChange={event => setKeepsakeDraft({
            ...keepsakeDraft,
            title: event.target.value
          })} />
            <TextareaField label="A line about it" value={keepsakeDraft.note} onChange={event => setKeepsakeDraft({
            ...keepsakeDraft,
            note: event.target.value
          })} placeholder="Why this one stayed with us…" />
          </div>

          <DialogFooter className="gap-2">
            <Button variant="ghost" size="sm" onClick={() => void removeKeepsake()}>
              <Trash2 className="h-3.5 w-3.5" /> Remove
            </Button>
            <Button variant="soft" size="sm" onClick={() => setViewingKeepsake(null)}>
              Close
            </Button>
            <Button size="sm" onClick={saveKeepsakeDraft}>
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(openLetter)} onOpenChange={open => !open && setOpenLetter(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="hand text-[1.6rem]">{openLetter?.title}</DialogTitle>
            <DialogDescription className="text-[0.7rem]">
              {openLetter?.occasion} · from{" "}
              {openLetter?.from === "you" ? data.people.you.nickname : data.people.me.nickname}
            </DialogDescription>
          </DialogHeader>
          <p className="whitespace-pre-line rounded-xl bg-butter-soft/70 p-3 font-read text-[0.85rem] leading-relaxed text-ink-soft">
            {openLetter?.body}
          </p>
          <DialogFooter>
            <Button size="sm" variant="soft" onClick={() => setOpenLetter(null)}>
              Close gently
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>;
}