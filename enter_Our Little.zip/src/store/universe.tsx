import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { seedData } from "@/lib/seed";
import { privateCollections, swapViewer, withoutPrivate } from "@/lib/identity";
import { AuthScreen } from "@/components/auth/auth-screen";
import { UniverseSetup, type PersonSeed } from "@/components/auth/universe-setup";
import type { PersonId, Person, Prayer, Memory, SpiritualReflection, UniverseData } from "@/lib/types";

type Stage = "boot" | "auth" | "loading" | "setup" | "ready" | "error";
type SyncState = "idle" | "saving" | "saved" | "error";

interface UniverseContextValue {
  data: UniverseData;
  mutate: (recipe: (draft: UniverseData) => UniverseData) => void;
  reset: () => void;
  viewerSlot: PersonId;
  partnerJoined: boolean;
  joinCode: string;
  spaceId: string;
  email: string;
  syncState: SyncState;
  signOut: () => Promise<void>;
}

const UniverseContext = createContext<UniverseContextValue | null>(null);

interface MemberRow {
  user_id: string;
  slot: string;
}

interface PrivateRow {
  kind: string;
  payload: unknown;
}

function buildShared(raw: unknown): UniverseData {
  const stored = (raw ?? {}) as Partial<UniverseData>;
  return {
    ...seedData,
    ...stored,
    people: {
      you: { ...seedData.people.you, ...stored.people?.you },
      me: { ...seedData.people.me, ...stored.people?.me },
    },
    settings: {
      ...seedData.settings,
      ...stored.settings,
      widgets: { ...seedData.settings.widgets, ...stored.settings?.widgets },
      notifications: { ...seedData.settings.notifications, ...stored.settings?.notifications },
    },
    events: stored.events ?? seedData.events,
    rituals: stored.rituals ?? seedData.rituals,
    moods: stored.moods ?? seedData.moods,
    loveNotes: stored.loveNotes ?? seedData.loveNotes,
    prayers: stored.prayers ?? seedData.prayers,
    intentions: stored.intentions ?? seedData.intentions,
    prayerSessions: stored.prayerSessions ?? seedData.prayerSessions,
    spiritualReflections: stored.spiritualReflections ?? seedData.spiritualReflections,
    readingPlans: stored.readingPlans ?? seedData.readingPlans,
    trips: stored.trips ?? seedData.trips,
    goals: stored.goals ?? seedData.goals,
    moneyTalks: stored.moneyTalks ?? seedData.moneyTalks,
    memories: stored.memories ?? seedData.memories,
    keepsakes: stored.keepsakes ?? seedData.keepsakes,
    prayerCards: stored.prayerCards ?? seedData.prayerCards,
    musicNotes: stored.musicNotes ?? seedData.musicNotes,
    prayerBoardNote: stored.prayerBoardNote ?? seedData.prayerBoardNote,
    openWhen: stored.openWhen ?? seedData.openWhen,
    reflections: stored.reflections ?? seedData.reflections,
  };
}

function mergePrivate(shared: UniverseData, rows: PrivateRow[]): UniverseData {
  const prayers = rows.filter((row) => row.kind === "prayer").map((row) => row.payload as Prayer);
  const memories = rows.filter((row) => row.kind === "memory").map((row) => row.payload as Memory);
  const reflections = rows
    .filter((row) => row.kind === "reflection")
    .map((row) => row.payload as SpiritualReflection);
  return {
    ...shared,
    prayers: [...shared.prayers.filter((prayer) => prayer.visibility !== "private"), ...prayers],
    memories: [...shared.memories.filter((memory) => memory.visibility !== "private"), ...memories],
    spiritualReflections: [
      ...shared.spiritualReflections.filter((reflection) => reflection.shared !== false),
      ...reflections,
    ],
  };
}

function friendlyAuthError(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes("invalid login")) return "That email and password don't match. Try again?";
  if (lower.includes("already registered") || lower.includes("already been registered"))
    return "There's already a little universe account with that email. Try signing in.";
  if (lower.includes("password")) return "Use at least six characters for your password.";
  if (lower.includes("email")) return "That email doesn't look quite right.";
  return message;
}

function Splash({ note }: { note: string }) {
  return (
    <div className="grid min-h-[100dvh] place-items-center bg-background px-4">
      <div className="flex flex-col items-center gap-2">
        <span className="hand text-[1.5rem] text-sage">{note}</span>
        <span className="h-1 w-24 overflow-hidden rounded-full bg-muted">
          <span className="block h-full w-1/2 animate-pulse rounded-full bg-sage" />
        </span>
      </div>
    </div>
  );
}

export function UniverseProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [stage, setStage] = useState<Stage>("boot");
  const [data, setData] = useState<UniverseData | null>(null);
  const [spaceId, setSpaceId] = useState<string | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [viewerSlot, setViewerSlot] = useState<PersonId>("you");
  const [partnerJoined, setPartnerJoined] = useState(false);
  const [syncState, setSyncState] = useState<SyncState>("idle");
  const [reloadKey, setReloadKey] = useState(0);

  const dirtyRef = useRef(false);
  const lastEditRef = useRef(0);
  const knownUpdatedAt = useRef<string | null>(null);
  const privateSignature = useRef<string>("");
  const refreshRef = useRef<() => void>(() => {});

  useEffect(() => {
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
    });
    supabase.auth
      .getSession()
      .then(({ data: current }) => {
        setSession(current.session);
      })
      .finally(() => {
        setStage((current) => (current === "boot" ? "auth" : current));
      });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const user = session?.user;
    if (!user) {
      setStage("auth");
      setData(null);
      setSpaceId(null);
      return;
    }

    let cancelled = false;
    setStage((current) => (current === "ready" ? current : "loading"));

    (async () => {
      const { data: member, error: memberError } = await supabase
        .from("universe_members")
        .select("space_id, slot")
        .eq("user_id", user.id)
        .maybeSingle();

      if (cancelled) return;
      if (memberError) {
        setStage("error");
        return;
      }
      if (!member) {
        setStage("setup");
        return;
      }

      const [{ data: spaceRow }, { data: memberRows }, { data: privateRows }] = await Promise.all([
        supabase.from("universe_spaces").select("id, join_code, data, updated_at").eq("id", member.space_id).maybeSingle(),
        supabase.from("universe_members").select("user_id, slot").eq("space_id", member.space_id),
        supabase.from("universe_private").select("kind, payload").eq("space_id", member.space_id).eq("author_id", user.id),
      ]);

      if (cancelled) return;
      if (!spaceRow) {
        setStage("setup");
        return;
      }

      const slot: PersonId = member.slot === "me" ? "me" : "you";
      const shared = mergePrivate(buildShared(spaceRow.data), (privateRows ?? []) as PrivateRow[]);
      setData(slot === "me" ? swapViewer(shared) : shared);
      setSpaceId(spaceRow.id);
      setJoinCode(spaceRow.join_code);
      setViewerSlot(slot);
      setPartnerJoined((memberRows ?? []).length > 1);
      knownUpdatedAt.current = spaceRow.updated_at;
      setSyncState("saved");
      dirtyRef.current = false;
      privateSignature.current = JSON.stringify(
        (privateRows ?? []).map((row) => [row.kind, row.payload]),
      );
      setStage("ready");

      const theme = (shared.settings?.theme ?? "light") as "light" | "dark";
      document.documentElement.classList.toggle("dark", theme === "dark");
      document.documentElement.style.fontSize = shared.settings?.comfortText ? "17.5px" : "";
      document.documentElement.classList.toggle("motion-calm", Boolean(shared.settings?.reducedMotion));
    })();

    return () => {
      cancelled = true;
    };
    // Reload only when the person changes, not on every token refresh.
  }, [session?.user?.id, reloadKey]);

  useEffect(() => {
    if (!data) return;
    document.documentElement.classList.toggle("dark", data.settings.theme === "dark");
    document.documentElement.style.fontSize = data.settings.comfortText ? "17.5px" : "";
    document.documentElement.classList.toggle("motion-calm", data.settings.reducedMotion);
  }, [data]);

  const mutate = useCallback((recipe: (draft: UniverseData) => UniverseData) => {
    dirtyRef.current = true;
    lastEditRef.current = Date.now();
    setData((prev) => (prev ? recipe(prev) : prev));
  }, []);

  // Debounced write of the shared document + this member's private entries.
  useEffect(() => {
    if (!data || !spaceId || !session?.user || !dirtyRef.current) return;
    const userId = session.user.id;
    const timer = window.setTimeout(async () => {
      setSyncState("saving");
      const canonical = viewerSlot === "me" ? swapViewer(data) : data;
      const shared = withoutPrivate(canonical);

      const { data: updated, error } = await supabase
        .from("universe_spaces")
        .update({ data: shared as unknown as Json })
        .eq("id", spaceId)
        .select("updated_at")
        .maybeSingle();

      if (error) {
        setSyncState("error");
        return;
      }
      knownUpdatedAt.current = updated?.updated_at ?? knownUpdatedAt.current;

      const private_ = privateCollections(canonical);
      const rows = [
        ...private_.prayers.map((prayer) => ({ space_id: spaceId, author_id: userId, kind: "prayer", payload: prayer as unknown as Json })),
        ...private_.memories.map((memory) => ({ space_id: spaceId, author_id: userId, kind: "memory", payload: memory as unknown as Json })),
        ...private_.reflections.map((reflection) => ({ space_id: spaceId, author_id: userId, kind: "reflection", payload: reflection as unknown as Json })),
      ];
      const signature = JSON.stringify(rows.map((row) => [row.kind, row.payload]));

      if (signature !== privateSignature.current) {
        await supabase.from("universe_private").delete().eq("space_id", spaceId).eq("author_id", userId);
        if (rows.length) {
          await supabase.from("universe_private").insert(rows);
        }
        privateSignature.current = signature;
      }

      dirtyRef.current = false;
      setSyncState("saved");
    }, 900);

    return () => window.clearTimeout(timer);
  }, [data, spaceId, session?.user, viewerSlot]);

  refreshRef.current = () => setReloadKey((key) => key + 1);

  // Live updates from the partner.
  useEffect(() => {
    if (!spaceId) return;
    const channel = supabase
      .channel(`universe-space-${spaceId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "universe_spaces", filter: `id=eq.${spaceId}` },
        (payload) => {
          const row = payload.new as { updated_at?: string };
          if (!row?.updated_at || row.updated_at === knownUpdatedAt.current) return;
          if (dirtyRef.current || Date.now() - lastEditRef.current < 2500) return;
          refreshRef.current();
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [spaceId]);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setData(null);
    setSpaceId(null);
    setStage("auth");
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { error: friendlyAuthError(error.message) };
    return {};
  }, []);

  const signUp = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${window.location.origin}/` },
    });
    if (error) return { error: friendlyAuthError(error.message) };
    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
    if (signInError) return { error: "Account created — please sign in with the same details." };
    return {};
  }, []);

  const createUniverse = useCallback(
    async (you: PersonSeed, partner: PersonSeed) => {
      // A new universe starts empty: only the two of you fill it in.
      const initial: UniverseData = {
        ...seedData,
        people: {
          you: { ...seedData.people.you, ...you, id: "you" },
          me: { ...seedData.people.me, ...partner, id: "me" },
        },
      };
      const { error } = await supabase.rpc("universe_create_space", {
        p_me: you as unknown as Json,
        p_data: withoutPrivate(initial) as unknown as Json,
      });
      if (error) return { error: error.message };
      setReloadKey((key) => key + 1);
      return {};
    },
    [],
  );

  const joinUniverse = useCallback(async (code: string, me: PersonSeed) => {
    const { data: rows, error } = await supabase.rpc("universe_join_space", {
      p_code: code,
      p_me: me as unknown as Json,
    });
    if (error) {
      const message = error.message.includes("space_full")
        ? "That universe already has two people in it."
        : error.message.includes("code_not_found")
          ? "We couldn't find that invite code — check the letters and numbers."
          : "That join didn't work. Try the code once more?";
      return { error: message };
    }
    const row = Array.isArray(rows) ? rows[0] : rows;
    if (row?.space_id) {
      const { data: space } = await supabase
        .from("universe_spaces")
        .select("data")
        .eq("id", row.space_id)
        .maybeSingle();
      const stored = buildShared(space?.data);
      const slot: PersonId = row.slot === "you" ? "you" : "me";
      const next: UniverseData = {
        ...withoutPrivate(stored),
        people: {
          ...stored.people,
          [slot]: { ...stored.people[slot], ...me, id: slot } as Person,
        },
      };
      await supabase
        .from("universe_spaces")
        .update({ data: next as unknown as Json })
        .eq("id", row.space_id);
    }
    setReloadKey((key) => key + 1);
    return {};
  }, []);

  const reset = useCallback(() => {
    if (!data) return;
    const fresh = viewerSlot === "me" ? swapViewer(seedData) : seedData;
    dirtyRef.current = true;
    lastEditRef.current = Date.now();
    setData(fresh);
  }, [data, viewerSlot]);

  const value = useMemo<UniverseContextValue | null>(() => {
    if (!data) return null;
    return {
      data,
      mutate,
      reset,
      viewerSlot,
      partnerJoined,
      joinCode,
      spaceId: spaceId ?? "",
      email: session?.user?.email ?? "",
      syncState,
      signOut,
    };
  }, [data, mutate, reset, viewerSlot, partnerJoined, joinCode, spaceId, session?.user?.email, syncState, signOut]);

  if (stage === "boot") return <Splash note="opening our little universe…" />;

  if (!session) {
    return <AuthScreen onSignIn={signIn} onSignUp={signUp} />;
  }

  if (stage === "setup") {
    return (
      <UniverseSetup
        email={session.user.email ?? ""}
        onCreate={createUniverse}
        onJoin={joinUniverse}
        onSignOut={signOut}
      />
    );
  }

  if (stage === "error") {
    return (
      <div className="grid min-h-[100dvh] place-items-center bg-background px-4">
        <div className="paper-card grain max-w-sm p-6 text-center">
          <p className="hand text-[1.4rem] text-sage">The little door is stuck</p>
          <p className="mt-1 text-[0.78rem] text-muted-foreground">
            We couldn't open your universe just now. Nothing has been lost.
          </p>
          <div className="mt-3 flex justify-center gap-2">
            <button
              type="button"
              onClick={() => setReloadKey((key) => key + 1)}
              className="rounded-full bg-primary px-3 py-1.5 text-[0.72rem] font-bold text-primary-foreground"
            >
              Try again
            </button>
            <button
              type="button"
              onClick={() => void signOut()}
              className="rounded-full border border-border px-3 py-1.5 text-[0.72rem] font-bold"
            >
              Sign out
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!value) return <Splash note="gathering your week…" />;

  return <UniverseContext.Provider value={value}>{children}</UniverseContext.Provider>;
}

export function useUniverse() {
  const ctx = useContext(UniverseContext);
  if (!ctx) throw new Error("useUniverse must be used inside UniverseProvider");
  return ctx;
}

export function useNow(intervalMs = 15000) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), intervalMs);
    return () => window.clearInterval(timer);
  }, [intervalMs]);
  return now;
}

export function makeId(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}
