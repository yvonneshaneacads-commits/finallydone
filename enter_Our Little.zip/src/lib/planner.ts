import type { CalEvent, Person, PersonId } from "./types";
import { hhmmToMinutes, zonedToUtc } from "./time";

export interface Interval {
  start: Date;
  end: Date;
}

export interface Window extends Interval {
  minutes: number;
}

function calendarParts(date: Date) {
  return { year: date.getFullYear(), month: date.getMonth(), day: date.getDate() };
}

/** Real instants for an event on the given week day. */
export function eventInterval(event: CalEvent, dates: Date[], tz: string): Interval {
  const day = dates[Math.min(Math.max(event.day, 0), 6)];
  const { year, month, day: dom } = calendarParts(day);
  const start = zonedToUtc(year, month, dom, event.start, tz);
  const startMinutes = hhmmToMinutes(event.start);
  const endMinutes = hhmmToMinutes(event.end);
  const spansMidnight = endMinutes <= startMinutes;
  const end = zonedToUtc(
    year,
    month,
    dom + (spansMidnight ? 1 : 0),
    event.end,
    tz,
  );
  return { start, end };
}

export function subtractIntervals(base: Interval[], blockers: Interval[]): Interval[] {
  let result = [...base];
  for (const blocker of blockers) {
    const next: Interval[] = [];
    for (const slot of result) {
      if (blocker.end <= slot.start || blocker.start >= slot.end) {
        next.push(slot);
        continue;
      }
      if (blocker.start > slot.start) {
        next.push({ start: slot.start, end: new Date(Math.min(blocker.start.getTime(), slot.end.getTime())) });
      }
      if (blocker.end < slot.end) {
        next.push({ start: new Date(Math.max(blocker.end.getTime(), slot.start.getTime())), end: slot.end });
      }
    }
    result = next;
  }
  return result.filter((slot) => slot.end.getTime() - slot.start.getTime() > 0);
}

export function intersectIntervals(a: Interval[], b: Interval[]): Interval[] {
  const out: Interval[] = [];
  for (const left of a) {
    for (const right of b) {
      const start = new Date(Math.max(left.start.getTime(), right.start.getTime()));
      const end = new Date(Math.min(left.end.getTime(), right.end.getTime()));
      if (end.getTime() > start.getTime()) out.push({ start, end });
    }
  }
  return out.sort((x, y) => x.start.getTime() - y.start.getTime());
}

/** Free time = declared open hours minus anything that actually blocks. */
export function freeWindows(
  person: Person,
  day: number,
  dates: Date[],
  events: CalEvent[],
): Window[] {
  const dayDate = dates[Math.min(Math.max(day, 0), 6)];
  const { year, month, day: dom } = calendarParts(dayDate);
  const openStart = zonedToUtc(year, month, dom, person.openFrom, person.timezone);
  let openEnd = zonedToUtc(year, month, dom, person.openTo, person.timezone);
  if (openEnd <= openStart) {
    openEnd = new Date(openEnd.getTime() + 86400000);
  }

  const blockers = events
    .filter((event) => event.person === person.id && event.day === day && event.status === "busy")
    .map((event) => eventInterval(event, dates, person.timezone))
    .sort((a, b) => a.start.getTime() - b.start.getTime());

  return subtractIntervals([{ start: openStart, end: openEnd }], blockers)
    .map((slot) => ({ ...slot, minutes: Math.round((slot.end.getTime() - slot.start.getTime()) / 60000) }))
    .filter((slot) => slot.minutes >= 20);
}

export interface OverlapWindow extends Window {
  you: Window;
  me: Window;
}

/** Periods where both people are genuinely free (never "empty calendar = free"). */
export function overlapWindows(
  people: Record<PersonId, Person>,
  day: number,
  dates: Date[],
  events: CalEvent[],
  minimumMinutes = 30,
): OverlapWindow[] {
  const youFree = freeWindows(people.you, day, dates, events);
  const meFree = freeWindows(people.me, day, dates, events);
  return intersectIntervals(youFree, meFree)
    .map((slot) => {
      const minutes = Math.round((slot.end.getTime() - slot.start.getTime()) / 60000);
      return {
        ...slot,
        minutes,
        you: { start: slot.start, end: slot.end, minutes },
        me: { start: slot.start, end: slot.end, minutes },
      };
    })
    .filter((slot) => slot.minutes >= minimumMinutes);
}

export function upcomingCalls(events: CalEvent[], dates: Date[], now = new Date()): CalEvent[] {
  const todayIndex = (now.getDay() + 6) % 7;
  return events
    .filter((event) => /call/i.test(event.title) && event.day >= todayIndex)
    .sort((a, b) => a.day - b.day || hhmmToMinutes(a.start) - hhmmToMinutes(b.start));
}

export function conflictsFor(event: CalEvent, events: CalEvent[], person: Person): boolean {
  return events.some((other) => {
    if (other.id === event.id) return false;
    if (other.person !== person.id || other.day !== event.day) return false;
    const aStart = hhmmToMinutes(event.start);
    const aEnd = hhmmToMinutes(event.end);
    const bStart = hhmmToMinutes(other.start);
    const bEnd = hhmmToMinutes(other.end);
    return aStart < bEnd && bStart < aEnd;
  });
}

export function eventColors(status: CalEvent["status"]): string {
  switch (status) {
    case "busy":
      return "bg-peach-soft border-peach text-ink";
    case "flexible":
      return "bg-butter-soft border-butter text-ink";
    default:
      return "bg-sage-soft border-sage/40 text-ink";
  }
}
