import { supabase } from "@/integrations/supabase/client";
import { hhmmInZone, weekdayIndexInZone, zonedToUtc } from "./time";
import type { CalEvent, PersonId } from "./types";

export const CALENDAR_FUNCTION = "google-calendar-sync-76b8d4cea638";

export interface GoogleEvent {
  id: string;
  title: string;
  start: string | null;
  end: string | null;
  allDay: boolean;
  location: string | null;
  transparency: string;
}

type CalendarResponse<T> = T & {
  ok?: boolean;
  error?: string;
  items?: GoogleEvent[];
  count?: number;
  timezone?: string | null;
  googleEventId?: string;
};

async function callCalendar<T = Record<string, unknown>>(body: Record<string, unknown>) {
  const { data, error } = await supabase.functions.invoke(CALENDAR_FUNCTION, {
    body,
    headers: { "Content-Type": "application/json" },
  });
  if (error) {
    return { error: error.message || "Google Calendar did not answer" } as {
      error: string;
    };
  }
  const payload = (data ?? {}) as CalendarResponse<T>;
  if (payload.error) return { error: payload.error };
  return { data: payload };
}

export function checkCalendar(spaceId: string) {
  return callCalendar<{ connected?: boolean; timezone?: string | null }>({
    action: "status",
    spaceId,
  });
}

export function pullCalendar(spaceId: string, timeMin: string, timeMax: string) {
  return callCalendar<{ items?: GoogleEvent[]; count?: number; timezone?: string | null }>({
    action: "pull",
    spaceId,
    timeMin,
    timeMax,
  });
}

export function pushCalendarEvent(
  spaceId: string,
  event: { summary: string; description?: string; startISO: string; endISO: string; timezone: string; location?: string },
) {
  return callCalendar<{ googleEventId?: string }>({ action: "create", spaceId, event });
}

export function patchCalendarEvent(
  spaceId: string,
  googleEventId: string,
  event: { summary: string; description?: string; startISO: string; endISO: string; timezone: string; location?: string },
) {
  return callCalendar({ action: "patch", spaceId, googleEventId, event });
}

export function removeCalendarEvent(spaceId: string, googleEventId: string) {
  return callCalendar({ action: "remove", spaceId, googleEventId });
}

/** Monday 00:00 → next Monday 00:00 of the viewed week, in the given zone. */
export function weekWindow(dates: Date[], timezone: string) {
  const monday = dates[0];
  const next = dates[6];
  const start = zonedToUtc(
    monday.getFullYear(),
    monday.getMonth(),
    monday.getDate(),
    "00:00",
    timezone,
  );
  const end = zonedToUtc(next.getFullYear(), next.getMonth(), next.getDate() + 1, "00:00", timezone);
  return { timeMin: start.toISOString(), timeMax: end.toISOString(), start, end };
}

/** Timed Google events become regular planner events; all-day ones are listed separately. */
export function googleToEvent(
  item: GoogleEvent,
  person: PersonId,
  timezone: string,
  window: { start: Date; end: Date },
): CalEvent | null {
  if (item.allDay || !item.start || !item.end) return null;
  const start = new Date(item.start);
  const end = new Date(item.end);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return null;
  if (start < window.start || start >= window.end) return null;

  return {
    id: `gcal-${item.id}`,
    person,
    title: item.title,
    day: weekdayIndexInZone(start, timezone),
    start: hhmmInZone(start, timezone),
    end: hhmmInZone(end, timezone),
    status: item.transparency === "transparent" ? "available" : "busy",
    category: "Google",
    notes: item.location ?? "From Google Calendar",
    recurrence: "none",
    source: "google",
    googleEventId: item.id,
    location: item.location ?? undefined,
  };
}

/** The instant for one event, in its owner's local time zone. */
export function eventInstants(event: CalEvent, dates: Date[], timezone: string) {
  const day = dates[Math.min(Math.max(event.day, 0), 6)];
  const start = zonedToUtc(day.getFullYear(), day.getMonth(), day.getDate(), event.start, timezone);
  const overnight = event.end <= event.start;
  const end = zonedToUtc(
    day.getFullYear(),
    day.getMonth(),
    day.getDate() + (overnight ? 1 : 0),
    event.end,
    timezone,
  );
  return { start, end };
}

export function eventToPayload(event: CalEvent, dates: Date[], timezone: string) {
  const { start, end } = eventInstants(event, dates, timezone);
  return {
    summary: event.title,
    description: event.notes ?? "",
    startISO: start.toISOString(),
    endISO: end.toISOString(),
    timezone,
    location: event.location ?? "",
  };
}
