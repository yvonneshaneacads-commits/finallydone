export type PersonId = "you" | "me";

export interface ZoneOption {
  id: string;
  city: string;
  country: string;
  label: string;
}

export const ZONES: ZoneOption[] = [
  { id: "Asia/Manila", city: "Pasig", country: "Philippines", label: "Philippines" },
  { id: "Asia/Kolkata", city: "Bengaluru", country: "India", label: "India" },
  { id: "Asia/Brisbane", city: "Brisbane", country: "Australia", label: "Queensland" },
  { id: "Asia/Singapore", city: "Singapore", country: "Singapore", label: "Singapore" },
  { id: "Asia/Tokyo", city: "Tokyo", country: "Japan", label: "Japan" },
  { id: "Asia/Dubai", city: "Dubai", country: "UAE", label: "UAE" },
  { id: "Europe/London", city: "London", country: "United Kingdom", label: "UK" },
  { id: "Europe/Paris", city: "Paris", country: "France", label: "France" },
  { id: "America/New_York", city: "New York", country: "United States", label: "US Eastern" },
  { id: "America/Los_Angeles", city: "Los Angeles", country: "United States", label: "US Pacific" },
  { id: "Australia/Sydney", city: "Sydney", country: "Australia", label: "NSW" },
  { id: "Pacific/Auckland", city: "Auckland", country: "New Zealand", label: "New Zealand" },
];

export interface Person {
  id: PersonId;
  name: string;
  nickname: string;
  companion: "siamese" | "orange" | "black";
  color: "sage" | "powder" | "peach" | "butter" | "lilac";
  city: string;
  country: string;
  timezone: string;
  openFrom: string;
  openTo: string;
}

export type EventStatus = "busy" | "flexible" | "available";

export interface CalEvent {
  id: string;
  person: PersonId;
  title: string;
  day: number; // 0 = Monday
  start: string; // HH:mm in the owner's zone
  end: string; // HH:mm in the owner's zone
  status: EventStatus;
  category: string;
  notes?: string;
  recurrence: "none" | "weekly" | "biweekly" | "monthly";
  ritual?: boolean;
  /** Google Calendar mirroring */
  source?: "local" | "google";
  googleEventId?: string;
  syncToGoogle?: boolean;
  location?: string;
}

export interface Ritual {
  id: string;
  title: string;
  days: number[];
  start: string;
  end: string;
  enabled: boolean;
}

export interface MoodCheck {
  id: string;
  person: PersonId;
  mood: string;
  note: string;
  need: string;
  needNote: string;
  date: string;
}

export interface LoveNote {
  id: string;
  from: PersonId;
  text: string;
  createdAt: string;
  revealOn?: string;
  opened?: boolean;
}

export interface PrayerUpdate {
  id: string;
  date: string;
  text: string;
}

export interface Prayer {
  id: string;
  title: string;
  description: string;
  category: string;
  scripture?: string;
  concern?: string;
  status: "new" | "praying" | "updated" | "answered" | "continuing" | "gratitude";
  visibility: "shared" | "private";
  author: PersonId;
  createdAt: string;
  updates: PrayerUpdate[];
}

export interface Intention {
  id: string;
  title: string;
  note: string;
  period: string;
  practiced: { person: PersonId; text: string }[];
}

export interface PrayerSession {
  id: string;
  prayerId: string;
  date: string;
  scripture: string;
  intentions: { person: PersonId; text: string }[];
  completed: boolean;
}

export interface SpiritualReflection {
  id: string;
  author: PersonId;
  date: string;
  text: string;
  shared: boolean;
}

export interface Chapter {
  id: string;
  title: string;
  progress: Record<PersonId, "todo" | "reading" | "done">;
}

export interface DiscussionEntry {
  id: string;
  author: PersonId;
  chapter: string;
  prompt: string;
  text: string;
  date: string;
}

export interface ReadingPlan {
  id: string;
  title: string;
  kind: string;
  startDate: string;
  targetDate: string;
  chapters: Chapter[];
  quotes: { id: string; author: PersonId; text: string }[];
  discussion: DiscussionEntry[];
}

export interface GoalContribution {
  id: string;
  person: PersonId;
  amount: number;
  date: string;
  note?: string;
}

export interface Goal {
  id: string;
  title: string;
  subtitle: string;
  target: number;
  targetDate: string;
  accent: "sage" | "powder" | "peach" | "butter" | "lilac" | "blush";
  contributions: GoalContribution[];
}

export interface Trip {
  id: string;
  name: string;
  from: string;
  to: string;
  currency: string;
  exchangeRateLabel: string;
  days: number;
  travelers: number;
  airfare: number;
  lodging: number;
  transport: number;
  food: number;
  activities: number;
  documents: number;
  bufferPct: number;
  saved: number;
  monthly: number;
}

export interface MoneyTalkAction {
  id: string;
  person: PersonId;
  text: string;
  due: string;
  done: boolean;
}

export interface MoneyTalk {
  id: string;
  month: string;
  answers: Record<string, string>;
  actions: MoneyTalkAction[];
}

export interface PrayerCard {
  id: string;
  title: string;
  description: string;
  scripture?: string;
  imagePath?: string;
  status: "praying" | "waiting" | "answered" | "gratitude";
  person: PersonId | "both";
  createdAt: string;
}

export interface Memory {
  id: string;
  title: string;
  date: string;
  body: string;
  tags: string[];
  kind: "letter" | "photo" | "moment" | "milestone" | "date";
  visibility: "shared" | "private";
  author: PersonId;
  palette: "peach" | "powder" | "butter" | "sage" | "lilac";
  imagePath?: string;
}

export interface MusicNote {
  id: string;
  person: PersonId;
  title: string;
  artist: string;
  message: string;
  audioPath?: string;
  youtubeId?: string;
  startSeconds?: number;
  createdAt: string;
}

export interface Keepsake {
  id: string;
  title: string;
  path: string;
  note: string;
  date: string;
  author: PersonId;
}

export interface OpenWhenLetter {
  id: string;
  occasion: string;
  title: string;
  body: string;
  from: PersonId;
  sealUntil?: string;
}

export interface ReflectionEntry {
  id: string;
  person: PersonId;
  list: "love" | "improve";
  title: string;
  body: string;
  status: "open" | "working" | "resolved";
  followUp?: string;
}

export interface WeeklyReflection {
  id: string;
  weekOf: string;
  entries: ReflectionEntry[];
  archived: boolean;
}

export interface SettingsData {
  theme: "light" | "dark";
  wallpaper: "room" | "meadow" | "dusk";
  reducedMotion: boolean;
  comfortText: boolean;
  widgets: Record<string, boolean>;
  anniversary: string;
  verse: string;
  siteNote: string;
  googleOwner: PersonId;
  googleWrite: boolean;
  googleSyncedAt?: string;
  notifications: { checkIns: boolean; prayers: boolean; reading: boolean; money: boolean };
}

export interface UniverseData {
  people: Record<PersonId, Person>;
  settings: SettingsData;
  events: CalEvent[];
  rituals: Ritual[];
  moods: MoodCheck[];
  loveNotes: LoveNote[];
  prayers: Prayer[];
  intentions: Intention[];
  prayerSessions: PrayerSession[];
  spiritualReflections: SpiritualReflection[];
  readingPlans: ReadingPlan[];
  trips: Trip[];
  goals: Goal[];
  moneyTalks: MoneyTalk[];
  prayerBoardNote: string;
  memories: Memory[];
  keepsakes: Keepsake[];
  prayerCards: PrayerCard[];
  musicNotes: MusicNote[];
  openWhen: OpenWhenLetter[];
  reflections: WeeklyReflection[];
}
