/** Real time-zone helpers built on Intl, so DST transitions stay correct. */

const partsFormatterCache = new Map<string, Intl.DateTimeFormat>();

function partsFormatter(tz: string) {
  const cached = partsFormatterCache.get(tz);
  if (cached) return cached;
  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  partsFormatterCache.set(tz, formatter);
  return formatter;
}

interface WallClock {
  year: number;
  month: number; // 1-12
  day: number;
  hour: number;
  minute: number;
  second: number;
}

export function wallClock(date: Date, tz: string): WallClock {
  const parts = partsFormatter(tz).formatToParts(date);
  const get = (type: Intl.DateTimeFormatPartTypes) =>
    Number(parts.find((p) => p.type === type)?.value ?? 0);
  return {
    year: get("year"),
    month: get("month"),
    day: get("day"),
    hour: get("hour") % 24,
    minute: get("minute"),
    second: get("second"),
  };
}

/** Offset of `tz` from UTC in minutes at the given instant. */
export function offsetMinutes(date: Date, tz: string): number {
  const w = wallClock(date, tz);
  const asUtc = Date.UTC(w.year, w.month - 1, w.day, w.hour, w.minute, w.second);
  return Math.round((asUtc - date.getTime()) / 60000);
}

export function offsetLabel(tz: string, date = new Date()): string {
  const minutes = offsetMinutes(date, tz);
  const sign = minutes < 0 ? "-" : "+";
  const abs = Math.abs(minutes);
  const h = Math.floor(abs / 60);
  const m = abs % 60;
  return `GMT${sign}${h}${m ? `:${String(m).padStart(2, "0")}` : ""}`;
}

/** Difference between two zones at `date`, in minutes. */
export function zoneDifference(a: string, b: string, date = new Date()): number {
  return offsetMinutes(date, b) - offsetMinutes(date, a);
}

export function formatDiff(minutes: number): string {
  const abs = Math.abs(minutes);
  const h = Math.floor(abs / 60);
  const m = abs % 60;
  if (h === 0 && m === 0) return "same time";
  const bits = [h ? `${h}h` : "", m ? `${m}m` : ""].filter(Boolean).join(" ");
  return `${bits} diff`;
}

export function formatClock(date: Date, tz: string): string {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(date);
}

export function formatWeekday(date: Date, tz: string, long = false): string {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    weekday: long ? "long" : "short",
    month: "short",
    day: "numeric",
  }).format(date);
}

export function formatDateIn(date: Date, tz: string, withYear = false): string {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    weekday: "short",
    month: "short",
    day: "numeric",
    ...(withYear ? { year: "numeric" } : {}),
  }).format(date);
}

export function isDaytime(date: Date, tz: string): boolean {
  const hour = wallClock(date, tz).hour;
  return hour >= 6 && hour < 19;
}

export function hhmmToMinutes(value: string): number {
  const [h, m] = value.split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minutesToHhmm(total: number): string {
  const normalised = ((total % 1440) + 1440) % 1440;
  return `${String(Math.floor(normalised / 60)).padStart(2, "0")}:${String(
    normalised % 60,
  ).padStart(2, "0")}`;
}

export function formatHHmm(value: string): string {
  const minutes = hhmmToMinutes(value);
  const h24 = Math.floor(minutes / 60) % 24;
  const m = minutes % 60;
  const suffix = h24 >= 12 ? "PM" : "AM";
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${String(m).padStart(2, "0")} ${suffix}`;
}

export function formatDuration(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h && m) return `${h}h ${m}m`;
  if (h) return `${h}h`;
  return `${m}m`;
}

/** Local wall time in `tz` -> real UTC instant. */
export function zonedToUtc(
  year: number,
  monthIndex: number,
  day: number,
  hhmm: string,
  tz: string,
): Date {
  const [h, m] = hhmm.split(":").map(Number);
  const guess = Date.UTC(year, monthIndex, day, h || 0, m || 0);
  let instant = guess - offsetMinutes(new Date(guess), tz) * 60000;
  // Second pass handles DST boundaries where the offset shifts.
  instant = guess - offsetMinutes(new Date(instant), tz) * 60000;
  return new Date(instant);
}

/** Format a UTC instant as wall-clock time in `tz`. */
export function timeInZone(date: Date, tz: string): string {
  return formatClock(date, tz);
}

/** Monday-first week containing `reference` (in the viewer's local zone). */
export function weekDates(reference = new Date()): Date[] {
  const base = new Date(reference);
  base.setHours(12, 0, 0, 0);
  const day = base.getDay(); // 0 Sun
  const mondayOffset = day === 0 ? -6 : 1 - day;
  const monday = new Date(base);
  monday.setDate(base.getDate() + mondayOffset);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    return d;
  });
}

export const DAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export function weekLabel(dates: Date[]): string {
  const start = dates[0];
  const end = dates[6];
  const sameMonth = start.getMonth() === end.getMonth();
  const fmt = (d: Date, withMonth: boolean) =>
    new Intl.DateTimeFormat("en-US", {
      month: withMonth ? "short" : undefined,
      day: "numeric",
    }).format(d);
  return `${fmt(start, true)} – ${fmt(end, !sameMonth)}`;
}

export function relativeTime(iso: string): string {
  const then = new Date(iso).getTime();
  const diff = Date.now() - then;
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} ${hours === 1 ? "hour" : "hours"} ago`;
  const days = Math.round(hours / 24);
  if (days < 7) return `${days} ${days === 1 ? "day" : "days"} ago`;
  return formatDateIn(new Date(iso), "UTC");
}

export function currency(amount: number, code = "PHP"): string {
  const symbol = code === "INR" ? "₹" : code === "PHP" ? "₱" : code === "AUD" ? "A$" : "";
  const rounded = Math.round(amount);
  const formatted = new Intl.NumberFormat("en-US").format(rounded);
  return symbol ? `${symbol}${formatted}` : `${code} ${formatted}`;
}

export function hhmmInZone(date: Date, tz: string): string {
  const w = wallClock(date, tz);
  return `${String(w.hour).padStart(2, "0")}:${String(w.minute).padStart(2, "0")}`;
}

/** Monday-first day index of an instant, in the given zone. */
export function weekdayIndexInZone(date: Date, tz: string): number {
  const short = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" }).format(date);
  return ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].indexOf(short);
}

export function monthLabel(iso: string): string {
  return new Intl.DateTimeFormat("en-US", { month: "long", year: "numeric" }).format(new Date(iso));
}
