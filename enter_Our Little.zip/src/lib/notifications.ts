import type { UniverseData } from "./types";
import { relativeTime } from "./time";

export interface Notice {
  id: string;
  kind: "note" | "prayer" | "reading" | "money" | "plan" | "mood";
  title: string;
  detail: string;
  href: string;
  when: string;
}

/** Only real things waiting for you — never invented activity. */
export function buildNotifications(data: UniverseData): Notice[] {
  const notices: Notice[] = [];
  const partner = data.people.me;
  const you = data.people.you;

  const latestNote = [...data.loveNotes]
    .filter((note) => !note.revealOn || note.revealOn <= new Date().toISOString().slice(0, 10))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];

  if (latestNote) {
    notices.push({
      id: `note-${latestNote.id}`,
      kind: "note",
      title: `A new note from ${latestNote.from === "me" ? partner.name : you.name}`,
      detail: latestNote.text,
      href: "/close",
      when: relativeTime(latestNote.createdAt),
    });
  }

  const pendingPrayers = data.prayers.filter(
    (prayer) => prayer.visibility === "shared" && ["new", "updated", "praying"].includes(prayer.status),
  );
  if (pendingPrayers.length) {
    notices.push({
      id: "prayers",
      kind: "prayer",
      title: `${pendingPrayers.length} prayer ${pendingPrayers.length === 1 ? "request needs" : "requests need"} an update`,
      detail: pendingPrayers[0].title,
      href: "/faith",
      when: relativeTime(pendingPrayers[0].createdAt),
    });
  }

  const plan = data.readingPlans[0];
  if (plan) {
    const done = plan.chapters.filter((c) => c.progress.you === "done" && c.progress.me === "done").length;
    notices.push({
      id: "reading",
      kind: "reading",
      title: "Your shared reading is waiting",
      detail: `${done}/${plan.chapters.length} chapters finished · ${plan.title}`,
      href: "/reading",
      when: "today",
    });
  }

  const latestMood = [...data.moods].sort((a, b) => b.date.localeCompare(a.date))[0];
  if (latestMood && Date.now() - new Date(latestMood.date).getTime() < 86400000) {
    notices.push({
      id: "mood",
      kind: "mood",
      title: `${latestMood.person === "me" ? partner.name : you.name} checked in today`,
      detail: latestMood.mood,
      href: "/close",
      when: relativeTime(latestMood.date),
    });
  }

  const visit = data.goals[0];
  if (visit) {
    const saved = visit.contributions.reduce((sum, c) => sum + c.amount, 0);
    notices.push({
      id: "money",
      kind: "money",
      title: `${visit.title.charAt(0).toUpperCase()}${visit.title.slice(1)} is ${Math.round(
        (saved / Math.max(1, visit.target)) * 100,
      )}% there`,
      detail: "One tiny step closer to the life we're dreaming of.",
      href: "/money",
      when: "recently",
    });
  }

  if (!notices.length) {
    notices.push({
      id: "start",
      kind: "plan",
      title: "Your week is a blank page",
      detail: "Add your busy blocks, then we'll find the time you share.",
      href: "/planner",
      when: "now",
    });
  }

  return notices;
}
