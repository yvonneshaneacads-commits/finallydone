import type { PersonId, UniverseData } from "./types";

const other = (person: PersonId): PersonId => (person === "you" ? "me" : "you");

/**
 * The app always shows the signed-in person as "you".
 * Stored data uses the universe's canonical slots, so viewing as the second
 * member mirrors every person reference. The transform is its own inverse.
 */
export function swapViewer(data: UniverseData): UniverseData {
  return {
    ...data,
    people: {
      you: { ...data.people.me, id: "you" },
      me: { ...data.people.you, id: "me" },
    },
    events: data.events.map((event) => ({ ...event, person: other(event.person) })),
    moods: data.moods.map((mood) => ({ ...mood, person: other(mood.person) })),
    loveNotes: data.loveNotes.map((note) => ({ ...note, from: other(note.from) })),
    prayers: data.prayers.map((prayer) => ({ ...prayer, author: other(prayer.author) })),
    prayerSessions: data.prayerSessions.map((session) => ({
      ...session,
      intentions: session.intentions.map((intention) => ({
        ...intention,
        person: other(intention.person),
      })),
    })),
    spiritualReflections: data.spiritualReflections.map((reflection) => ({
      ...reflection,
      author: other(reflection.author),
    })),
    readingPlans: data.readingPlans.map((plan) => ({
      ...plan,
      chapters: plan.chapters.map((chapter) => ({
        ...chapter,
        progress: {
          you: chapter.progress.me,
          me: chapter.progress.you,
        },
      })),
      quotes: plan.quotes.map((quote) => ({ ...quote, author: other(quote.author) })),
      discussion: plan.discussion.map((entry) => ({ ...entry, author: other(entry.author) })),
    })),
    goals: data.goals.map((goal) => ({
      ...goal,
      contributions: goal.contributions.map((contribution) => ({
        ...contribution,
        person: other(contribution.person),
      })),
    })),
    moneyTalks: data.moneyTalks.map((talk) => ({
      ...talk,
      actions: talk.actions.map((action) => ({ ...action, person: other(action.person) })),
    })),
    memories: data.memories.map((memory) => ({ ...memory, author: other(memory.author) })),
    keepsakes: data.keepsakes.map((keepsake) => ({ ...keepsake, author: other(keepsake.author) })),
    musicNotes: data.musicNotes.map((note) => ({ ...note, person: other(note.person) })),
    prayerCards: data.prayerCards.map((card) => ({
      ...card,
      person: card.person === "both" ? "both" : other(card.person),
    })),
    openWhen: data.openWhen.map((letter) => ({ ...letter, from: other(letter.from) })),
    reflections: data.reflections.map((week) => ({
      ...week,
      entries: week.entries.map((entry) => ({ ...entry, person: other(entry.person) })),
    })),
  };
}

export function privateCollections(data: UniverseData) {
  return {
    prayers: data.prayers.filter((prayer) => prayer.visibility === "private"),
    memories: data.memories.filter((memory) => memory.visibility === "private"),
    reflections: data.spiritualReflections.filter((reflection) => reflection.shared === false),
  };
}

/** Shared document only — private items travel to their own author-scoped table. */
export function withoutPrivate(data: UniverseData): UniverseData {
  return {
    ...data,
    prayers: data.prayers.filter((prayer) => prayer.visibility !== "private"),
    memories: data.memories.filter((memory) => memory.visibility !== "private"),
    spiritualReflections: data.spiritualReflections.filter((reflection) => reflection.shared !== false),
  };
}
