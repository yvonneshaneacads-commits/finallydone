import { supabase } from "@/integrations/supabase/client";

export const KEEPSAKE_BUCKET = "keepsakes";
const MAX_BYTES = 10 * 1024 * 1024;
const ALLOWED = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const AUDIO_ALLOWED = [
  "audio/mpeg",
  "audio/mp3",
  "audio/mp4",
  "audio/aac",
  "audio/wav",
  "audio/x-wav",
  "audio/ogg",
  "audio/webm",
];

function extensionFor(file: File) {
  const fromName = file.name.split(".").pop()?.toLowerCase();
  if (fromName === "jpeg") return "jpg";
  if (fromName && ["jpg", "png", "webp", "gif"].includes(fromName)) return fromName;
  if (file.type === "image/png") return "png";
  if (file.type === "image/webp") return "webp";
  if (file.type === "image/gif") return "gif";
  return "jpg";
}

export function imageUploadError(file: File): string | null {
  if (!ALLOWED.includes(file.type)) {
    return "That file type is not a photo we can keep — try a JPG, PNG, WEBP or GIF.";
  }
  if (file.size > MAX_BYTES) {
    return "That photo is larger than 10 MB. A smaller version will keep just as well.";
  }
  return null;
}

export async function uploadPrivateImage(spaceId: string, file: File) {
  const path = `${spaceId}/${crypto.randomUUID()}.${extensionFor(file)}`;
  const { error } = await supabase.storage.from(KEEPSAKE_BUCKET).upload(path, file, {
    contentType: file.type || "image/jpeg",
    upsert: false,
  });
  if (error) throw error;
  return path;
}

export async function signedImageUrls(paths: string[], expiresIn = 21600) {
  if (!paths.length) return {} as Record<string, string>;
  const { data, error } = await supabase.storage
    .from(KEEPSAKE_BUCKET)
    .createSignedUrls(paths, expiresIn);
  if (error || !data) return {} as Record<string, string>;
  const map: Record<string, string> = {};
  data.forEach((row) => {
    if (row.path && row.signedUrl) map[row.path] = row.signedUrl;
  });
  return map;
}

export async function deletePrivateImage(path: string) {
  await supabase.storage.from(KEEPSAKE_BUCKET).remove([path]);
}

function audioExtension(file: File) {
  const fromName = file.name.split(".").pop()?.toLowerCase();
  if (fromName && ["mp3", "m4a", "aac", "wav", "ogg", "webm"].includes(fromName)) return fromName;
  if (file.type === "audio/wav" || file.type === "audio/x-wav") return "wav";
  if (file.type === "audio/mp4") return "m4a";
  if (file.type === "audio/ogg") return "ogg";
  if (file.type === "audio/webm") return "webm";
  return "mp3";
}

export function audioUploadError(file: File): string | null {
  if (!AUDIO_ALLOWED.includes(file.type) && !file.name.match(/\.(mp3|m4a|aac|wav|ogg|webm)$/i)) {
    return "That file isn't audio we can play — try MP3, M4A, WAV, OGG or WEBM.";
  }
  if (file.size > MAX_BYTES) {
    return "That clip is larger than 10 MB. A shorter snippet is plenty.";
  }
  return null;
}

export async function uploadPrivateAudio(spaceId: string, file: File) {
  const path = `${spaceId}/audio-${crypto.randomUUID()}.${audioExtension(file)}`;
  const { error } = await supabase.storage.from(KEEPSAKE_BUCKET).upload(path, file, {
    contentType: file.type || "audio/mpeg",
    upsert: false,
  });
  if (error) throw error;
  return path;
}
