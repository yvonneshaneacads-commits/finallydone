import type { CompanionName } from "@/components/kit/bits";

export interface Companion {
  name: string;
  species: string;
  trait: string;
  note: string;
}

/** The five companions who live in this universe. */
export const COMPANIONS: Record<CompanionName, Companion> = {
  siamese: { name: "Mochi", species: "Siamese", trait: "Calm & loving", note: "Loves cozy afternoons" },
  orange: { name: "Kyo", species: "Orange cat", trait: "Playful & energetic", note: "Brings the sunshine" },
  black: { name: "Yuki", species: "Black cat", trait: "Mischievous & loyal", note: "Loves midnight talks" },
  parakeet: { name: "Mello", species: "Parakeet", trait: "Cheerful & curious", note: "Brings good news" },
  betta: { name: "Nera", species: "Betta", trait: "Peaceful & graceful", note: "Reminds us to slow down" },
};
