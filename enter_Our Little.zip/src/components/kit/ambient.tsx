const PETALS = [
  { left: "4%", delay: "0s", duration: "26s", size: 8 },
  { left: "13%", delay: "7s", duration: "30s", size: 11 },
  { left: "24%", delay: "3s", duration: "24s", size: 7 },
  { left: "37%", delay: "12s", duration: "32s", size: 10 },
  { left: "48%", delay: "1.5s", duration: "28s", size: 8 },
  { left: "61%", delay: "9s", duration: "27s", size: 12 },
  { left: "72%", delay: "4.5s", duration: "31s", size: 9 },
  { left: "83%", delay: "14s", duration: "25s", size: 7 },
  { left: "91%", delay: "6s", duration: "29s", size: 10 },
  { left: "97%", delay: "18s", duration: "33s", size: 8 },
];

const SPARKS = [
  { left: "8%", top: "18%", delay: "0s" },
  { left: "19%", top: "62%", delay: "1.4s" },
  { left: "31%", top: "34%", delay: "2.8s" },
  { left: "44%", top: "78%", delay: "0.8s" },
  { left: "56%", top: "22%", delay: "3.4s" },
  { left: "67%", top: "56%", delay: "4.2s" },
  { left: "76%", top: "14%", delay: "2.2s" },
  { left: "86%", top: "72%", delay: "5s" },
  { left: "94%", top: "40%", delay: "1.8s" },
  { left: "3%", top: "84%", delay: "3.8s" },
];

/** Slow drifting petals and sparks. Pure CSS, hidden for reduced motion. */
export function AmbientLayer() {
  return (
    <div className="ambient" aria-hidden>
      {PETALS.map((petal) => (
        <span
          key={`petal-${petal.left}`}
          className="petal"
          style={{
            left: petal.left,
            width: petal.size,
            height: petal.size,
            animationDelay: petal.delay,
            animationDuration: petal.duration,
          }}
        />
      ))}
      {SPARKS.map((spark) => (
        <span
          key={`spark-${spark.left}`}
          className="spark-dot"
          style={{ left: spark.left, top: spark.top, animationDelay: spark.delay }}
        />
      ))}
    </div>
  );
}
