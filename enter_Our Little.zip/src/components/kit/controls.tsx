import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { MascotAvatar } from "./bits";
import { Textarea } from "@/components/ui/textarea";

export function Field({
  label,
  hint,
  children,
  className,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("flex flex-col gap-1", className)}>
      <span className="text-[0.68rem] font-bold uppercase tracking-[0.08em] text-muted-foreground">
        {label}
      </span>
      {children}
      {hint && <span className="text-[0.62rem] text-muted-foreground">{hint}</span>}
    </label>
  );
}

export function TextField(props: React.ComponentProps<typeof Input> & { label: string; hint?: string }) {
  const { label, hint, className, ...rest } = props;
  return (
    <Field label={label} hint={hint} className={className}>
      <Input {...rest} />
    </Field>
  );
}

export function TextareaField(
  props: React.ComponentProps<typeof Textarea> & { label: string; hint?: string },
) {
  const { label, hint, className, ...rest } = props;
  return (
    <Field label={label} hint={hint} className={className}>
      <Textarea {...rest} />
    </Field>
  );
}

export function SelectField({
  label,
  value,
  onChange,
  options,
  hint,
  className,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  hint?: string;
  className?: string;
}) {
  return (
    <Field label={label} hint={hint} className={className}>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="h-10 w-full rounded-2xl border border-input bg-card px-3 text-[0.85rem] font-medium text-foreground shadow-inner outline-none transition focus-visible:border-sage/60 focus-visible:ring-2 focus-visible:ring-ring/40"
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </Field>
  );
}

export function EmptyState({
  icon,
  mascot,
  title,
  note,
  action,
}: {
  icon?: ReactNode;
  mascot?: "siamese" | "orange" | "black" | "parakeet" | "betta";
  title: string;
  note?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-3xl border border-dashed border-border/80 bg-card/55 px-5 py-8 text-center">
      {mascot ? (
        <MascotAvatar name={mascot} className="h-12 w-12 shadow-note" />
      ) : (
        icon && <span className="text-sage">{icon}</span>
      )}
      <p className="hand text-[1.2rem] leading-tight text-ink/80">{title}</p>
      {note && <p className="max-w-sm text-[0.74rem] leading-relaxed text-muted-foreground">{note}</p>}
      {action}
    </div>
  );
}

export function SectionCard({
  title,
  subtitle,
  action,
  children,
  className,
  id,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  id?: string;
}) {
  return (
    <section id={id} className={cn("paper-card stitched grain p-4 sm:p-5", className)}>
      <div className="mb-3.5 flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 className="text-[1.02rem] font-bold tracking-tight sm:text-[1.12rem]">{title}</h2>
          {subtitle && <p className="mt-1 text-[0.74rem] leading-snug text-muted-foreground">{subtitle}</p>}
        </div>
        {action && <div className="flex flex-wrap items-center gap-1.5">{action}</div>}
      </div>
      {children}
    </section>
  );
}
