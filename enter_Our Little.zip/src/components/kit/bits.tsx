import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { formatClock, formatDateIn, formatWeekday, isDaytime } from "@/lib/time";
import { useNow } from "@/store/universe";
import { tintChip, type Tint } from "./panel";
import { COMPANIONS } from "@/lib/companions";
import { Moon, Sun } from "lucide-react";

export const MASCOTS_URL =
  "https://cdn.enter.pro/resources/uid_100708801/our-little-universe-mascots_344951c8.png";
export const WALLPAPER_URL =
  "https://cdn.enter.pro/resources/uid_100708801/our-little-universe-wallpaper_3181120e.png";

export type CompanionName = "siamese" | "orange" | "black" | "parakeet" | "betta";

const SPRITES: Record<CompanionName, { zoom: number; x: number; y: number }> = {
  siamese: { zoom: 470, x: 24, y: 45 },
  orange: { zoom: 470, x: 58, y: 42 },
  black: { zoom: 470, x: 77, y: 44 },
  parakeet: { zoom: 400, x: 33, y: 4 },
  betta: { zoom: 430, x: 50, y: 82 },
};

export function MascotAvatar({
  name,
  className,
  decorative = true,
}: {
  name: CompanionName;
  className?: string;
  decorative?: boolean;
}) {
  const sprite = SPRITES[name];
  return (
    <span
      role={decorative ? "presentation" : "img"}
      aria-label={decorative ? undefined : `${COMPANIONS[name].name} the ${COMPANIONS[name].species}`}
      className={cn(
        "inline-block shrink-0 overflow-hidden rounded-full border-2 border-card bg-butter-soft shadow-sm",
        className,
      )}
      style={{
        backgroundImage: `url(${MASCOTS_URL})`,
        backgroundSize: `${sprite.zoom}% auto`,
        backgroundPosition: `${sprite.x}% ${sprite.y}%`,
        backgroundRepeat: "no-repeat",
      }}
    />
  );
}

export function CompanionGroup({ className }: { className?: string }) {
  return (
    <img
      src={MASCOTS_URL}
      alt="Mochi the Siamese cat, Kyo the orange cat, Yuki the black cat, Mello the parakeet and Nera the betta fish"
      crossOrigin="anonymous"
      loading="lazy"
      className={cn("h-full w-full object-cover", className)}
    />
  );
}

export function LiveClock({
  timezone,
  showDate = true,
  className,
  align = "left",
}: {
  timezone: string;
  showDate?: boolean;
  className?: string;
  align?: "left" | "center" | "right";
}) {
  const now = useNow(1000);
  const day = isDaytime(now, timezone);
  return (
    <div
      className={cn(
        "flex flex-col gap-1",
        align === "center" && "items-center text-center",
        align === "right" && "items-end text-right",
        className,
      )}
    >
      <div className="flex items-center gap-2">
        <span className="text-[1.6rem] font-bold leading-none tracking-tight tabular-nums sm:text-[1.75rem]">
          {formatClock(now, timezone)}
        </span>
        {day ? (
          <Sun className="h-4 w-4 text-[hsl(42_80%_58%)]" aria-hidden />
        ) : (
          <Moon className="h-4 w-4 text-powder" aria-hidden />
        )}
      </div>
      {showDate && (
        <span className="text-[0.68rem] font-semibold text-muted-foreground">
          {formatDateIn(now, timezone, false)}
        </span>
      )}
    </div>
  );
}

export function TodayLabel() {
  const now = useNow(30000);
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
  return (
    <span className="text-[0.7rem] font-semibold text-muted-foreground">
      {formatWeekday(now, tz, true)} · {formatClock(now, tz)}
    </span>
  );
}

export function SoftProgress({
  value,
  tone = "sage",
  className,
  height = "h-2.5",
}: {
  value: number;
  tone?: "sage" | "powder" | "peach" | "butter" | "coral";
  className?: string;
  height?: string;
}) {
  const tones: Record<string, string> = {
    sage: "bg-sage",
    powder: "bg-powder",
    peach: "bg-coral/70",
    butter: "bg-[hsl(44_72%_62%)]",
    coral: "bg-coral",
  };
  return (
    <div className={cn("w-full overflow-hidden rounded-full bg-muted", height, className)}>
      <div
        className={cn("relative h-full overflow-hidden rounded-full transition-[width] duration-700 ease-soft", tones[tone])}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      >
        <span className="shimmer-bar absolute inset-0 animate-shimmer" aria-hidden />
      </div>
    </div>
  );
}

export function IconTile({
  children,
  tone = "cream",
  className,
}: {
  children: ReactNode;
  tone?: Tint;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "grid h-8 w-8 shrink-0 place-items-center rounded-[0.7rem] border border-border/60",
        tintChip[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function PageHeading({
  eyebrow,
  title,
  mascot,
  children,
}: {
  eyebrow: string;
  title: string;
  mascot?: CompanionName;
  children?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div className="flex items-center gap-3">
        {mascot && (
          <MascotAvatar name={mascot} className="h-11 w-11 shadow-note sm:h-12 sm:w-12" />
        )}
        <div>
          <p className="hand text-[1.15rem] text-sage">{eyebrow}</p>
          <h1 className="title-wave inline-block text-[1.9rem] font-bold leading-[1.15] tracking-tight sm:text-[2.25rem]">{title}</h1>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  );
}

export function Pill({
  children,
  tone = "cream",
  className,
}: {
  children: ReactNode;
  tone?: Tint;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-border/50 px-2.5 py-1 text-[0.68rem] font-semibold",
        tintChip[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
