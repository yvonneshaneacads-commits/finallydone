import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export type Tint = "cream" | "sage" | "peach" | "butter" | "powder" | "lilac" | "blush";

export const tintSurface: Record<Tint, string> = {
  cream: "bg-card",
  sage: "bg-sage-soft",
  peach: "bg-peach-soft",
  butter: "bg-butter-soft",
  powder: "bg-powder-soft",
  lilac: "bg-lilac",
  blush: "bg-blush",
};

export const tintChip: Record<Tint, string> = {
  cream: "bg-muted text-ink",
  sage: "bg-sage-soft text-sage",
  peach: "bg-peach text-accent-foreground",
  butter: "bg-butter text-ink",
  powder: "bg-powder text-ink",
  lilac: "bg-lilac text-ink",
  blush: "bg-blush text-ink",
};

interface PanelProps {
  title?: ReactNode;
  icon?: ReactNode;
  action?: ReactNode;
  tint?: Tint;
  className?: string;
  bodyClassName?: string;
  children: ReactNode;
  id?: string;
}

export function Panel({
  title,
  icon,
  action,
  tint = "cream",
  className,
  bodyClassName,
  children,
  id,
}: PanelProps) {
  return (
    <section
      id={id}
      className={cn(
        "grain stitched relative flex flex-col overflow-hidden rounded-[1.8rem] border border-border/80 shadow-card ring-1 ring-card/60",
        tintSurface[tint],
        className,
      )}
    >
      {(title || action) && (
        <header className="flex items-center justify-between gap-3 border-b border-border/60 px-4 py-3 sm:px-5">
          <div className="flex min-w-0 items-center gap-2.5">
            {icon && (
              <span className="grid h-7 w-7 shrink-0 -rotate-3 place-items-center rounded-full bg-card/80 text-ink-soft shadow-sm ring-1 ring-border/40">
                {icon}
              </span>
            )}
            <h2 className="truncate text-[1rem] font-bold tracking-tight sm:text-[1.06rem]">{title}</h2>
          </div>
          {action && <div className="shrink-0 text-[0.72rem] font-semibold text-muted-foreground">{action}</div>}
        </header>
      )}
      <div className={cn("relative flex-1 p-3.5 sm:p-4", bodyClassName)}>{children}</div>
    </section>
  );
}

export function DottedRule({ className }: { className?: string }) {
  return <div className={cn("border-t border-dashed border-border/80", className)} />;
}

export function StickyNote({
  children,
  tone = "butter",
  className,
}: {
  children: ReactNode;
  tone?: "butter" | "peach" | "blush" | "sage";
  className?: string;
}) {
  const tones: Record<string, string> = {
    butter: "bg-butter-soft",
    peach: "bg-peach-soft",
    blush: "bg-blush",
    sage: "bg-sage-soft",
  };
  return (
    <div
      className={cn(
        "relative rounded-[0.5rem] border border-border/70 px-3 py-2 shadow-note transition duration-300 hover:rotate-0 hover:scale-[1.02]",
        tones[tone],
        className,
      )}
    >
      <span className="washi absolute -top-2 left-1/2 h-4 w-10 -translate-x-1/2 rotate-[-3deg] rounded-[2px] opacity-90" />
      <p className="hand text-[0.98rem] leading-tight text-ink/80">{children}</p>
    </div>
  );
}

export function TinyStar({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className={cn("h-3 w-3", className)} fill="none">
      <path
        d="M12 3.5l1.9 5.1 5.4.4-4.1 3.4 1.3 5.3L12 14.7l-4.5 3 1.3-5.3-4.1-3.4 5.4-.4z"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
    </svg>
  );
}
