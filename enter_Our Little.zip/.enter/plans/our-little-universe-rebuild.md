# Our Little Universe — rebuild plan

You started this in another account and can't export it, so I'll rebuild it from your screenshot and your original brief. Goal: the **same layout and mood as your reference image**, with every section actually working and sharing data between the two of you.

## The experience

A single cosy "digital home" that opens like a nostalgic computer desktop: a soft status bar on top (site name, shared world clock, notifications, theme switch, avatar), an illustrated icon rail down the left, and a warm, paper-textured room scene behind hand-drawn cards with dotted borders, gingham accents and sticky notes.

Palette: cream, pistachio/sage, butter yellow, powder blue, peach/blush, muted coral accents, warm brown text. Type: a rounded friendly sans for the interface, a handwritten style for notes and labels, and a clean readable font for long text. Five original mascots — Siamese cat, orange cat, black cat, blue parakeet, red-tailed betta fish — appear across the site with consistent personalities and gentle, optional motion. Light and dark theme, reduced-motion support, keyboard-friendly focus states.

## Home — matched to the reference layout

- [ ] Desktop-style shell: window chrome, status bar with dates, icon rail (Home, Planner, Staying Close, Faith & Prayer, Reading, Money & Future, Dreams Board, Memories & Letters, Settings), and a bottom bar on mobile.
- [ ] Welcome panel with "Welcome back, Onni & Navi", a chosen verse/affirmation, and the illustrated companions.
- [ ] "Our Locations & Time" card: live local clocks for both people, real difference between them, and an editable location per person.
- [ ] "Today's Little Overview": eight rows (schedules, next call, date night, mood check-in, prayer updates, reading progress, shared savings, next milestone), each opening its section.
- [ ] "Weekly Planner" preview: both lanes for the current day, a highlighted **Our Time** overlap ribbon with duration, and a "Create Call / Date" action.
- [ ] "Our Animal Friends" card listing each mascot with its personality lines.
- [ ] "Quick Access" tile grid, the tilted "new message from your partner" note, and the little side sticky notes.
- [ ] "Notifications" list with relative times that deep-links to its section.
- [ ] "Shared Goals" card with the featured visit-fund illustration, progress bar and amount, plus fund chips and Add Goal.
- [ ] "This Week's Reflection" card with the two three-item lists and a link to the full reflection.
- [ ] Responsive reflow: cards stack into one column, tap-friendly controls, nothing overlapping or cut off.

## The other sections

- [ ] **Weekly Planner** — week view with two lanes, add/edit/delete events (title, day, start/end, category, notes, busy / flexible / available, recurrence), per-person time zone with full conversion of real events, explicit availability (empty ≠ free), automatic overlap "Our Time" windows with durations, recurring rituals (goodnight call, date night, Sunday check-in, reading session, prayer, money talk) and conflict warnings that propose another open window.
- [ ] **Staying Close** — daily mood check-in with custom moods and a note, "what I need today", gentle canned responses, and a love-note board including notes scheduled to appear on a future date.
- [ ] **Faith & Prayer** — shared prayer list with categories, scripture reference, statuses (new → answered/gratitude), dated updates that append rather than overwrite, weekly intentions, shared prayer sessions with history, and private reflections visible only to their author.
- [ ] **Reading Together** — books/plans with dates, chapter-level status, shared and per-person progress, notes, quotes, questions and a discussion journal.
- [ ] **Money & Future** — trip cost calculator with saved comparable scenarios and clearly labelled manual exchange rates, shared goal cards with contributions, targets and projected completion, and an archived monthly money talk with action items.
- [ ] **Dreams Board** — one-, three- and five-year horizons, dream cards with status, budget, milestones and next actions, movable between horizons, cross-linked to the matching fund, plus a "the kind of life we want to build" note.
- [ ] **Memories & Letters** — scrapbook entries with photos, dates, tags, private drafts vs shared, and an "Open When" letter collection.
- [ ] **Settings** — names, avatars, time zones, personal colours, anniversary dates, wallpaper/theme, which home widgets show, notification preferences, reduced motion and text size.

## Data, accounts and privacy

- [ ] Two-person private space with sign-in, an invite for the second person, and sign-out; no content is reachable without being one of the two members.
- [ ] Shared items (schedule, prayers, reading, goals, dreams, shared letters) sync between both accounts and both devices; personal mood notes, private prayers and private letters stay with their author, enforced on the server, not just hidden.
- [ ] All edits persist after refresh; destructive actions ask for confirmation; empty and loading states are designed rather than blank.
- [ ] Times are stored as real instants in named time zones (Asia/Manila, Asia/Kolkata, Asia/Brisbane and others), so conversions and daylight-saving changes stay correct; no hardcoded offsets.

## Deliberately out of scope

No email/push reminders or external calendar sync, no live flight or accommodation pricing, and no live exchange-rate feed — those stay editable and clearly labelled as your estimates. Notifications live inside the app only.

## Assumptions

Seeded with Onni & Navi, Pasig (Asia/Manila) and Bengaluru (Asia/Kolkata), with Brisbane available; all of it editable in Settings. The reference image is the layout standard for Home. Your original nine-section brief defines the feature set, so sections are built complete rather than as placeholders.

If something you expected is missing from this plan, tell me and I'll fold it in before building.
