import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const GATEWAY = "https://api.enter.pro/code/api/v1/edge-function/connectors/operations/";
const OPERATIONS = {
  list: "ffb3236a-6aa5-42f3-baed-2a9beb335f33",
  create: "4f61b786-ba3c-4368-8529-eb388be5022f",
  patch: "65dc6904-5599-4fd7-9b4c-0a9dab0a54a3",
  remove: "6b8bb460-ab2b-481a-92af-2c729fdeed41",
};

interface GoogleEventInput {
  summary?: string;
  description?: string;
  startISO?: string;
  endISO?: string;
  timezone?: string;
  location?: string;
}

interface NormalisedEvent {
  id: string;
  title: string;
  start: string | null;
  end: string | null;
  allDay: boolean;
  location: string | null;
  transparency: string;
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function connectorToken() {
  return Deno.env.get("CONNECTOR_RUNTIME_TOKEN_76b8d4cea638_1137") ?? "";
}

async function callConnector(operationId: string, input: Record<string, unknown>) {
  const token = connectorToken();
  if (!token) {
    throw new Error("Google Calendar is not connected for this workspace yet");
  }

  const response = await fetch(`${GATEWAY}${operationId}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ input }),
  });

  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const message =
      (payload as { error?: { message?: string } } | null)?.error?.message ??
      `Google Calendar returned ${response.status}`;
    throw new Error(message);
  }
  return (payload as { data?: unknown } | null)?.data ?? null;
}

function collectArrays(value: unknown, depth = 0): Record<string, unknown>[][] {
  if (!value || typeof value !== "object" || depth > 6) return [];
  if (Array.isArray(value)) {
    const objects = value.filter(
      (item): item is Record<string, unknown> => Boolean(item) && typeof item === "object",
    );
    return objects.length ? [objects] : [];
  }
  const record = value as Record<string, unknown>;
  if (Array.isArray(record.items)) {
    return [record.items as Record<string, unknown>[]];
  }
  const found: Record<string, unknown>[][] = [];
  for (const entry of Object.values(record)) {
    found.push(...collectArrays(entry, depth + 1));
  }
  return found;
}

function normaliseEvent(raw: Record<string, unknown>): NormalisedEvent {
  const start = raw.start as { dateTime?: string; date?: string } | undefined;
  const end = raw.end as { dateTime?: string; date?: string } | undefined;
  return {
    id: String(raw.id ?? ""),
    title: String(raw.summary ?? "Google Calendar event").slice(0, 200),
    start: start?.dateTime ?? start?.date ?? null,
    end: end?.dateTime ?? end?.date ?? null,
    allDay: Boolean(start?.date && !start?.dateTime),
    location: typeof raw.location === "string" ? raw.location.slice(0, 200) : null,
    transparency: String(raw.transparency ?? "opaque"),
  };
}

function findEventId(value: unknown, depth = 0): string | null {
  if (!value || typeof value !== "object" || depth > 6) return null;
  const record = value as Record<string, unknown>;
  for (const key of ["id", "event_id", "eventId"]) {
    const candidate = record[key];
    if (typeof candidate === "string" && candidate.length > 5 && candidate !== "primary") {
      return candidate;
    }
  }
  for (const entry of Object.values(record)) {
    const found = findEventId(entry, depth + 1);
    if (found) return found;
  }
  return null;
}

function cleanEvent(input: GoogleEventInput) {
  const summary = String(input.summary ?? "").trim().slice(0, 200);
  const description = String(input.description ?? "").slice(0, 1800);
  const startISO = String(input.startISO ?? "");
  const endISO = String(input.endISO ?? "");
  const timezone = String(input.timezone ?? "UTC");
  const location = String(input.location ?? "").slice(0, 200);

  if (!summary) throw new Error("An event needs a title before it can go to Google");
  if (!startISO || !endISO) throw new Error("An event needs a start and an end");
  if (Number.isNaN(new Date(startISO).getTime()) || Number.isNaN(new Date(endISO).getTime())) {
    throw new Error("Those event times could not be read");
  }
  if (new Date(endISO) <= new Date(startISO)) {
    throw new Error("The end time needs to be after the start");
  }

  return { summary, description, startISO, endISO, timezone, location };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authorization = req.headers.get("Authorization") ?? "";
    if (!authorization) return json({ error: "Please sign in first" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const supabase = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authorization } },
      auth: { persistSession: false },
    });

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) return json({ error: "Please sign in first" }, 401);

    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "status");
    const spaceId = String(body.spaceId ?? "");
    if (!spaceId) return json({ error: "Missing universe" }, 400);

    const { data: member } = await supabase
      .from("universe_members")
      .select("space_id")
      .eq("space_id", spaceId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (!member) return json({ error: "This universe is not yours" }, 403);

    if (action === "status") {
      const payload = await callConnector(OPERATIONS.list, {
        calendar_id: "primary",
        maxResults: 1,
        singleEvents: true,
        timeMin: new Date(Date.now() - 86400000).toISOString(),
        timeMax: new Date(Date.now() + 86400000).toISOString(),
        fields: "items(id,status,start,end),timeZone",
      });
      const record = (payload ?? {}) as Record<string, unknown>;
      return json({
        ok: true,
        connected: true,
        timezone: typeof record.timeZone === "string" ? record.timeZone : null,
      });
    }

    if (action === "pull") {
      const timeMin = String(body.timeMin ?? "");
      const timeMax = String(body.timeMax ?? "");
      if (!timeMin || !timeMax) return json({ error: "Missing the week window" }, 400);

      const payload = await callConnector(OPERATIONS.list, {
        calendar_id: "primary",
        timeMin,
        timeMax,
        singleEvents: true,
        orderBy: "startTime",
        maxResults: 200,
        fields: "items(id,status,summary,start,end,location,transparency),timeZone",
      });

      const arrays = collectArrays(payload);
      const rawEvents = arrays.length
        ? arrays.reduce((longest, current) => (current.length > longest.length ? current : longest), [])
        : [];
      const items = rawEvents
        .filter((raw) => raw.status !== "cancelled")
        .map(normaliseEvent)
        .filter((event) => event.id && event.start);

      const record = (payload ?? {}) as Record<string, unknown>;
      console.log(`calendar pull: ${items.length} events`);
      return json({
        ok: true,
        items,
        count: items.length,
        timezone: typeof record.timeZone === "string" ? record.timeZone : null,
        shape: Object.keys(record).slice(0, 12),
      });
    }

    if (action === "create") {
      const event = cleanEvent((body.event ?? {}) as GoogleEventInput);
      const payload = await callConnector(OPERATIONS.create, {
        calendar_id: "primary",
        summary: event.summary,
        description: event.description || undefined,
        location: event.location || undefined,
        start_datetime: event.startISO,
        end_datetime: event.endISO,
        timezone: event.timezone,
        send_updates: "none",
        create_meeting_room: false,
        exclude_organizer: true,
        transparency: "opaque",
      });
      const id = findEventId(payload);
      if (!id) return json({ error: "Google accepted the event but returned no id" }, 502);
      console.log("calendar create: ok");
      return json({ ok: true, googleEventId: id });
    }

    if (action === "patch") {
      const googleEventId = String(body.googleEventId ?? "");
      if (!googleEventId) return json({ error: "Missing the Google event id" }, 400);
      const event = cleanEvent((body.event ?? {}) as GoogleEventInput);
      await callConnector(OPERATIONS.patch, {
        calendar_id: "primary",
        event_id: googleEventId,
        summary: event.summary,
        description: event.description || undefined,
        location: event.location || undefined,
        start_time: event.startISO,
        end_time: event.endISO,
        timezone: event.timezone,
        send_updates: "none",
      });
      console.log("calendar patch: ok");
      return json({ ok: true });
    }

    if (action === "remove") {
      const googleEventId = String(body.googleEventId ?? "");
      if (!googleEventId) return json({ error: "Missing the Google event id" }, 400);
      await callConnector(OPERATIONS.remove, {
        calendar_id: "primary",
        event_id: googleEventId,
        send_updates: "none",
      });
      console.log("calendar remove: ok");
      return json({ ok: true });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Google Calendar did not answer";
    console.error("calendar sync failed:", message);
    return json({ error: message }, 502);
  }
});
